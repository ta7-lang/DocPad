#!/usr/bin/env python3
"""
Скачивает свободные шрифты из репозитория Google Fonts (github.com/google/fonts)
и встраивает их в приложение: app/src/main/assets/editor/fonts/

Запускается автоматически при сборке на GitHub (см. .github/workflows/build.yml).
Локально: python3 tools/fetch_fonts.py   (нужны git и интернет)

Метрически совместимые замены офисных шрифтов регистрируются под их «офисными»
именами: документ, набранный в Times New Roman, откроется с теми же переносами строк.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "app", "src", "main", "assets", "editor", "fonts")
FILES = os.path.join(OUT, "files")
LIC = os.path.join(OUT, "licenses")

# Каталоги в google/fonts (ofl/, apache/ или ufl/ — ищутся все три)
FAMILIES = [
    # замены офисных шрифтов
    "arimo", "tinos", "cousine", "carlito", "caladea", "gelasio", "comicneue", "ebgaramond",
    # популярные шрифты с кириллицей
    "ptsans", "ptserif", "ptmono", "ptsansnarrow", "opensans", "robotoslab", "robotomono", "robotocondensed",
    "montserrat", "lora", "merriweather", "playfairdisplay", "oswald", "ubuntu", "sourcesans3", "sourceserif4",
    "notosans", "notoserif", "inter", "raleway", "nunito", "rubik", "exo2", "alegreya", "cormorantgaramond",
    "spectral", "literata", "manrope", "jetbrainsmono", "firacode", "comfortaa", "philosopher", "russoone",
    "yesevaone", "kurale", "lobster", "caveat", "pacifico", "amaticsc", "marckscript", "badscript", "neucha", "poiretone",
]

# Офисное имя -> каталог шрифта-замены
ALIASES = {
    "Arial": "arimo", "Helvetica": "arimo", "Arial Narrow": "ptsansnarrow",
    "Times New Roman": "tinos", "Times": "tinos",
    "Courier New": "cousine", "Courier": "cousine", "Consolas": "cousine", "Lucida Console": "cousine",
    "Calibri": "carlito", "Calibri Light": "carlito", "Cambria": "caladea", "Georgia": "gelasio",
    "Comic Sans MS": "comicneue", "Garamond": "ebgaramond", "Segoe UI": "opensans", "Verdana": "ptsans",
    "Tahoma": "ptsans", "Trebuchet MS": "ptsans", "Book Antiqua": "ebgaramond", "Palatino Linotype": "ebgaramond",
    "Century Gothic": "montserrat", "Franklin Gothic": "ptsansnarrow", "Candara": "opensans", "Corbel": "opensans",
    "Constantia": "lora", "Bookman Old Style": "lora", "Impact": "oswald",
}

CATS = {"SANS_SERIF": "sans", "SERIF": "serif", "DISPLAY": "display", "HANDWRITING": "hand", "MONOSPACE": "mono"}
MAX_TOTAL_MB = float(os.environ.get("FONTS_MAX_MB", "45"))


def run(cmd, cwd=None):
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def parse_metadata(path):
    txt = open(path, encoding="utf-8").read()
    name = re.search(r'^name:\s*"([^"]+)"', txt, re.M)
    cat = re.search(r'^category:\s*"([^"]+)"', txt, re.M)
    fonts = []
    for block in re.findall(r"fonts\s*\{(.*?)\n\}", txt, re.S):
        f = {
            "style": (re.search(r'style:\s*"([^"]+)"', block) or [None, "normal"])[1],
            "weight": int((re.search(r"weight:\s*(\d+)", block) or [None, "400"])[1]),
            "filename": (re.search(r'filename:\s*"([^"]+)"', block) or [None, ""])[1],
        }
        if f["filename"]:
            fonts.append(f)
    axes = {}
    for block in re.findall(r"axes\s*\{(.*?)\}", txt, re.S):
        tag = re.search(r'tag:\s*"([^"]+)"', block)
        mn = re.search(r"min_value:\s*([\d.]+)", block)
        mx = re.search(r"max_value:\s*([\d.]+)", block)
        if tag and mn and mx:
            axes[tag.group(1)] = (float(mn.group(1)), float(mx.group(1)))
    return {
        "name": name.group(1) if name else None,
        "cat": CATS.get(cat.group(1) if cat else "", "serif"),
        "fonts": fonts,
        "axes": axes,
    }


def main():
    if os.environ.get("SKIP_FONTS"):
        print("SKIP_FONTS задан — шрифты не скачиваются")
        return
    tmp = tempfile.mkdtemp(prefix="gfonts-")
    try:
        run(["git", "clone", "--depth", "1", "--filter=blob:none", "--sparse", "https://github.com/google/fonts.git", tmp])
        patterns = []
        for fam in FAMILIES:
            for lic in ("ofl", "apache", "ufl"):
                patterns.append(f"/{lic}/{fam}/")
        run(["git", "sparse-checkout", "set", "--no-cone"] + patterns, cwd=tmp)

        if os.path.isdir(FILES):
            shutil.rmtree(FILES)
        os.makedirs(FILES, exist_ok=True)
        os.makedirs(LIC, exist_ok=True)

        css = ["/* Сгенерировано tools/fetch_fonts.py — не редактируйте вручную */"]
        families = []
        by_dir = {}
        total = 0
        for fam in FAMILIES:
            d = None
            for lic in ("ofl", "apache", "ufl"):
                p = os.path.join(tmp, lic, fam)
                if os.path.isdir(p):
                    d = p
                    break
            if not d or not os.path.exists(os.path.join(d, "METADATA.pb")):
                print(f"  — нет каталога {fam}, пропускаю")
                continue
            meta = parse_metadata(os.path.join(d, "METADATA.pb"))
            if not meta["name"]:
                continue
            faces = []
            for f in meta["fonts"]:
                variable = "[" in f["filename"]
                # у статических семейств берём только обычное и полужирное начертания
                if not variable and f["weight"] not in (400, 700):
                    continue
                src = os.path.join(d, f["filename"])
                if not os.path.exists(src):
                    continue
                size = os.path.getsize(src)
                if (total + size) / 1e6 > MAX_TOTAL_MB:
                    print(f"  ! превышен лимит {MAX_TOTAL_MB} МБ — пропускаю {f['filename']}")
                    continue
                safe = re.sub(r"[^A-Za-z0-9._-]", "_", f["filename"])
                if any(x["file"] == safe for x in faces):
                    continue
                shutil.copy(src, os.path.join(FILES, safe))
                total += size
                weight = f"{int(meta['axes']['wght'][0])} {int(meta['axes']['wght'][1])}" if variable and "wght" in meta["axes"] else str(f["weight"])
                faces.append({"file": safe, "style": f["style"], "weight": weight})
            if not faces:
                continue
            for lf in ("OFL.txt", "LICENSE.txt", "UFL.txt", "LICENSE"):
                lp = os.path.join(d, lf)
                if os.path.exists(lp):
                    shutil.copy(lp, os.path.join(LIC, f"{fam}-{lf}"))
                    break
            by_dir[fam] = (meta["name"], faces)
            families.append({"family": meta["name"], "cat": meta["cat"]})
            for fc in faces:
                css.append(
                    f'@font-face {{ font-family: "{meta["name"]}"; src: url("files/{fc["file"]}") format("truetype"); '
                    f'font-weight: {fc["weight"]}; font-style: {fc["style"]}; font-display: swap; }}'
                )
            print(f"  + {meta['name']}: {len(faces)} файл(ов)")

        css.append("/* Офисные имена -> метрически совместимые замены */")
        aliases = []
        for office, fam in ALIASES.items():
            if fam not in by_dir:
                continue
            real, faces = by_dir[fam]
            aliases.append({"family": office, "target": real})
            for fc in faces:
                css.append(
                    f'@font-face {{ font-family: "{office}"; src: local("{office}"), url("files/{fc["file"]}") format("truetype"); '
                    f'font-weight: {fc["weight"]}; font-style: {fc["style"]}; font-display: swap; }}'
                )

        with open(os.path.join(OUT, "fonts.css"), "w", encoding="utf-8") as fh:
            fh.write("\n".join(css) + "\n")
        with open(os.path.join(OUT, "fonts.json"), "w", encoding="utf-8") as fh:
            json.dump({"families": families, "aliases": aliases}, fh, ensure_ascii=False, indent=1)
        print(f"Готово: {len(families)} семейств, {total / 1e6:.1f} МБ")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        print("Не удалось скачать шрифты:", e, file=sys.stderr)
        print("Приложение соберётся без встроенных шрифтов (будут доступны системные).", file=sys.stderr)
        sys.exit(0)
