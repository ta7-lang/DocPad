package com.docpad.editor

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Единственный экран приложения. Весь редактор написан на HTML/CSS/JS
 * (app/src/main/assets/editor) и работает внутри WebView. Kotlin-часть
 * отвечает за то, что браузер сам сделать не может: доступ к файлам через
 * системный диалог Android, печать и PDF, «Поделиться», буфер обмена,
 * полноэкранный режим и открытие документов из других приложений.
 */
class MainActivity : ComponentActivity() {

    lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private var pageLoaded = false
    private var pendingIntent: Intent? = null
    private var lastBackPress = 0L
    private var fullscreen = false

    /** Прочитанные файлы ждут, пока JS заберёт их через Bridge.takeFile(id). */
    val pendingFiles = ConcurrentHashMap<Int, ByteArray>()
    val fileIds = AtomicInteger(1)

    /** Данные, которые нужно записать после выбора места сохранения. */
    private var pendingSave: ByteArray? = null
    private var pendingSaveCallback: String? = null

    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsPending: Pair<String, String>? = null

    private val openDocLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uri = res.data?.data
            if (uri == null) {
                js("App.onFileCancelled && App.onFileCancelled()")
                return@registerForActivityResult
            }
            persist(uri, res.data?.flags ?: 0)
            deliverUri(uri, "open")
        }

    private val createDocLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = pendingSave
            val cb = pendingSaveCallback
            pendingSave = null
            pendingSaveCallback = null
            val uri = res.data?.data
            if (uri == null || data == null) {
                js("App.onSaveResult && App.onSaveResult(${JSONObject.quote(cb ?: "")}, false, null, null)")
                return@registerForActivityResult
            }
            persist(uri, res.data?.flags ?: 0)
            val ok = writeUri(uri, data)
            val name = displayName(uri)
            js(
                "App.onSaveResult && App.onSaveResult(${JSONObject.quote(cb ?: "")}, $ok, " +
                    "${JSONObject.quote(uri.toString())}, ${JSONObject.quote(name)})"
            )
        }

    private val chooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = fileChooserCallback
            fileChooserCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Отступы под системные панели и клавиатуру (Android 15 рисует «от края до края»)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            if (fullscreen) {
                v.setPadding(0, 0, 0, ime.bottom)
            } else {
                v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            }
            WindowInsetsCompat.CONSUMED
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            textZoom = 100
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webView.isVerticalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        WebView.setWebContentsDebuggingEnabled(BuildConfigHelper.isDebug(this))

        webView.addJavascriptInterface(Bridge(this), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                openExternal(url.toString())
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                pageLoaded = true
                pendingIntent?.let { handleIntent(it) }
                pendingIntent = null
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Процесс отрисовки упал (обычно из-за нехватки памяти) — перезапускаем экран.
                // Документ восстановится из автосохранения.
                recreate()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                return try {
                    chooserLauncher.launch(params.createIntent())
                    true
                } catch (e: ActivityNotFoundException) {
                    fileChooserCallback = null
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.App && App.onBack) ? App.onBack() : false") { v ->
                    if (v == "true") return@evaluateJavascript
                    val now = System.currentTimeMillis()
                    if (now - lastBackPress < 2000) {
                        finish()
                    } else {
                        lastBackPress = now
                        Toast.makeText(this@MainActivity, R.string.exit_hint, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        if (webView.url == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/editor/index.html")
        }
        intent?.let { if (isDocumentIntent(it)) pendingIntent = it }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!isDocumentIntent(intent)) return
        if (pageLoaded) handleIntent(intent) else pendingIntent = intent
    }

    override fun onPause() {
        super.onPause()
        js("App.onPause && App.onPause()")
    }

    private fun isDocumentIntent(i: Intent) =
        i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_EDIT || i.action == Intent.ACTION_SEND

    private fun handleIntent(i: Intent) {
        when (i.action) {
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> i.data?.let {
                persist(it, i.flags)
                deliverUri(it, "intent")
            }
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                val stream: Uri? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra(Intent.EXTRA_STREAM)
                if (stream != null) {
                    deliverUri(stream, "intent")
                } else {
                    val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
                    js("App.onSharedText && App.onSharedText(${JSONObject.quote(text)})")
                }
            }
        }
    }

    private fun persist(uri: Uri, flags: Int) {
        try {
            val f = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(
                uri, if (f == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION else f
            )
        } catch (_: Exception) {
            // не все источники разрешают постоянный доступ — это нормально
        }
    }

    fun canWrite(uri: Uri): Boolean =
        contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }

    fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { return it }
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "document"
    }

    /** Читает файл в фоне и сообщает JS, что его можно забрать. */
    fun deliverUri(uri: Uri, source: String) {
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Не удалось открыть файл")
                val id = fileIds.getAndIncrement()
                pendingFiles[id] = bytes
                val info = JSONObject()
                    .put("id", id)
                    .put("name", displayName(uri))
                    .put("mime", contentResolver.getType(uri) ?: "")
                    .put("uri", uri.toString())
                    .put("size", bytes.size)
                    .put("canWrite", canWrite(uri))
                    .put("source", source)
                js("App.onFileOpened && App.onFileOpened($info)")
            } catch (e: Throwable) {
                js("App.onError && App.onError(${JSONObject.quote("Ошибка чтения файла: " + (e.message ?: e.javaClass.simpleName))})")
            }
        }.start()
    }

    fun writeUri(uri: Uri, data: ByteArray): Boolean = try {
        // "wt" — перезапись с усечением; некоторые провайдеры поддерживают только "w"
        val out = try {
            contentResolver.openOutputStream(uri, "wt")
        } catch (_: Exception) {
            contentResolver.openOutputStream(uri, "w")
        }
        out?.use { it.write(data); it.flush() } != null
    } catch (_: Exception) {
        false
    }

    fun launchOpen(mimes: Array<String>) = runOnUiThread {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimes)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            openDocLauncher.launch(i)
        } catch (e: ActivityNotFoundException) {
            toast("Нет приложения для выбора файлов")
        }
    }

    fun launchSaveAs(data: ByteArray, name: String, mime: String, callbackId: String) = runOnUiThread {
        pendingSave = data
        pendingSaveCallback = callbackId
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_TITLE, name)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            createDocLauncher.launch(i)
        } catch (e: ActivityNotFoundException) {
            pendingSave = null
            toast("Нет приложения для сохранения файлов")
        }
    }

    fun printPage(title: String) = runOnUiThread {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter = webView.createPrintDocumentAdapter(title)
        val attrs = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()
        pm.print(title, adapter, attrs)
    }

    fun shareBytes(data: ByteArray, name: String, mime: String) = runOnUiThread {
        try {
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "document" }
            val f = File(dir, safe)
            f.writeBytes(data)
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "application/octet-stream" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Поделиться"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    fun shareText(text: String) = runOnUiThread {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "Поделиться текстом"))
    }

    fun openExternal(url: String) = runOnUiThread {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    fun setKeepScreenOn(on: Boolean) = runOnUiThread {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun setFullscreen(on: Boolean) = runOnUiThread {
        fullscreen = on
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
        ViewCompat.requestApplyInsets(root)
    }

    fun setBarsColor(color: String, lightBackground: Boolean) = runOnUiThread {
        try {
            root.setBackgroundColor(Color.parseColor(color))
        } catch (_: Exception) {
        }
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = lightBackground
        c.isAppearanceLightNavigationBars = lightBackground
    }

    /** Чтение текста вслух системным синтезатором речи */
    fun speak(text: String, lang: String) = runOnUiThread {
        if (tts == null) {
            ttsPending = text to lang
            tts = TextToSpeech(this) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (!ttsReady) toast("Синтез речи недоступен на этом устройстве")
                ttsPending?.let { (t, l) -> ttsPending = null; speakNow(t, l) }
            }
        } else if (ttsReady) speakNow(text, lang) else ttsPending = text to lang
    }

    private fun speakNow(text: String, lang: String) {
        val t = tts ?: return
        if (!ttsReady) return
        t.setLanguage(Locale.forLanguageTag(lang))
        t.stop()
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        // делим по предложениям, чтобы не превысить лимит длины
        val parts = mutableListOf<String>()
        val sb = StringBuilder()
        for (sentence in text.split(Regex("(?<=[.!?…\\n])\\s+"))) {
            if (sb.length + sentence.length > max && sb.isNotEmpty()) { parts.add(sb.toString()); sb.clear() }
            if (sentence.length > max) sentence.chunked(max).forEach { parts.add(it) } else sb.append(sentence).append(' ')
        }
        if (sb.isNotBlank()) parts.add(sb.toString())
        parts.forEachIndexed { i, p -> t.speak(p, TextToSpeech.QUEUE_ADD, null, "dp$i") }
    }

    fun stopSpeak() = runOnUiThread { tts?.stop() }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    fun js(code: String) = runOnUiThread {
        webView.evaluateJavascript(code, null)
    }
}

/** Помогает понять, отладочная ли это сборка, без генерации BuildConfig. */
object BuildConfigHelper {
    fun isDebug(ctx: Context): Boolean =
        (ctx.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
}

/**
 * Методы, доступные из JavaScript как window.Android.*
 * Вызываются в фоновом потоке WebView.
 */
class Bridge(private val a: MainActivity) {

    private fun b64(s: String): ByteArray = Base64.decode(s, Base64.DEFAULT)

    @JavascriptInterface
    fun isAndroid(): Boolean = true

    @JavascriptInterface
    fun openDocument() = a.launchOpen(
        arrayOf(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
            "application/msword",
            "application/vnd.oasis.opendocument.text",
            "application/rtf", "text/rtf",
            "text/plain", "text/html", "text/markdown", "text/x-markdown",
            "application/pdf",
            "application/octet-stream",
            "*/*"
        )
    )

    /** Открыть ранее открытый файл (из списка недавних). */
    @JavascriptInterface
    fun reopen(uri: String) = a.deliverUri(Uri.parse(uri), "recent")

    /** Забрать содержимое файла в base64 (один раз). */
    @JavascriptInterface
    fun takeFile(id: Int): String {
        val bytes = a.pendingFiles.remove(id) ?: return ""
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    @JavascriptInterface
    fun saveAs(base64: String, name: String, mime: String, callbackId: String) =
        a.launchSaveAs(b64(base64), name, mime, callbackId)

    /** Перезаписать уже открытый файл. Возвращает true при успехе. */
    @JavascriptInterface
    fun saveToUri(uri: String, base64: String): Boolean = a.writeUri(Uri.parse(uri), b64(base64))

    @JavascriptInterface
    fun canWrite(uri: String): Boolean = a.canWrite(Uri.parse(uri))

    @JavascriptInterface
    fun printDocument(title: String) = a.printPage(title)

    @JavascriptInterface
    fun share(base64: String, name: String, mime: String) = a.shareBytes(b64(base64), name, mime)

    @JavascriptInterface
    fun shareText(text: String) = a.shareText(text)

    @JavascriptInterface
    fun getClipboardText(): String {
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(a).toString()
    }

    @JavascriptInterface
    fun getClipboardHtml(): String {
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).htmlText ?: ""
    }

    @JavascriptInterface
    fun setClipboard(text: String, html: String) {
        a.runOnUiThread {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = if (html.isNotEmpty()) ClipData.newHtmlText("DocPad", text, html)
            else ClipData.newPlainText("DocPad", text)
            cm.setPrimaryClip(clip)
        }
    }

    @JavascriptInterface
    fun setKeepScreenOn(on: Boolean) = a.setKeepScreenOn(on)

    @JavascriptInterface
    fun setFullscreen(on: Boolean) = a.setFullscreen(on)

    @JavascriptInterface
    fun setBarsColor(color: String, light: Boolean) = a.setBarsColor(color, light)

    @JavascriptInterface
    fun toast(msg: String) = a.toast(msg)

    @JavascriptInterface
    fun openUrl(url: String) = a.openExternal(url)

    @JavascriptInterface
    fun exitApp() = a.runOnUiThread { a.finish() }

    @JavascriptInterface
    fun speak(text: String, lang: String) = a.speak(text, lang)

    @JavascriptInterface
    fun stopSpeak() = a.stopSpeak()

    @JavascriptInterface
    fun appVersion(): String = try {
        val p = a.packageManager.getPackageInfo(a.packageName, 0)
        p.versionName ?: "1.0"
    } catch (_: Exception) {
        "1.0"
    }
}
