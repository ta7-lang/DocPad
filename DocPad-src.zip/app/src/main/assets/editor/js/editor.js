/* Ядро редактора: выделение, история правок, форматирование, таблицы, рисунки, поиск */
'use strict';
const Ed = (() => {
  const doc = document.getElementById('doc');
  const MARK = 'dp-mark-0x7f';
  const ZW = '​';
  const BLOCK_SEL = 'p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,td,th';
  let savedRange = null;
  let listeners = { change: [], selection: [] };
  let suppress = false;

  const on = (ev, fn) => listeners[ev].push(fn);
  const emit = (ev, ...a) => listeners[ev].forEach(f => { try { f(...a); } catch (e) { console.error(e); } });

  // ================= Выделение =================
  const inDoc = n => !!n && (n === doc || doc.contains(n));
  function range() {
    const s = getSelection();
    if (s.rangeCount) {
      const r = s.getRangeAt(0);
      if (inDoc(r.commonAncestorContainer)) return r;
    }
    return null;
  }
  function setRange(r) {
    const s = getSelection();
    s.removeAllRanges();
    s.addRange(r);
    savedRange = r.cloneRange();
  }
  function focus() {
    if (App.state && App.state.reading) return;
    const had = range();
    if (document.activeElement !== doc) doc.focus({ preventScroll: true });
    if (!had) {
      if (savedRange && inDoc(savedRange.startContainer)) setRange(savedRange);
      else { const r = document.createRange(); r.selectNodeContents(doc); r.collapse(false); setRange(r); }
    }
  }
  document.addEventListener('selectionchange', () => {
    const r = range();
    if (r) savedRange = r.cloneRange();
    if (!suppress) emit('selection');
  });
  const elOf = n => (n && n.nodeType === 1 ? n : n && n.parentElement);
  function blockOf(n) {
    let e = elOf(n);
    while (e && e !== doc) {
      if (e.matches(BLOCK_SEL) || (e.parentElement === doc && e.tagName === 'DIV')) return e;
      e = e.parentElement;
    }
    return null;
  }
  function caretEl() { const r = range() || savedRange; return r ? elOf(r.startContainer) : null; }

  /** Блоки (абзацы), затронутые выделением */
  function blocks(r = range() || savedRange) {
    if (!r) return [];
    const out = new Set();
    const b0 = blockOf(r.startContainer);
    if (b0) out.add(b0);
    if (!r.collapsed) {
      const w = document.createTreeWalker(doc, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (!r.intersectsNode(n)) continue;
        const b = blockOf(n);
        if (b) out.add(b);
      }
    }
    // если в выделении есть и li, и его вложенные абзацы — берём только самые внутренние
    return [...out].filter(b => !(b.tagName === 'TD' || b.tagName === 'TH') || out.size === 1);
  }

  // путь к узлу — для сохранения позиции курсора в истории
  function pathOf(node) {
    const p = [];
    while (node && node !== doc) { const par = node.parentNode; if (!par) return null; p.unshift([...par.childNodes].indexOf(node)); node = par; }
    return node === doc ? p : null;
  }
  function nodeAt(path) {
    let n = doc;
    for (const i of path) { if (!n.childNodes[i]) return null; n = n.childNodes[i]; }
    return n;
  }
  function serializeSel() {
    const r = range() || savedRange;
    if (!r || !inDoc(r.startContainer)) return null;
    const a = pathOf(r.startContainer), b = pathOf(r.endContainer);
    return a && b ? { a, ao: r.startOffset, b, bo: r.endOffset } : null;
  }
  function restoreSel(s) {
    if (!s) return;
    const a = nodeAt(s.a), b = nodeAt(s.b);
    if (!a || !b) return;
    try {
      const r = document.createRange();
      r.setStart(a, Math.min(s.ao, a.nodeType === 3 ? a.length : a.childNodes.length));
      r.setEnd(b, Math.min(s.bo, b.nodeType === 3 ? b.length : b.childNodes.length));
      setRange(r);
    } catch (e) {}
  }

  // ================= История (отмена/возврат) =================
  const Hist = (() => {
    let stack = [], idx = -1, timer = null;
    const MAX = 200, MAX_CHARS = 80e6;
    const snap = () => ({ html: doc.innerHTML, sel: serializeSel() });
    function trim() {
      let total = stack.reduce((s, x) => s + x.html.length, 0);
      while ((stack.length > MAX || total > MAX_CHARS) && stack.length > 2) { total -= stack[0].html.length; stack.shift(); idx--; }
    }
    function record() {
      clearTimeout(timer); timer = null;
      const s = snap();
      const top = stack[idx];
      if (top && top.html === s.html) { top.sel = s.sel; return false; }
      stack.length = idx + 1;
      stack.push(s); idx++;
      trim();
      return true;
    }
    function schedule() { clearTimeout(timer); timer = setTimeout(record, 700); }
    function apply(s) {
      doc.innerHTML = s.html;
      restoreSel(s.sel);
      afterChange(true);
    }
    function undo() { record(); if (idx > 0) { idx--; apply(stack[idx]); } }
    function redo() { if (timer) record(); if (idx < stack.length - 1) { idx++; apply(stack[idx]); } }
    function reset() { clearTimeout(timer); stack = [snap()]; idx = 0; }
    const canUndo = () => idx > 0 || !!timer;
    const canRedo = () => idx < stack.length - 1;
    return { record, schedule, undo, redo, reset, canUndo, canRedo };
  })();

  function afterChange(fromHistory) {
    emit('change', { fromHistory });
  }
  /** Выполнить изменение как один шаг истории */
  function run(fn, { keepFocus = true } = {}) {
    if (App.state && App.state.reading) { UI.toast('Режим чтения: редактирование выключено'); return; }
    if (keepFocus) focus();
    Hist.record();
    let res;
    try { res = fn(); } catch (e) { console.error(e); UI.toast('Ошибка: ' + e.message); }
    cleanup();
    Hist.record();
    afterChange();
    return res;
  }
  function exec(cmd, val = null, css = false) {
    return run(() => {
      document.execCommand('styleWithCSS', false, css);
      document.execCommand(cmd, false, val);
    });
  }
  const state = cmd => { try { return document.queryCommandState(cmd); } catch (e) { return false; } };

  // ================= Нормализация =================
  /** Исправляет недопустимую вложенность (список внутри абзаца, список прямо в списке),
      которую иногда создают встроенные команды браузера. Курсор сохраняется. */
  function fixStructure() {
    const bad = doc.querySelectorAll('p > ul, p > ol, p > table, p > div, p > h1, p > h2, p > h3, p > p, ul > ul, ul > ol, ol > ul, ol > ol, h1 > ul, h1 > ol');
    if (!bad.length) return;
    const r = range();
    const sel = r ? [r.startContainer, r.startOffset, r.endContainer, r.endOffset] : null;
    for (const el of bad) {
      const par = el.parentElement;
      if (!par || !doc.contains(par)) continue;
      if (/^(UL|OL)$/.test(par.tagName)) {
        const prev = el.previousElementSibling;
        if (prev && prev.tagName === 'LI') prev.append(el);
        else { const li = document.createElement('li'); el.before(li); li.append(el); }
        continue;
      }
      // разрезаем абзац вокруг блочного элемента
      const after = par.cloneNode(false);
      while (el.nextSibling) after.append(el.nextSibling);
      par.after(el);
      if (after.childNodes.length && (after.textContent.trim() || after.querySelector('img'))) el.after(after);
      if (!par.textContent.trim() && !par.querySelector('img')) par.remove();
    }
    if (sel && sel[0].isConnected && sel[2].isConnected) {
      try { const nr = document.createRange(); nr.setStart(sel[0], sel[1]); nr.setEnd(sel[2], sel[3]); setRange(nr); } catch (e) {}
    }
  }
  function cleanup() {
    fixStructure();
    // удаляем маркеры, которые могли остаться
    doc.querySelectorAll(`font[face="${MARK}"]`).forEach(f => f.replaceWith(...f.childNodes));
    // пустые span без стилей
    doc.querySelectorAll('span:not([class]):not([style]):not([data-id])').forEach(s => { if (!s.attributes.length) s.replaceWith(...s.childNodes); });
    if (!doc.firstChild) doc.innerHTML = '<p><br></p>';
  }
  /** Оборачивает «голый» текст верхнего уровня в абзацы (без учёта курсора — для загрузки документа) */
  function normalizeTop(root = doc) {
    let p = null;
    for (const n of [...root.childNodes]) {
      const inline = n.nodeType === 3 || (n.nodeType === 1 && /^(SPAN|B|I|U|S|STRONG|EM|A|FONT|SUB|SUP|IMG|BR|CODE|MARK|SMALL|BIG|STRIKE|DEL|INS|LABEL)$/.test(n.tagName));
      if (inline) {
        if (n.nodeType === 3 && !n.textContent.trim() && !p) { n.remove(); continue; }
        if (!p) { p = document.createElement('p'); n.before(p); }
        p.append(n);
      } else p = null;
    }
    if (!root.firstChild) root.innerHTML = '<p><br></p>';
  }

  // ================= Встроенное форматирование =================
  /** Оборачивает выделенный текст в span'ы, созданные make(). Возвращает созданные элементы. */
  function wrapInline(make, clearProps = []) {
    const r = range();
    if (!r) return [];
    if (r.collapsed) {
      const span = make();
      span.textContent = ZW;
      r.insertNode(span);
      const nr = document.createRange();
      nr.setStart(span.firstChild, 1); nr.collapse(true);
      setRange(nr);
      return [span];
    }
    document.execCommand('styleWithCSS', false, false);
    document.execCommand('fontName', false, MARK);
    const fonts = [...doc.querySelectorAll(`font[face="${MARK}"]`)];
    const spans = [];
    for (const f of fonts) {
      const span = make();
      if (clearProps.length) f.querySelectorAll('[style]').forEach(e => {
        clearProps.forEach(p => e.style.removeProperty(p));
        if (!e.getAttribute('style')) e.removeAttribute('style');
      });
      span.append(...f.childNodes);
      f.replaceWith(span);
      spans.push(span);
    }
    if (spans.length) {
      const nr = document.createRange();
      nr.setStart(spans[0], 0);
      const last = spans[spans.length - 1];
      nr.setEnd(last, last.childNodes.length);
      setRange(nr);
    }
    return spans;
  }
  /** Применить CSS-свойства к выделенному тексту: css({ 'font-size': '14pt' }) */
  function css(props) {
    return run(() => wrapInline(() => {
      const s = document.createElement('span');
      for (const [k, v] of Object.entries(props)) if (v != null && v !== '') s.style.setProperty(k, v);
      return s;
    }, Object.keys(props)));
  }
  const fontName = name => { css({ 'font-family': Fonts.css(name) }); recentFont(name); };
  const fontSize = pt => css({ 'font-size': pt + 'pt' });
  function recentFont(name) {
    const rf = Store.S().recentFonts.filter(x => x !== name);
    rf.unshift(name); Store.set('recentFonts', rf.slice(0, 8));
  }
  function color(c) { css({ color: c || 'inherit' }); }
  function highlight(c) { css({ 'background-color': c || 'transparent' }); }
  function growFont(dir) {
    const sizes = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];
    const cur = current().size;
    let next = dir > 0 ? sizes.find(s => s > cur + 0.01) || cur + 10 : [...sizes].reverse().find(s => s < cur - 0.01) || Math.max(1, cur - 1);
    fontSize(next);
  }
  function underlineStyle(style, col) {
    css({ 'text-decoration-line': 'underline', 'text-decoration-style': style, 'text-decoration-color': col || null });
  }
  function clearFormat() {
    run(() => {
      document.execCommand('removeFormat');
      blocks().forEach(b => {
        if (/^(LI|TD|TH)$/.test(b.tagName)) { b.removeAttribute('style'); return; }
        const p = document.createElement('p');
        p.append(...b.childNodes);
        b.replaceWith(p);
      });
      // снятие стилей у span внутри выделения
      const r = range();
      if (r) doc.querySelectorAll('span[style]').forEach(s => { if (r.intersectsNode(s)) s.removeAttribute('style'); });
    });
  }
  function changeCase(mode) {
    run(() => {
      const r = range();
      if (!r || r.collapsed) return UI.toast('Выделите текст');
      const nodes = textNodesIn(r, true);
      let all = nodes.map(n => n.textContent).join('');
      const conv = {
        upper: s => s.toLocaleUpperCase(),
        lower: s => s.toLocaleLowerCase(),
        title: s => s.toLocaleLowerCase().replace(/(^|[\s«"(\-–—])(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase()),
        sentence: s => s.toLocaleLowerCase().replace(/(^\s*|[.!?…]\s+)(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase()),
        toggle: s => [...s].map(c => c === c.toLocaleUpperCase() ? c.toLocaleLowerCase() : c.toLocaleUpperCase()).join('')
      }[mode];
      const res = conv(all);
      let i = 0;
      for (const n of nodes) { const L = n.textContent.length; n.textContent = res.slice(i, i + L); i += L; }
      const nr = document.createRange();
      nr.setStart(nodes[0], 0); const last = nodes[nodes.length - 1]; nr.setEnd(last, last.length);
      setRange(nr);
    });
  }
  /** Текстовые узлы внутри диапазона; split=true разрезает крайние узлы по границе выделения */
  function textNodesIn(r, split) {
    if (split) {
      if (r.endContainer.nodeType === 3 && r.endOffset < r.endContainer.length) r.endContainer.splitText(r.endOffset);
      if (r.startContainer.nodeType === 3 && r.startOffset > 0) {
        const t = r.startContainer.splitText(r.startOffset);
        r.setStart(t, 0);
      }
    }
    const out = [];
    const w = document.createTreeWalker(r.commonAncestorContainer.nodeType === 3 ? r.commonAncestorContainer.parentNode : r.commonAncestorContainer, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) if (r.intersectsNode(n) && n.length) out.push(n);
    return out;
  }

  // ================= Абзацы =================
  function blockStyle(fn) {
    run(() => {
      let bs = blocks();
      if (!bs.length) { document.execCommand('formatBlock', false, 'p'); bs = blocks(); }
      bs.forEach(fn);
    });
  }
  const STYLES = {
    normal: { tag: 'p', label: 'Обычный' },
    nospacing: { tag: 'p', cls: 'no-spacing', label: 'Без интервала' },
    h1: { tag: 'h1', label: 'Заголовок 1' }, h2: { tag: 'h2', label: 'Заголовок 2' }, h3: { tag: 'h3', label: 'Заголовок 3' },
    h4: { tag: 'h4', label: 'Заголовок 4' }, h5: { tag: 'h5', label: 'Заголовок 5' }, h6: { tag: 'h6', label: 'Заголовок 6' },
    title: { tag: 'p', cls: 'title', label: 'Название' }, subtitle: { tag: 'p', cls: 'subtitle', label: 'Подзаголовок' },
    quote: { tag: 'blockquote', label: 'Цитата' }, code: { tag: 'pre', label: 'Код' }
  };
  function applyStyle(key) {
    const st = STYLES[key];
    run(() => {
      let bs = blocks().filter(b => !/^(TD|TH)$/.test(b.tagName));
      if (bs.length && bs.every(b => b.tagName === 'LI')) {
        // в списке меняем только класс/вложенный абзац
        bs.forEach(b => b.className = st.cls || '');
        return;
      }
      document.execCommand('formatBlock', false, st.tag);
      bs = blocks();
      bs.forEach(b => {
        b.classList.remove('title', 'subtitle', 'no-spacing');
        if (st.cls) b.classList.add(st.cls);
        if (!b.className) b.removeAttribute('class');
      });
    });
  }
  function align(a) {
    blockStyle(b => { b.style.textAlign = a === 'left' ? '' : a; if (!b.getAttribute('style')) b.removeAttribute('style'); });
  }
  const lineHeight = v => blockStyle(b => b.style.lineHeight = v);
  const spacing = (before, after) => blockStyle(b => {
    if (before != null) b.style.marginTop = before + 'pt';
    if (after != null) b.style.marginBottom = after + 'pt';
  });
  function indent(dir) {
    const bs = blocks();
    if (bs.some(b => b.closest('li'))) return exec(dir > 0 ? 'indent' : 'outdent');
    blockStyle(b => {
      const cur = parseFloat(b.style.marginLeft) || 0;   // pt
      const next = Math.max(0, cur + dir * 35.4);         // шаг 1,25 см
      b.style.marginLeft = next ? next.toFixed(1) + 'pt' : '';
    });
  }
  function direction(dir) { blockStyle(b => { if (dir === 'ltr') b.removeAttribute('dir'); else b.setAttribute('dir', dir); }); }

  // ================= Списки =================
  function list(kind, type) {
    run(() => {
      const li = caretEl()?.closest('li');
      const cur = li?.parentElement;
      const want = kind === 'ol' ? 'OL' : 'UL';
      if (!cur || cur.tagName !== want) document.execCommand(kind === 'ol' ? 'insertOrderedList' : 'insertUnorderedList');
      else if (!type) { document.execCommand(kind === 'ol' ? 'insertOrderedList' : 'insertUnorderedList'); return; }
      const lst = caretEl()?.closest('ul,ol');
      if (lst) {
        lst.classList.remove('checklist');
        if (!lst.className) lst.removeAttribute('class');
        if (type) lst.style.listStyleType = type; else lst.style.removeProperty('list-style-type');
        if (!lst.getAttribute('style')) lst.removeAttribute('style');
      }
    });
  }
  function checklist() {
    run(() => {
      let lst = caretEl()?.closest('ul');
      if (!lst || !lst.classList.contains('checklist')) {
        if (!lst) document.execCommand('insertUnorderedList');
        lst = caretEl()?.closest('ul');
        lst && lst.classList.add('checklist');
      } else {
        document.execCommand('insertUnorderedList');
      }
    });
  }
  function startNumber(n) {
    const ol = caretEl()?.closest('ol');
    if (!ol) return UI.toast('Курсор должен быть в нумерованном списке');
    run(() => { if (n > 1) ol.setAttribute('start', n); else ol.removeAttribute('start'); });
  }

  // ================= Вставка =================
  function insertHTML(html) { return run(() => { document.execCommand('insertHTML', false, html); }); }
  function insertText(t) { return run(() => { document.execCommand('insertText', false, t); }); }
  function insertNodeBlock(node) {
    // вставка блочного элемента после текущего абзаца
    return run(() => {
      const b = blocks()[0];
      const top = b ? topLevel(b) : null;
      if (top) top.after(node); else doc.append(node);
      if (!node.nextSibling) node.after(h('p', null, h('br')));
      const r = document.createRange();
      r.selectNodeContents(node.nextSibling); r.collapse(true); setRange(r);
    });
  }
  function topLevel(n) { while (n && n.parentElement !== doc) n = n.parentElement; return n; }

  function pageBreak() {
    insertNodeBlock(h('div', { class: 'page-break', contenteditable: 'false' }));
  }
  function columnBreak() { insertNodeBlock(h('div', { class: 'col-break', contenteditable: 'false' })); }
  function hr() { insertNodeBlock(h('hr')); }

  function link(url, text) {
    run(() => {
      const r = range();
      const a0 = caretEl()?.closest('a');
      if (a0) { a0.href = url; if (text) a0.textContent = text; return; }
      if (r && !r.collapsed) document.execCommand('createLink', false, url);
      else document.execCommand('insertHTML', false, `<a href="${esc(url)}">${esc(text || url)}</a>&nbsp;`);
    });
  }
  function unlink() {
    run(() => {
      const a = caretEl()?.closest('a');
      if (a) a.replaceWith(...a.childNodes); else document.execCommand('unlink');
    });
  }

  // ================= Рисунки =================
  let selImg = null;
  function insertImage(src, width) {
    const style = width ? ` style="width:${Math.round(width)}px"` : '';
    insertHTML(`<img src="${src}"${style}>`);
  }
  function selectImage(img) {
    if (selImg && selImg !== img) selImg.classList.remove('dp-selected');
    selImg = img;
    if (img) img.classList.add('dp-selected');
    emit('selection');
    positionHandle();
  }
  function positionHandle() {
    const hd = document.getElementById('imgHandle');
    if (!selImg || !doc.contains(selImg) || App.state.reading) { hd.hidden = true; return; }
    const ws = document.getElementById('workspace');
    const r = selImg.getBoundingClientRect(), wr = ws.getBoundingClientRect();
    hd.hidden = false;
    hd.style.left = (r.right - wr.left + ws.scrollLeft - 14) + 'px';
    hd.style.top = (r.bottom - wr.top + ws.scrollTop - 14) + 'px';
  }
  function imageOp(fn) {
    if (!selImg) return UI.toast('Выберите рисунок (нажмите на него)');
    run(() => fn(selImg), { keepFocus: false });
    positionHandle();
  }
  function imageWidth(w) { imageOp(img => { img.style.width = typeof w === 'number' ? w + 'px' : w; img.style.height = ''; img.removeAttribute('width'); img.removeAttribute('height'); }); }
  function imageWrap(mode) {
    imageOp(img => {
      img.classList.remove('float-left', 'float-right', 'center');
      if (mode !== 'inline') img.classList.add(mode);
    });
  }
  function imageRotate() {
    imageOp(img => {
      const c = document.createElement('canvas');
      const w = img.naturalWidth, hgt = img.naturalHeight;
      c.width = hgt; c.height = w;
      const g = c.getContext('2d');
      g.translate(hgt / 2, w / 2); g.rotate(Math.PI / 2); g.drawImage(img, -w / 2, -hgt / 2);
      const curW = img.getBoundingClientRect().width / zoomFactor();
      img.src = c.toDataURL(/png/.test(img.src.slice(0, 30)) ? 'image/png' : 'image/jpeg', 0.92);
      img.style.width = Math.round(Math.min(curW * hgt / w, doc.clientWidth)) + 'px';
    });
  }
  function imageBorder(on) { imageOp(img => { img.style.border = on ? '1px solid #000' : ''; }); }
  function deleteImage() { imageOp(img => { img.remove(); }); selectImage(null); }
  const zoomFactor = () => parseFloat(getComputedStyle(document.getElementById('page')).zoom) || 1;

  // перетаскивание маркера размера
  (() => {
    const hd = document.getElementById('imgHandle');
    let start = null;
    hd.addEventListener('pointerdown', e => {
      if (!selImg) return;
      e.preventDefault();
      hd.setPointerCapture(e.pointerId);
      Hist.record();
      start = { x: e.clientX, w: selImg.getBoundingClientRect().width / zoomFactor() };
    });
    hd.addEventListener('pointermove', e => {
      if (!start || !selImg) return;
      const w = Math.max(20, Math.min(doc.clientWidth, start.w + (e.clientX - start.x) / zoomFactor()));
      selImg.style.width = Math.round(w) + 'px';
      selImg.style.height = '';
      positionHandle();
    });
    const end = () => { if (start) { start = null; Hist.record(); afterChange(); } };
    hd.addEventListener('pointerup', end);
    hd.addEventListener('pointercancel', end);
  })();

  // ================= Таблицы =================
  function cell() { const e = caretEl(); const c = e && e.closest('td,th'); return c && doc.contains(c) ? c : null; }
  function grid(t) {
    const G = [];
    [...t.rows].forEach((tr, r) => {
      G[r] = G[r] || [];
      let c = 0;
      for (const td of tr.cells) {
        while (G[r][c]) c++;
        for (let i = 0; i < (td.rowSpan || 1); i++)
          for (let j = 0; j < (td.colSpan || 1); j++) {
            G[r + i] = G[r + i] || [];
            G[r + i][c + j] = td;
          }
        c += td.colSpan || 1;
      }
    });
    return G;
  }
  function pos(G, td) {
    for (let r = 0; r < G.length; r++) { const c = G[r].indexOf(td); if (c >= 0) return { r, c }; }
    return { r: 0, c: 0 };
  }
  const newCell = (tag = 'td') => { const c = document.createElement(tag); c.innerHTML = '<br>'; return c; };
  function insertAtCol(tr, G, ri, col, el) {
    for (const td of tr.cells) { if (pos(G, td).c >= col) { tr.insertBefore(el, td); return; } }
    tr.appendChild(el);
  }
  function tableOp(fn) {
    const td = cell();
    if (!td) return UI.toast('Поставьте курсор в таблицу');
    run(() => fn(td, td.closest('table')));
  }
  function insertTable(rows, cols, opts = {}) {
    const borders = opts.borders === false ? '0' : '1';
    let html = `<table data-borders="${borders}" style="width:100%"><tbody>`;
    for (let r = 0; r < rows; r++) {
      html += '<tr>';
      for (let c = 0; c < cols; c++) html += '<td><br></td>';
      html += '</tr>';
    }
    html += '</tbody></table>';
    const t = document.createElement('template');
    t.innerHTML = html;
    const tbl = t.content.firstChild;
    insertNodeBlock(tbl);
    // курсор в первую ячейку
    const first = tbl.rows[0] && tbl.rows[0].cells[0];
    if (first) { const r = document.createRange(); r.selectNodeContents(first); r.collapse(true); setRange(r); }
  }
  function addRow(after) {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const at = after ? p.r + (td.rowSpan || 1) : p.r;
      const tr = document.createElement('tr');
      const ncols = Math.max(...G.map(r => r.length));
      const bumped = new Set();
      for (let c = 0; c < ncols; c++) {
        const occ = G[at] && G[at][c];
        if (occ && pos(G, occ).r < at) {
          if (!bumped.has(occ)) { occ.rowSpan = (occ.rowSpan || 1) + 1; bumped.add(occ); }
          continue;
        }
        tr.appendChild(newCell(G[p.r][c] && G[p.r][c].tagName === 'TH' && !after ? 'th' : 'td'));
      }
      const ref = t.rows[at];
      if (ref) ref.parentElement.insertBefore(tr, ref); else t.rows[t.rows.length - 1].parentElement.appendChild(tr);
    });
  }
  function addCol(after) {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const target = after ? p.c + (td.colSpan || 1) : p.c;
      const done = new Set();
      [...t.rows].forEach((tr, ri) => {
        const row = G[ri] || [];
        const occ = row[target];
        if (!occ) { tr.appendChild(newCell()); return; }
        if (done.has(occ)) return;
        const st = pos(G, occ);
        if (st.c === target) insertAtCol(tr, G, ri, target, newCell(occ.tagName.toLowerCase()));
        else { occ.colSpan = (occ.colSpan || 1) + 1; done.add(occ); }
      });
    });
  }
  function delRow() {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const tr = t.rows[p.r];
      const next = t.rows[p.r + 1];
      const seen = new Set();
      (G[p.r] || []).forEach((occ, c) => {
        if (!occ || seen.has(occ)) return;
        seen.add(occ);
        const st = pos(G, occ);
        if ((occ.rowSpan || 1) > 1) {
          occ.rowSpan--;
          if (st.r === p.r && next) insertAtCol(next, G, p.r + 1, st.c, occ);
        }
      });
      tr.remove();
      if (!t.rows.length) t.remove();
    });
  }
  function delCol() {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const seen = new Set();
      G.forEach(row => {
        const occ = row[p.c];
        if (!occ || seen.has(occ)) return;
        seen.add(occ);
        if ((occ.colSpan || 1) > 1) occ.colSpan--; else occ.remove();
      });
      [...t.rows].forEach(tr => { if (!tr.cells.length) tr.remove(); });
      if (!t.rows.length) t.remove();
    });
  }
  function delTable() { tableOp((td, t) => { const p = h('p', null, h('br')); t.replaceWith(p); }); }
  const isEmptyCell = c => !c.textContent.trim() && !c.querySelector('img');
  function mergeRight() {
    tableOp(td => {
      const nx = td.nextElementSibling;
      if (!nx) return UI.toast('Справа нет ячейки');
      if (!isEmptyCell(nx)) { if (isEmptyCell(td)) td.innerHTML = ''; else td.append(h('br')); td.append(...nx.childNodes); }
      td.colSpan = (td.colSpan || 1) + (nx.colSpan || 1);
      nx.remove();
    });
  }
  function mergeDown() {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const below = G[p.r + (td.rowSpan || 1)] && G[p.r + (td.rowSpan || 1)][p.c];
      if (!below || pos(G, below).c !== p.c || (below.colSpan || 1) !== (td.colSpan || 1)) return UI.toast('Снизу нет подходящей ячейки');
      if (!isEmptyCell(below)) { if (isEmptyCell(td)) td.innerHTML = ''; else td.append(h('br')); td.append(...below.childNodes); }
      td.rowSpan = (td.rowSpan || 1) + (below.rowSpan || 1);
      below.remove();
    });
  }
  function splitCell() {
    tableOp((td, t) => {
      const G = grid(t);
      const p = pos(G, td);
      const cs = td.colSpan || 1, rs = td.rowSpan || 1;
      for (let i = 1; i < cs; i++) td.after(newCell(td.tagName.toLowerCase()));
      td.colSpan = 1;
      for (let r = 1; r < rs; r++) {
        const tr = t.rows[p.r + r];
        for (let j = cs - 1; j >= 0; j--) insertAtCol(tr, G, p.r + r, p.c + j, newCell());
      }
      td.rowSpan = 1;
      if (cs === 1 && rs === 1) {
        // разбить одиночную ячейку на две по горизонтали
        td.after(newCell());
        const G2 = grid(t);
        const p2 = pos(G2, td);
        [...t.rows].forEach((tr, ri) => {
          if (ri === p.r) return;
          const occ = G2[ri][p2.c];
          if (occ && !occ.__b) { occ.colSpan = (occ.colSpan || 1) + 1; occ.__b = 1; }
        });
        t.querySelectorAll('td,th').forEach(c => delete c.__b);
      }
    });
  }
  function headerRow() {
    tableOp((td, t) => {
      const tr = t.rows[0];
      const toTh = tr.cells[0].tagName === 'TD';
      [...tr.cells].forEach(c => {
        const n = document.createElement(toTh ? 'th' : 'td');
        for (const a of c.attributes) n.setAttribute(a.name, a.value);
        n.append(...c.childNodes);
        c.replaceWith(n);
      });
    });
  }
  const tableBorders = on => tableOp((td, t) => t.dataset.borders = on ? '1' : '0');
  const cellColor = c => tableOp(td => { td.style.backgroundColor = c || ''; });
  const cellVAlign = v => tableOp(td => { td.style.verticalAlign = v; });
  const tableWidth = w => tableOp((td, t) => { t.style.width = w; });
  const tableAlign = a => tableOp((td, t) => {
    t.style.marginLeft = a === 'left' ? '' : 'auto';
    t.style.marginRight = a === 'right' ? '' : (a === 'center' ? 'auto' : '');
  });
  const tablePreset = p => tableOp((td, t) => {
    t.classList.remove('zebra', 'blue-head');
    if (p === 'grid') t.dataset.borders = '1';
    if (p === 'none') t.dataset.borders = '0';
    if (p === 'zebra') { t.dataset.borders = '1'; t.classList.add('zebra'); }
    if (p === 'blue') { t.dataset.borders = '1'; t.classList.add('blue-head'); }
    if (!t.className) t.removeAttribute('class');
  });
  const distribute = () => tableOp((td, t) => { t.querySelectorAll('td,th,col').forEach(c => { c.style.width = ''; c.removeAttribute('width'); }); t.style.tableLayout = 'fixed'; });
  const autofit = () => tableOp((td, t) => { t.style.tableLayout = ''; t.querySelectorAll('td,th').forEach(c => { c.style.width = ''; c.removeAttribute('width'); }); });
  function sortTable(desc, hasHeader) {
    tableOp((td, t) => {
      const G = grid(t);
      const col = pos(G, td).c;
      const rows = [...t.rows];
      const head = hasHeader ? rows.shift() : null;
      if (rows.some(r => [...r.cells].some(c => (c.rowSpan || 1) > 1))) return UI.toast('Нельзя сортировать таблицу с объединёнными по вертикали ячейками');
      const key = r => { const g = grid(t); const ri = [...t.rows].indexOf(r); const c = g[ri] && g[ri][col]; return c ? c.textContent.trim() : ''; };
      const keys = new Map(rows.map(r => [r, key(r)]));
      const coll = new Intl.Collator(Store.S().lang, { numeric: true, sensitivity: 'base' });
      rows.sort((a, b) => {
        const x = keys.get(a), y = keys.get(b);
        const nx = parseFloat(x.replace(',', '.').replace(/\s/g, '')), ny = parseFloat(y.replace(',', '.').replace(/\s/g, ''));
        const res = !isNaN(nx) && !isNaN(ny) ? nx - ny : coll.compare(x, y);
        return desc ? -res : res;
      });
      const body = (head || rows[0]).parentElement;
      rows.forEach(r => body.appendChild(r));
    });
  }
  /** Переход по ячейкам клавишей Tab */
  function nextCell(back) {
    const td = cell();
    if (!td) return false;
    const all = [...td.closest('table').querySelectorAll('td,th')].filter(c => c.closest('table') === td.closest('table'));
    let i = all.indexOf(td) + (back ? -1 : 1);
    if (i >= all.length) { addRow(true); i = all.length; }
    const t2 = [...td.closest('table').querySelectorAll('td,th')];
    const target = t2[Math.max(0, i)];
    if (target) { const r = document.createRange(); r.selectNodeContents(target); setRange(r); }
    return true;
  }

  // ================= Оглавление, сноски, примечания =================
  function headings() { return [...doc.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(x => !x.closest('.toc')); }
  function ensureId(el) { if (!el.id) el.id = 'h-' + Math.random().toString(36).slice(2, 9); return el.id; }
  function buildToc(pageOf) {
    const box = h('div', { class: 'toc', contenteditable: 'false' }, h('div', { class: 'toc-title', text: 'Оглавление' }));
    for (const hd of headings()) {
      const lvl = +hd.tagName[1];
      if (lvl > 3) continue;
      box.append(h('div', { class: 'l' + lvl }, h('a', { href: '#' + ensureId(hd) }, h('span', { class: 't', text: hd.textContent.trim() || '…' }), h('span', { class: 'n', text: pageOf ? pageOf(hd) : '' }))));
    }
    if (box.children.length === 1) box.append(h('div', { class: 'hint', text: 'Нет заголовков. Примените стили «Заголовок 1–3» к разделам документа.' }));
    return box;
  }
  function insertToc(pageOf) {
    const old = doc.querySelector('.toc');
    if (old) return run(() => old.replaceWith(buildToc(pageOf)));
    insertNodeBlock(buildToc(pageOf));
  }
  function updateToc(pageOf) {
    const old = doc.querySelector('.toc');
    if (!old) return UI.toast('В документе нет оглавления');
    run(() => old.replaceWith(buildToc(pageOf)), { keepFocus: false });
  }
  function footnote(text) {
    run(() => {
      const id = 'fn' + Math.random().toString(36).slice(2, 8);
      const sup = h('sup', { class: 'fn', 'data-fn': id, contenteditable: 'false', text: '*' });
      const r = range();
      r.collapse(false);
      r.insertNode(sup);
      const nr = document.createRange(); nr.setStartAfter(sup); nr.collapse(true); setRange(nr);
      let box = doc.querySelector('.footnotes');
      if (!box) { box = h('div', { class: 'footnotes' }, h('ol')); doc.append(box); }
      box.querySelector('ol').append(h('li', { id, text: text || ' ' }));
      renumberFootnotes();
    });
  }
  function renumberFootnotes() {
    const box = doc.querySelector('.footnotes');
    const sups = [...doc.querySelectorAll('sup.fn')];
    if (!box) return;
    const ol = box.querySelector('ol');
    sups.forEach((s, i) => {
      s.textContent = i + 1;
      const li = ol.querySelector('#' + CSS.escape(s.dataset.fn));
      if (li) ol.appendChild(li);
    });
    // удаляем сноски без ссылок
    [...ol.children].forEach(li => { if (!doc.querySelector(`sup.fn[data-fn="${li.id}"]`)) li.remove(); });
    if (!ol.children.length) box.remove();
  }
  function addComment(text) {
    const id = 'c' + Date.now().toString(36);
    const author = Store.S().author || 'Автор';
    run(() => {
      const r = range();
      if (!r || r.collapsed) {
        // без выделения — выделяем слово под курсором
        const sel = getSelection();
        sel.modify('move', 'backward', 'word'); sel.modify('extend', 'forward', 'word');
      }
      wrapInline(() => h('span', { class: 'dp-comment', 'data-id': id, 'data-text': text, 'data-author': author, 'data-date': new Date().toISOString() }));
    });
  }
  function comments() {
    const m = new Map();
    doc.querySelectorAll('.dp-comment').forEach(s => {
      if (!m.has(s.dataset.id)) m.set(s.dataset.id, { id: s.dataset.id, text: s.dataset.text, author: s.dataset.author, date: s.dataset.date, el: s, quote: '' });
      m.get(s.dataset.id).quote += s.textContent;
    });
    return [...m.values()];
  }
  function removeComment(id) {
    run(() => doc.querySelectorAll(`.dp-comment[data-id="${id}"]`).forEach(s => s.replaceWith(...s.childNodes)), { keepFocus: false });
  }

  // ================= Поиск и замена =================
  const Find = (() => {
    let matches = [], cur = -1, opts = { q: '', cs: false, ww: false, re: false };
    const hl = () => window.CSS && CSS.highlights;
    function build() {
      matches = []; cur = -1;
      if (hl()) { CSS.highlights.delete('search'); CSS.highlights.delete('search-cur'); }
      if (!opts.q) return 0;
      const nodes = []; let text = ''; let lastBlock = null;
      const w = document.createTreeWalker(doc, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        const b = blockOf(n);
        if (lastBlock && b !== lastBlock) text += '\n';
        lastBlock = b;
        nodes.push({ n, start: text.length });
        text += n.data;
      }
      let rx;
      try {
        let src = opts.re ? opts.q : opts.q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        if (opts.ww) src = `(?<![\\p{L}\\p{N}_])(?:${src})(?![\\p{L}\\p{N}_])`;
        rx = new RegExp(src, 'gu' + (opts.cs ? '' : 'i'));
      } catch (e) { return -1; }
      const locate = off => {
        let lo = 0, hi = nodes.length - 1;
        while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (nodes[mid].start <= off) lo = mid; else hi = mid - 1; }
        return nodes[lo];
      };
      let m;
      while ((m = rx.exec(text))) {
        if (!m[0].length) { rx.lastIndex++; continue; }
        const a = locate(m.index), b = locate(m.index + m[0].length - 1);
        const r = document.createRange();
        r.setStart(a.n, m.index - a.start);
        r.setEnd(b.n, m.index + m[0].length - b.start);
        matches.push({ r, text: m[0], groups: m });
        if (matches.length > 5000) break;
      }
      if (hl() && matches.length) CSS.highlights.set('search', new Highlight(...matches.map(x => x.r)));
      return matches.length;
    }
    function go(dir) {
      if (!matches.length) return;
      // ближайшее совпадение после курсора
      if (cur < 0) {
        const r0 = range() || savedRange;
        cur = 0;
        if (r0) { const i = matches.findIndex(m => m.r.compareBoundaryPoints(Range.START_TO_START, r0) >= 0); cur = i < 0 ? 0 : i; if (dir < 0) cur = (cur - 1 + matches.length) % matches.length; }
      } else cur = (cur + dir + matches.length) % matches.length;
      const m = matches[cur];
      if (hl()) CSS.highlights.set('search-cur', new Highlight(m.r));
      const rect = m.r.getBoundingClientRect();
      const ws = document.getElementById('workspace');
      const wr = ws.getBoundingClientRect();
      if (rect.top < wr.top + 40 || rect.bottom > wr.bottom - 40) ws.scrollTop += rect.top - wr.top - wr.height / 3;
      savedRange = m.r.cloneRange();
    }
    function replaceOne(rep) {
      if (cur < 0 || !matches[cur]) { go(1); return; }
      const m = matches[cur];
      run(() => {
        setRange(m.r);
        const out = opts.re ? m.text.replace(new RegExp(opts.q, opts.cs ? 'u' : 'iu'), rep) : rep;
        document.execCommand('insertText', false, out);
      });
      const keep = cur;
      build(); cur = Math.min(keep, matches.length) - 1; go(1);
    }
    function replaceAll(rep) {
      if (!matches.length) return 0;
      const n = matches.length;
      run(() => {
        for (let i = matches.length - 1; i >= 0; i--) {
          const m = matches[i];
          const out = opts.re ? m.text.replace(new RegExp(opts.q, opts.cs ? 'u' : 'iu'), rep) : rep;
          m.r.deleteContents();
          if (out) m.r.insertNode(document.createTextNode(out));
        }
        doc.normalize();
      }, { keepFocus: false });
      build();
      return n;
    }
    function clear() { opts.q = ''; build(); }
    return { set: o => { Object.assign(opts, o); return build(); }, go, replaceOne, replaceAll, clear, info: () => ({ n: matches.length, cur }), rebuild: build };
  })();

  // ================= Состояние для ленты =================
  function current() {
    const e = caretEl() || doc;
    const cs = getComputedStyle(e);
    const b = blockOf(e);
    const bcs = b ? getComputedStyle(b) : cs;
    let st = 'normal';
    if (b) {
      const t = b.tagName.toLowerCase();
      if (/^h[1-6]$/.test(t)) st = t;
      else if (t === 'blockquote' || b.closest('blockquote')) st = 'quote';
      else if (t === 'pre') st = 'code';
      else if (b.classList.contains('title')) st = 'title';
      else if (b.classList.contains('subtitle')) st = 'subtitle';
      else if (b.classList.contains('no-spacing')) st = 'nospacing';
    }
    let al = bcs.textAlign;
    if (al === 'start' || al === '-webkit-auto') al = 'left';
    if (al === 'end') al = 'right';
    const list = e.closest('ul,ol');
    return {
      font: Fonts.first(cs.fontFamily),
      size: Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2,
      bold: state('bold'), italic: state('italic'), underline: state('underline'), strike: state('strikeThrough'),
      sub: state('subscript'), sup: state('superscript'),
      style: st, align: al,
      ul: !!(list && list.tagName === 'UL' && !list.classList.contains('checklist')), ol: !!(list && list.tagName === 'OL'),
      checklist: !!(list && list.classList.contains('checklist')),
      inTable: !!cell(), inLink: !!e.closest('a'),
      image: selImg && doc.contains(selImg) ? selImg : null,
      lineHeight: bcs.lineHeight, color: cs.color
    };
  }

  // ================= Вставка из буфера =================
  const ALLOWED = new Set(['P', 'BR', 'B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'DEL', 'INS', 'SUB', 'SUP', 'SPAN', 'A', 'UL', 'OL', 'LI',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'PRE', 'CODE', 'TABLE', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'TD', 'TH', 'IMG', 'HR', 'DIV', 'FONT', 'MARK', 'SMALL', 'COLGROUP', 'COL', 'CAPTION']);
  const STYLE_OK = /^(font-family|font-size|font-weight|font-style|text-decoration.*|color|background-color|background|text-align|margin-left|margin-top|margin-bottom|text-indent|line-height|vertical-align|width|height|border.*|padding.*|text-transform|letter-spacing|list-style-type|font-variant)$/;
  function sanitize(html) {
    const t = document.createElement('template');
    t.innerHTML = html.replace(/<!--[\s\S]*?-->/g, '');
    const walk = el => {
      for (const n of [...el.childNodes]) {
        if (n.nodeType === 8) { n.remove(); continue; }
        if (n.nodeType !== 1) continue;
        if (/^(SCRIPT|STYLE|META|LINK|TITLE|IFRAME|OBJECT|EMBED|svg|XML|NOSCRIPT|BUTTON|INPUT|SELECT|TEXTAREA|FORM)$/i.test(n.tagName) || n.tagName.includes(':')) { n.remove(); continue; }
        walk(n);
        if (!ALLOWED.has(n.tagName)) { n.replaceWith(...n.childNodes); continue; }
        if (n.tagName === 'FONT') {
          const s = document.createElement('span');
          if (n.getAttribute('face')) s.style.fontFamily = n.getAttribute('face');
          if (n.getAttribute('color')) s.style.color = n.getAttribute('color');
          s.append(...n.childNodes); n.replaceWith(s); continue;
        }
        for (const a of [...n.attributes]) {
          const nm = a.name.toLowerCase();
          if (nm === 'style') {
            const keep = [];
            for (const decl of a.value.split(';')) {
              const [k, ...v] = decl.split(':');
              if (!k || !v.length) continue;
              const key = k.trim().toLowerCase();
              if (STYLE_OK.test(key) && !/mso-|expression|url\(/i.test(v.join(':'))) keep.push(key + ':' + v.join(':').trim());
            }
            if (keep.length) n.setAttribute('style', keep.join(';')); else n.removeAttribute('style');
          } else if (nm === 'href' && n.tagName === 'A') {
            if (/^\s*javascript:/i.test(a.value)) n.removeAttribute('href');
          } else if (nm === 'src' && n.tagName === 'IMG') {
            if (!/^data:image\//.test(a.value) && !/^https?:/.test(a.value)) n.remove();
          } else if (!['colspan', 'rowspan', 'start', 'type', 'width', 'height', 'data-borders', 'class', 'alt', 'data-checked', 'id'].includes(nm)) n.removeAttribute(a.name);
          else if (nm === 'class' && !/^(title|subtitle|no-spacing|checklist|zebra|blue-head|page-break|float-left|float-right|center|toc|dp-comment)$/.test(a.value)) n.removeAttribute('class');
        }
        if (n.tagName === 'TABLE' && !n.dataset.borders) n.dataset.borders = '1';
      }
    };
    walk(t.content);
    const d = document.createElement('div');
    d.append(t.content);
    return d.innerHTML;
  }
  function pasteData(html, text, plain) {
    if (plain || !html) {
      if (!text) return;
      const lines = text.replace(/\r\n?/g, '\n').split('\n');
      if (lines.length === 1) insertText(text);
      else insertHTML(lines.map(l => `<p>${esc(l) || '<br>'}</p>`).join(''));
    } else insertHTML(sanitize(html));
  }

  // ================= События редактора =================
  doc.addEventListener('paste', e => {
    const cd = e.clipboardData;
    if (!cd) return;
    e.preventDefault();
    const files = [...cd.files].filter(f => f.type.startsWith('image/'));
    if (files.length) { files.forEach(f => App.readImageFile(f)); return; }
    pasteData(cd.getData('text/html'), cd.getData('text/plain'), Store.S().pastePlain);
  });
  doc.addEventListener('drop', e => {
    const files = [...(e.dataTransfer?.files || [])].filter(f => f.type.startsWith('image/'));
    if (files.length) { e.preventDefault(); files.forEach(f => App.readImageFile(f)); }
  });
  doc.addEventListener('input', () => {
    fixStructure();
    if (App.state.findOpen) Find.rebuild();
    Hist.schedule();
    afterChange();
  });
  doc.addEventListener('beforeinput', e => {
    if (e.inputType === 'historyUndo') { e.preventDefault(); Hist.undo(); return; }
    if (e.inputType === 'historyRedo') { e.preventDefault(); Hist.redo(); return; }
    if (App.state.reading) { e.preventDefault(); return; }
    // если курсор не внутри абзаца — сначала создаём абзац
    if (e.inputType.startsWith('insert')) {
      const r = range();
      if (r && r.collapsed && !blockOf(r.startContainer)) document.execCommand('formatBlock', false, 'p');
    }
    // «умные» кавычки и тире
    if (e.inputType === 'insertText' && e.data && Store.S().smartQuotes) {
      const r = range();
      if (!r || !r.collapsed) return;
      const prev = r.startContainer.nodeType === 3 ? r.startContainer.data.slice(0, r.startOffset) : '';
      const ru = Store.S().lang !== 'en';
      const open = !prev || /[\s(\[{«„“ —–-]$/.test(prev);
      let rep = null;
      if (e.data === '"') rep = ru ? (open ? '«' : '»') : (open ? '“' : '”');
      else if (e.data === "'" && !ru) rep = open ? '‘' : '’';
      else if (e.data === ' ' && /\s--?$/.test(prev)) {
        e.preventDefault();
        const n = r.startContainer, k = prev.endsWith('--') ? 2 : 1;
        const rr = document.createRange(); rr.setStart(n, r.startOffset - k); rr.setEnd(n, r.startOffset); setRange(rr);
        document.execCommand('insertText', false, '— ');
        return;
      }
      if (rep) { e.preventDefault(); document.execCommand('insertText', false, rep); }
    }
  });
  doc.addEventListener('keydown', e => {
    if (e.key === 'Tab') {
      e.preventDefault();
      if (cell()) { nextCell(e.shiftKey); return; }
      if (caretEl()?.closest('li')) { exec(e.shiftKey ? 'outdent' : 'indent'); return; }
      if (!e.shiftKey) insertText('\t');
    }
  });
  doc.addEventListener('click', e => {
    const img = e.target.closest('img');
    if (img && doc.contains(img)) { selectImage(img); return; }
    if (selImg) selectImage(null);
    const li = e.target.closest('ul.checklist > li');
    if (li && e.clientX - li.getBoundingClientRect().left < 24) {
      run(() => { li.dataset.checked = li.dataset.checked === '1' ? '0' : '1'; }, { keepFocus: false });
      return;
    }
    const fn = e.target.closest('sup.fn');
    if (fn) { const t = doc.querySelector('#' + CSS.escape(fn.dataset.fn)); t && t.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
    const a = e.target.closest('a');
    if (a && a.closest('.toc')) {
      e.preventDefault();
      const t = doc.querySelector(a.getAttribute('href'));
      t && t.scrollIntoView({ block: 'start', behavior: 'smooth' });
      return;
    }
    if (a && (App.state.reading || e.ctrlKey)) { e.preventDefault(); App.openLink(a.getAttribute('href')); return; }
    if (a) App.linkPopup(a);
    const cm = e.target.closest('.dp-comment');
    if (cm) App.commentPopup(cm);
  });
  document.getElementById('workspace').addEventListener('scroll', positionHandle, { passive: true });

  // ================= Загрузка / выгрузка =================
  function setHTML(html) {
    try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}
    doc.innerHTML = html || '<p><br></p>';
    normalizeTop();
    fixStructure();
    doc.querySelectorAll('.page-break,.col-break,.toc,sup.fn').forEach(x => x.setAttribute('contenteditable', 'false'));
    selImg = null;
    savedRange = null;
    Hist.reset();
    afterChange(true);
  }
  /** HTML документа без служебной разметки */
  function getHTML() {
    const c = doc.cloneNode(true);
    c.querySelectorAll('.dp-selected').forEach(x => x.classList.remove('dp-selected'));
    c.querySelectorAll('[class=""]').forEach(x => x.removeAttribute('class'));
    let s = c.innerHTML.replace(/​/g, '');
    return s;
  }
  function text() { return doc.innerText.replace(/​/g, ''); }
  function selectedText() { const r = range(); return r ? r.toString() : ''; }
  function stats(selOnly) {
    const t = selOnly ? selectedText() : text();
    const words = (t.match(/[\p{L}\p{N}][\p{L}\p{N}'’\-]*/gu) || []).length;
    return {
      words,
      chars: t.replace(/\n/g, '').length,
      charsNoSpaces: t.replace(/\s/g, '').length,
      paragraphs: selOnly ? t.split(/\n+/).filter(x => x.trim()).length : [...doc.querySelectorAll('p,h1,h2,h3,h4,h5,h6,li,blockquote,pre')].filter(x => x.textContent.trim()).length,
      lines: t.split('\n').length
    };
  }

  return {
    doc, on, range, setRange, focus, blocks, blockOf, caretEl, run, exec, css, fontName, fontSize, color, highlight, growFont,
    underlineStyle, clearFormat, changeCase, applyStyle, STYLES, align, lineHeight, spacing, indent, direction, list, checklist, startNumber,
    insertHTML, insertText, insertNodeBlock, pageBreak, columnBreak, hr, link, unlink, insertImage, selectImage, imageWidth, imageWrap,
    imageRotate, imageBorder, deleteImage, positionHandle, insertTable, addRow, addCol, delRow, delCol, delTable, mergeRight, mergeDown,
    splitCell, headerRow, tableBorders, cellColor, cellVAlign, tableWidth, tableAlign, tablePreset, distribute, autofit, sortTable, cell,
    headings, ensureId, insertToc, updateToc, footnote, renumberFootnotes, addComment, comments, removeComment, Find, current, sanitize,
    pasteData, setHTML, getHTML, text, selectedText, stats, Hist, normalizeTop, wrapInline, blockStyle, textNodesIn,
    get selImg() { return selImg && doc.contains(selImg) ? selImg : null },
    get savedRange() { return savedRange; }
  };
})();
