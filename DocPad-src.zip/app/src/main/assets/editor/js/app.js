/* DocPad — главный модуль: лента, команды, диалоги, файлы, настройки */
'use strict';
const App = (() => {
  const S = () => Store.S();
  const isAndroid = !!(window.Android && Android.isAndroid);
  const state = {
    meta: null, file: { name: 'Документ', uri: null, format: 'docx', canWrite: false }, dirty: false,
    reading: false, findOpen: false, tab: 'home', ribbonShown: true, ctxTab: null, painter: null, pdfName: null
  };
  const app = $('#app');

  // ===================================================================
  //                               КОМАНДЫ
  // ===================================================================
  const C = {};
  const cmd = (id, o) => { C[id] = Object.assign({ id }, o); };
  const glyph = (t, style = '') => `<span class="glyph" style="${style}">${t}</span>`;

  // --- Файл / общие ---
  cmd('backstage', { label: 'Файл', icon: 'menu', run: () => openBackstage() });
  cmd('undo', { label: 'Отменить', icon: 'undo', run: () => Ed.Hist.undo(), enabled: () => Ed.Hist.canUndo() });
  cmd('redo', { label: 'Вернуть', icon: 'redo', run: () => Ed.Hist.redo(), enabled: () => Ed.Hist.canRedo() });
  cmd('save', { label: 'Сохранить', icon: 'save', run: () => save() });
  cmd('saveAs', { label: 'Сохранить как', icon: 'saveas', run: () => saveAs() });
  cmd('newDoc', { label: 'Создать', icon: 'newdoc', run: () => newDocDialog() });
  cmd('open', { label: 'Открыть', icon: 'open', run: () => openFile() });
  cmd('print', { label: 'Печать', icon: 'print', run: () => print() });
  cmd('exportPdf', { label: 'PDF', icon: 'pdf', run: () => print(true) });
  cmd('share', { label: 'Поделиться', icon: 'share', run: () => shareDialog() });
  cmd('settings', { label: 'Настройки', icon: 'gear', run: () => settingsDialog() });
  cmd('readMode', { label: 'Чтение', icon: 'book', run: () => setReading(!state.reading), active: () => state.reading });
  cmd('toggleRibbon', { label: 'Лента', icon: 'chevUp', run: () => toggleRibbon() });
  cmd('properties', { label: 'Свойства', icon: 'info', run: () => propertiesDialog() });

  // --- Главная ---
  cmd('paste', { label: 'Вставить', icon: 'paste', run: () => pasteFromClipboard(false) });
  cmd('pastePlain', { label: 'Как текст', icon: 'pastePlain', run: () => pasteFromClipboard(true) });
  cmd('cut', { label: 'Вырезать', icon: 'cut', run: () => { copySel(); Ed.exec('delete'); } });
  cmd('copy', { label: 'Копировать', icon: 'copy', run: () => { copySel(); UI.toast('Скопировано'); } });
  cmd('formatPainter', { label: 'Формат по образцу', icon: 'brush', run: () => startPainter(), active: () => !!state.painter });
  cmd('selectAll', { label: 'Выделить всё', icon: 'selectAll', run: () => { Ed.focus(); const r = document.createRange(); r.selectNodeContents(Ed.doc); Ed.setRange(r); } });
  cmd('font', { label: 'Шрифт', kind: 'combo', cls: 'font', value: c => c.font, run: b => fontPicker(b) });
  cmd('size', { label: 'Размер', kind: 'combo', cls: 'size', value: c => c.size, run: b => sizePicker(b) });
  cmd('grow', { label: 'Увеличить', icon: 'grow', run: () => Ed.growFont(1) });
  cmd('shrink', { label: 'Уменьшить', icon: 'shrink', run: () => Ed.growFont(-1) });
  cmd('textCase', { label: 'Регистр', icon: 'textCase', run: b => UI.menu(b, [
    { label: 'Как в предложениях.', action: () => Ed.changeCase('sentence') }, { label: 'все строчные', action: () => Ed.changeCase('lower') },
    { label: 'ВСЕ ПРОПИСНЫЕ', action: () => Ed.changeCase('upper') }, { label: 'Начинать С Прописных', action: () => Ed.changeCase('title') },
    { label: 'иЗМЕНИТЬ рЕГИСТР', action: () => Ed.changeCase('toggle') }]) });
  cmd('clearFormat', { label: 'Очистить формат', icon: 'clearFmt', run: () => Ed.clearFormat() });
  cmd('bold', { label: 'Жирный', html: glyph('Ж', 'font-weight:700;font-family:Arial,sans-serif'), run: () => Ed.exec('bold'), active: c => c.bold });
  cmd('italic', { label: 'Курсив', html: glyph('К', 'font-style:italic;font-family:Georgia,serif'), run: () => Ed.exec('italic'), active: c => c.italic });
  cmd('underline', { label: 'Подчёркнутый', html: glyph('Ч', 'text-decoration:underline;font-family:Arial,sans-serif'), run: () => Ed.exec('underline'), active: c => c.underline,
    menu: b => UI.menu(b, [
      { label: 'Одинарное', action: () => Ed.underlineStyle('solid') }, { label: 'Двойное', action: () => Ed.underlineStyle('double'), style: 'text-decoration:underline double' },
      { label: 'Точечное', action: () => Ed.underlineStyle('dotted'), style: 'text-decoration:underline dotted' }, { label: 'Штриховое', action: () => Ed.underlineStyle('dashed'), style: 'text-decoration:underline dashed' },
      { label: 'Волнистое', action: () => Ed.underlineStyle('wavy'), style: 'text-decoration:underline wavy' }, { sep: true },
      { label: 'Цвет подчёркивания…', action: () => UI.palette(b, c => Ed.underlineStyle('solid', c)) }]) });
  cmd('strike', { label: 'Зачёркнутый', html: glyph('abc', 'text-decoration:line-through;font-size:15px;font-family:Arial,sans-serif'), run: () => Ed.exec('strikeThrough'), active: c => c.strike });
  cmd('sub', { label: 'Подстрочный', icon: 'subText', run: () => Ed.exec('subscript'), active: c => c.sub });
  cmd('sup', { label: 'Надстрочный', icon: 'superText', run: () => Ed.exec('superscript'), active: c => c.sup });
  let lastColor = '#C00000', lastHl = '#FFFF00';
  cmd('fontColor', { label: 'Цвет текста', icon: 'fontColor', bar: () => lastColor, run: () => Ed.color(lastColor),
    menu: b => UI.palette(b, c => { if (c && c !== 'auto') { lastColor = c; updateBars(); } Ed.color(c === 'auto' ? null : c); }, { none: null, auto: 'Авто (чёрный)' }) });
  cmd('highlight', { label: 'Выделение цветом', icon: 'highlight', bar: () => lastHl, run: () => Ed.highlight(lastHl),
    menu: b => UI.palette(b, c => { if (c) { lastHl = c; updateBars(); } Ed.highlight(c); }, { highlight: true }) });
  cmd('fontDialog', { label: 'Шрифт…', icon: 'font', run: () => fontDialog() });
  cmd('bullets', { label: 'Маркеры', icon: 'bullets', run: () => Ed.list('ul'), active: c => c.ul,
    menu: b => UI.menu(b, [
      { label: '●  Круг', action: () => Ed.list('ul', 'disc') }, { label: '○  Окружность', action: () => Ed.list('ul', 'circle') },
      { label: '■  Квадрат', action: () => Ed.list('ul', 'square') }, { label: '–  Тире', action: () => Ed.list('ul', '"– "') },
      { label: '➢  Стрелка', action: () => Ed.list('ul', '"➢ "') }, { label: '✓  Галочка', action: () => Ed.list('ul', '"✓ "') },
      { label: '★  Звезда', action: () => Ed.list('ul', '"★ "') }, { sep: true }, { label: '☐  Список задач', action: () => Ed.checklist() }]) });
  cmd('numbering', { label: 'Нумерация', icon: 'numbering', run: () => Ed.list('ol'), active: c => c.ol,
    menu: b => UI.menu(b, [
      { label: '1. 2. 3.', action: () => Ed.list('ol', 'decimal') }, { label: '01. 02. 03.', action: () => Ed.list('ol', 'decimal-leading-zero') },
      { label: 'a. b. c.', action: () => Ed.list('ol', 'lower-alpha') }, { label: 'A. B. C.', action: () => Ed.list('ol', 'upper-alpha') },
      { label: 'а. б. в.', action: () => Ed.list('ol', 'cyr-lower') }, { label: 'А. Б. В.', action: () => Ed.list('ol', 'cyr-upper') }, { label: 'i. ii. iii.', action: () => Ed.list('ol', 'lower-roman') },
      { label: 'I. II. III.', action: () => Ed.list('ol', 'upper-roman') }, { sep: true },
      { label: 'Начать с номера…', action: async () => { const n = await UI.prompt('Начальный номер', '1', { type: 'number' }); if (n) Ed.startNumber(+n); } }]) });
  cmd('checklist', { label: 'Задачи', icon: 'checklist', run: () => Ed.checklist(), active: c => c.checklist });
  cmd('indent', { label: 'Увеличить отступ', icon: 'indent', run: () => Ed.indent(1) });
  cmd('outdent', { label: 'Уменьшить отступ', icon: 'outdent', run: () => Ed.indent(-1) });
  cmd('alignLeft', { label: 'По левому краю', icon: 'alignLeft', run: () => Ed.align('left'), active: c => c.align === 'left' });
  cmd('alignCenter', { label: 'По центру', icon: 'alignCenter', run: () => Ed.align('center'), active: c => c.align === 'center' });
  cmd('alignRight', { label: 'По правому краю', icon: 'alignRight', run: () => Ed.align('right'), active: c => c.align === 'right' });
  cmd('alignJustify', { label: 'По ширине', icon: 'alignJustify', run: () => Ed.align('justify'), active: c => c.align === 'justify' });
  cmd('alignMenu', { label: 'Выравнивание', icon: 'alignLeft', iconFn: c => ({ left: 'alignLeft', center: 'alignCenter', right: 'alignRight', justify: 'alignJustify' }[c.align] || 'alignLeft'),
    run: b => UI.menu(b, [{ label: 'По левому краю', icon: 'alignLeft', action: () => Ed.align('left') }, { label: 'По центру', icon: 'alignCenter', action: () => Ed.align('center') },
      { label: 'По правому краю', icon: 'alignRight', action: () => Ed.align('right') }, { label: 'По ширине', icon: 'alignJustify', action: () => Ed.align('justify') }]) });
  cmd('lineSpacing', { label: 'Интервал', icon: 'lineSpacing', run: b => {
    const cur = Ed.current();
    const items = [1, 1.15, 1.5, 2, 2.5, 3].map(v => ({ label: String(v).replace('.', ','), action: () => Ed.lineHeight(+(v * Fmt.LH).toFixed(3)) }));
    UI.menu(b, [...items, { sep: true },
      { label: 'Интервал перед: добавить', action: () => Ed.spacing(12, null) }, { label: 'Интервал перед: убрать', action: () => Ed.spacing(0, null) },
      { label: 'Интервал после: добавить', action: () => Ed.spacing(null, 8) }, { label: 'Интервал после: убрать', action: () => Ed.spacing(null, 0) },
      { sep: true }, { label: 'Параметры абзаца…', action: () => paragraphDialog() }]);
  } });
  cmd('paraDialog', { label: 'Абзац…', icon: 'paragraph', run: () => paragraphDialog() });
  cmd('shading', { label: 'Заливка', icon: 'shading', run: b => UI.palette(b, c => Ed.blockStyle(x => { x.style.backgroundColor = c || ''; })) });
  cmd('borders', { label: 'Границы', icon: 'border', run: b => UI.menu(b, [
    { label: 'Рамка вокруг абзаца', action: () => Ed.blockStyle(x => { x.style.border = '1px solid #000'; x.style.padding = '4pt 6pt'; }) },
    { label: 'Линия снизу', action: () => Ed.blockStyle(x => { x.style.borderBottom = '1px solid #000'; }) },
    { label: 'Линия сверху', action: () => Ed.blockStyle(x => { x.style.borderTop = '1px solid #000'; }) },
    { label: 'Без границ', action: () => Ed.blockStyle(x => { x.style.border = ''; x.style.padding = ''; }) }, { sep: true },
    { label: 'Горизонтальная линия', action: () => Ed.hr() }]) });
  cmd('style', { label: 'Стиль', kind: 'combo', cls: 'style', value: c => Ed.STYLES[c.style]?.label || 'Обычный', run: b => UI.menu(b, Object.entries(Ed.STYLES).map(([k, v]) => ({
    label: v.label, on: Ed.current().style === k, action: () => Ed.applyStyle(k),
    style: { h1: 'font-size:20px;font-weight:bold;color:#1F3864', h2: 'font-size:18px;font-weight:bold;color:#1F3864', h3: 'font-size:16px;font-weight:bold;color:#1F3864', title: 'font-size:22px', subtitle: 'color:#5a5a5a', quote: 'font-style:italic', code: 'font-family:monospace' }[k] || '' }))) });
  cmd('dir', { label: 'Справа налево', icon: 'textDir', run: b => UI.menu(b, [{ label: 'Слева направо', action: () => Ed.direction('ltr') }, { label: 'Справа налево', action: () => Ed.direction('rtl') }]) });

  // --- Вставка ---
  cmd('insertTable', { label: 'Таблица', icon: 'table', run: b => tablePicker(b) });
  cmd('insertImage', { label: 'Рисунок', icon: 'image', run: () => pickImage() });
  cmd('insertLink', { label: 'Ссылка', icon: 'link', run: () => linkDialog() });
  cmd('symbol', { label: 'Символ', icon: 'symbol', run: () => symbolDialog() });
  cmd('emoji', { label: 'Эмодзи', icon: 'emoji', run: () => symbolDialog('Эмодзи') });
  cmd('insertDate', { label: 'Дата и время', icon: 'calendar', run: () => dateDialog() });
  cmd('pageBreak', { label: 'Разрыв страницы', icon: 'pageBreak', run: () => Ed.pageBreak() });
  cmd('colBreak', { label: 'Разрыв колонки', icon: 'colBreak', run: () => Ed.columnBreak() });
  cmd('hr', { label: 'Линия', icon: 'hr', run: () => Ed.hr() });
  cmd('toc', { label: 'Оглавление', icon: 'toc', run: () => { computePages(); Ed.insertToc(pageOf); } });
  cmd('updateToc', { label: 'Обновить оглавление', icon: 'toc', run: () => { computePages(); Ed.updateToc(pageOf); } });
  cmd('footnote', { label: 'Сноска', icon: 'footnote', run: async () => { const t = await UI.prompt('Текст сноски', '', { title: 'Вставить сноску' }); if (t != null) Ed.footnote(t); } });
  cmd('comment', { label: 'Примечание', icon: 'comment', run: async () => { const t = await UI.prompt('Текст примечания', '', { title: 'Новое примечание' }); if (t) Ed.addComment(t); } });
  cmd('headerFooter', { label: 'Колонтитулы', icon: 'header', run: () => headerFooterDialog() });
  cmd('pageNumbers', { label: 'Номера страниц', icon: 'pageNum', run: b => UI.menu(b, [
    ['none', 'Без номеров'], ['bottom-center', 'Внизу по центру'], ['bottom-right', 'Внизу справа'], ['bottom-left', 'Внизу слева'], ['top-center', 'Вверху по центру'], ['top-right', 'Вверху справа']
  ].map(([v, l]) => ({ label: l, on: state.meta.pageNumbers === v, action: () => { setMeta({ pageNumbers: v }); } })).concat([{ sep: true },
    { label: 'Формат «Страница X из Y»', on: state.meta.pageNumFormat === 'n of N', action: () => setMeta({ pageNumFormat: state.meta.pageNumFormat === 'n of N' ? 'n' : 'n of N' }) }])) });
  cmd('quote', { label: 'Цитата', icon: 'quote', run: () => Ed.applyStyle('quote') });
  cmd('code', { label: 'Код', icon: 'code', run: () => Ed.applyStyle('code') });
  cmd('signature', { label: 'Строка подписи', icon: 'sigline', run: () => Ed.insertHTML(`<p>${new Date().toLocaleDateString('ru-RU')}\t\t\t\t____________________ / ${esc(S().author || 'Фамилия И. О.')}</p>`) });
  cmd('dropCap', { label: 'Буквица', icon: 'dropCap', run: () => dropCap() });
  cmd('textbox', { label: 'Надпись', icon: 'textbox', run: () => Ed.insertHTML('<table data-borders="1" style="width:60%;margin-left:auto;margin-right:auto"><tbody><tr><td>Текст надписи</td></tr></tbody></table><p><br></p>') });

  // --- Макет ---
  cmd('pageSetup', { label: 'Параметры страницы', icon: 'pageSize', run: () => pageSetupDialog() });
  cmd('pageSize', { label: 'Размер', icon: 'pageSize', run: b => UI.menu(b, Object.entries(Fmt.PAGE_SIZES).map(([k, [w, hh]]) => ({
    label: k, small: `${w} × ${hh} мм`, on: Math.abs(state.meta.pageW - w) < 1 && Math.abs(state.meta.pageH - hh) < 1,
    action: () => setMeta({ pageW: w, pageH: hh }) })).concat([{ sep: true }, { label: 'Другой размер…', action: () => pageSetupDialog() }])) });
  cmd('orientation', { label: 'Ориентация', icon: 'orientation', run: b => UI.menu(b, [
    { label: 'Книжная', on: state.meta.orientation !== 'landscape', action: () => setMeta({ orientation: 'portrait' }) },
    { label: 'Альбомная', on: state.meta.orientation === 'landscape', action: () => setMeta({ orientation: 'landscape' }) }]) });
  cmd('margins', { label: 'Поля', icon: 'margins', run: b => UI.menu(b, [
    ['normal', 'Обычные', '20 / 15 / 20 / 30'], ['gost', 'ГОСТ (документы)', '20 / 10 / 20 / 30'], ['office', 'Офисные', '25,4 со всех сторон'],
    ['narrow', 'Узкие', '12,7 со всех сторон'], ['moderate', 'Средние', '25,4 / 19,1'], ['wide', 'Широкие', '25,4 / 50,8']
  ].map(([k, l, d]) => ({ label: l, small: d, action: () => setMeta({ margins: Object.assign({}, Fmt.MARGINS[k]) }) })).concat([{ sep: true }, { label: 'Настраиваемые поля…', action: () => pageSetupDialog() }])) });
  cmd('columns', { label: 'Колонки', icon: 'columns', run: b => UI.menu(b, [1, 2, 3, 4].map(n => ({ label: n === 1 ? 'Одна' : n + ' колонки', on: (state.meta.columns || 1) === n, action: () => setMeta({ columns: n }) }))) });
  cmd('pageColor', { label: 'Цвет страницы', icon: 'pageColor', run: b => UI.palette(b, c => setMeta({ pageColor: c || '' }), { none: 'Без цвета' }) });
  cmd('hyphens', { label: 'Переносы', icon: 'textDir', glyphText: 'пере-', run: () => { Store.set('hyphens', !S().hyphens); applySettings(); }, active: () => S().hyphens });
  cmd('docDefaults', { label: 'Шрифт по умолчанию', icon: 'font', run: () => docDefaultsDialog() });

  // --- Вид ---
  cmd('viewPage', { label: 'Разметка страницы', icon: 'pageView', run: () => setView('page'), active: () => S().view === 'page' });
  cmd('viewMobile', { label: 'Мобильный вид', icon: 'mobile', run: () => setView('mobile'), active: () => S().view === 'mobile' });
  cmd('zoomIn', { label: 'Крупнее', icon: 'zoomIn', run: () => zoomBy(1.1) });
  cmd('zoomOut', { label: 'Мельче', icon: 'zoomOut', run: () => zoomBy(1 / 1.1) });
  cmd('zoom100', { label: '100%', html: glyph('100%', 'font-size:13px;font-family:sans-serif'), run: () => setZoom(1) });
  cmd('fitWidth', { label: 'По ширине', icon: 'fitWidth', run: () => { Store.set('fitWidth', true); fitWidth(); }, active: () => S().fitWidth && S().view === 'page' });
  cmd('guides', { label: 'Границы страниц', icon: 'guides', run: () => { Store.set('guides', !S().guides); applySettings(); }, active: () => S().guides });
  cmd('marks', { label: 'Знаки ¶', icon: 'pilcrow', run: () => { Store.set('marks', !S().marks); applySettings(); }, active: () => S().marks });
  cmd('navPane', { label: 'Навигация', icon: 'nav', run: () => navPane() });
  cmd('fullscreen', { label: 'Во весь экран', icon: 'fullscreen', run: () => { Store.set('fullscreen', !S().fullscreen); applySettings(); }, active: () => S().fullscreen });
  cmd('night', { label: 'Тема', icon: 'moon', run: b => UI.menu(b, [['system', 'Как в системе'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, l]) => ({ label: l, on: S().theme === v, action: () => { Store.set('theme', v); applySettings(); } })).concat([{ sep: true }, { title: 'Цвет листа (только на экране)' }],
    [['white', 'Белый'], ['sepia', 'Сепия'], ['gray', 'Серый'], ['dark', 'Тёмный']].map(([v, l]) => ({ label: l, on: S().paper === v, action: () => { Store.set('paper', v); applySettings(); } })))) });
  cmd('ribbonPos', { label: 'Лента снизу', icon: 'down', run: () => { Store.set('ribbonPos', S().ribbonPos === 'top' ? 'bottom' : 'top'); applySettings(); }, active: () => S().ribbonPos === 'bottom' });
  cmd('quickToggle', { label: 'Панель быстрого доступа', icon: 'keyboard', run: () => { Store.set('quickbar', !S().quickbar); applySettings(); }, active: () => S().quickbar });
  cmd('customizeQuick', { label: 'Настроить панель', icon: 'gear', run: () => quickDialog() });
  cmd('statusToggle', { label: 'Строка состояния', icon: 'info', run: () => { Store.set('statusbar', !S().statusbar); applySettings(); }, active: () => S().statusbar });

  // --- Рецензирование ---
  cmd('find', { label: 'Найти', icon: 'search', run: () => openFind(false) });
  cmd('replace', { label: 'Заменить', icon: 'replace', run: () => openFind(true) });
  cmd('spell', { label: 'Орфография', icon: 'spell', run: () => { Store.set('spellcheck', !S().spellcheck); applySettings(); UI.toast(S().spellcheck ? 'Проверка орфографии включена (подчёркивание ошибок — клавиатурой Android)' : 'Проверка орфографии выключена'); }, active: () => S().spellcheck });
  cmd('wordCount', { label: 'Статистика', icon: 'count', run: () => wordCountDialog() });
  cmd('commentsPane', { label: 'Все примечания', icon: 'comment', run: () => commentsPane() });
  cmd('speak', { label: 'Читать вслух', icon: 'speak', run: () => speak() });
  cmd('language', { label: 'Язык', icon: 'translate', run: b => UI.menu(b, [['ru', 'Русский'], ['uk', 'Українська'], ['en', 'English'], ['de', 'Deutsch'], ['be', 'Беларуская'], ['kk', 'Қазақша']].map(([v, l]) => ({ label: l, on: state.meta.lang === v, action: () => { setMeta({ lang: v }); Store.set('lang', v); } }))) });
  cmd('protect', { label: 'Только чтение', icon: 'lock', run: () => setReading(!state.reading), active: () => state.reading });

  // --- Таблица (контекстная вкладка) ---
  cmd('rowAbove', { label: 'Строка выше', icon: 'rowAbove', run: () => Ed.addRow(false) });
  cmd('rowBelow', { label: 'Строка ниже', icon: 'rowBelow', run: () => Ed.addRow(true) });
  cmd('colLeft', { label: 'Столбец слева', icon: 'colLeft', run: () => Ed.addCol(false) });
  cmd('colRight', { label: 'Столбец справа', icon: 'colRight', run: () => Ed.addCol(true) });
  cmd('delRow', { label: 'Удалить строку', icon: 'delRow', run: () => Ed.delRow() });
  cmd('delCol', { label: 'Удалить столбец', icon: 'delCol', run: () => Ed.delCol() });
  cmd('delTable', { label: 'Удалить таблицу', icon: 'delTable', run: () => Ed.delTable() });
  cmd('mergeRight', { label: 'Объединить вправо', icon: 'merge', run: () => Ed.mergeRight() });
  cmd('mergeDown', { label: 'Объединить вниз', icon: 'merge', run: () => Ed.mergeDown(), rot: true });
  cmd('splitCell', { label: 'Разделить ячейку', icon: 'split', run: () => Ed.splitCell() });
  cmd('headerRow', { label: 'Строка заголовка', icon: 'tableProps', run: () => Ed.headerRow() });
  cmd('tblBorders', { label: 'Границы', icon: 'border', run: b => UI.menu(b, [{ label: 'Все границы', action: () => Ed.tableBorders(true) }, { label: 'Без границ', action: () => Ed.tableBorders(false) }]) });
  cmd('cellColor', { label: 'Заливка ячейки', icon: 'shading', run: b => UI.palette(b, c => Ed.cellColor(c)) });
  cmd('cellAlign', { label: 'Выравнивание в ячейке', icon: 'cellAlign', run: b => UI.menu(b, [
    { label: 'Сверху', action: () => Ed.cellVAlign('top') }, { label: 'По центру', action: () => Ed.cellVAlign('middle') }, { label: 'Снизу', action: () => Ed.cellVAlign('bottom') }]) });
  cmd('tblStyle', { label: 'Стиль таблицы', icon: 'table', run: b => UI.menu(b, [
    { label: 'Сетка', action: () => Ed.tablePreset('grid') }, { label: 'Без границ', action: () => Ed.tablePreset('none') },
    { label: 'Чередование строк', action: () => Ed.tablePreset('zebra') }, { label: 'Синяя шапка', action: () => Ed.tablePreset('blue') }]) });
  cmd('tblWidth', { label: 'Ширина', icon: 'fitWidth', run: b => UI.menu(b, [
    { label: 'По ширине страницы', action: () => Ed.tableWidth('100%') }, { label: 'По содержимому', action: () => { Ed.tableWidth('auto'); Ed.autofit(); } },
    { label: 'Выровнять столбцы', action: () => Ed.distribute() }, { sep: true },
    { label: 'Таблица слева', action: () => Ed.tableAlign('left') }, { label: 'Таблица по центру', action: () => Ed.tableAlign('center') }, { label: 'Таблица справа', action: () => Ed.tableAlign('right') }]) });
  cmd('tblSort', { label: 'Сортировка', icon: 'sort', run: b => UI.menu(b, [
    { label: 'По возрастанию (А→Я)', action: () => Ed.sortTable(false, true) }, { label: 'По убыванию (Я→А)', action: () => Ed.sortTable(true, true) },
    { label: 'По возрастанию, без заголовка', action: () => Ed.sortTable(false, false) }]) });

  // --- Рисунок (контекстная вкладка) ---
  cmd('imgSize', { label: 'Размер', icon: 'resize', run: b => UI.menu(b, [25, 33, 50, 75, 100].map(p => ({ label: p + '% ширины', action: () => Ed.imageWidth(p + '%') }))
    .concat([{ label: 'Исходный размер', action: () => { const i = Ed.selImg; if (i) Ed.imageWidth(Math.min(i.naturalWidth, Ed.doc.clientWidth)); } }, { sep: true },
      { label: 'Точный размер…', action: async () => { const v = await UI.prompt('Ширина в пикселях или %', Ed.selImg ? Math.round(Ed.selImg.getBoundingClientRect().width / zoomVal()) : ''); if (v) Ed.imageWidth(/%$/.test(v) ? v : +v); } }])) });
  cmd('imgInline', { label: 'В тексте', icon: 'imgInline', run: () => Ed.imageWrap('inline') });
  cmd('imgLeft', { label: 'Обтекание слева', icon: 'imgLeft', run: () => Ed.imageWrap('float-left') });
  cmd('imgRight', { label: 'Обтекание справа', icon: 'imgRight', run: () => Ed.imageWrap('float-right') });
  cmd('imgCenter', { label: 'По центру', icon: 'imgCenter', run: () => Ed.imageWrap('center') });
  cmd('imgRotate', { label: 'Повернуть', icon: 'rotate', run: () => Ed.imageRotate() });
  cmd('imgBorder', { label: 'Рамка', icon: 'border', run: () => { const i = Ed.selImg; Ed.imageBorder(!(i && i.style.border)); } });
  cmd('imgAlt', { label: 'Подпись (alt)', icon: 'info', run: async () => { const i = Ed.selImg; if (!i) return; const t = await UI.prompt('Описание рисунка', i.alt || ''); if (t != null) Ed.run(() => { i.alt = t; }, { keepFocus: false }); } });
  cmd('imgDelete', { label: 'Удалить', icon: 'trash', run: () => Ed.deleteImage() });
  cmd('imgShare', { label: 'Сохранить рисунок', icon: 'share', run: () => { const i = Ed.selImg; if (!i) return; const d = Fmt.dataUrlToBytes(i.src); if (d) shareBytes(d.bytes, 'рисунок.' + (Fmt.EXT_BY_MIME[d.mime] || 'png'), d.mime); } });

  // ===================================================================
  //                        ЛЕНТА (вкладки и группы)
  // ===================================================================
  const TABS = [
    { id: 'home', label: 'Главная', groups: [
      { label: 'Буфер', items: ['paste', 'cut', 'copy', 'pastePlain', 'formatPainter', 'selectAll'] },
      { label: 'Шрифт', row: true, items: ['font', 'size'] },
      { label: 'Начертание', items: ['bold', 'italic', 'underline', 'strike', 'sub', 'sup', 'fontColor', 'highlight', 'grow', 'shrink', 'textCase', 'clearFormat', 'fontDialog'] },
      { label: 'Абзац', items: ['bullets', 'numbering', 'checklist', 'outdent', 'indent', 'alignLeft', 'alignCenter', 'alignRight', 'alignJustify', 'lineSpacing', 'shading', 'borders', 'paraDialog'] },
      { label: 'Стили', gallery: true },
      { label: 'Правка', items: ['find', 'replace'] }
    ] },
    { id: 'insert', label: 'Вставка', groups: [
      { label: 'Таблицы и рисунки', items: ['insertTable', 'insertImage', 'textbox'] },
      { label: 'Ссылки', items: ['insertLink', 'footnote', 'toc', 'updateToc'] },
      { label: 'Символы', items: ['symbol', 'emoji', 'insertDate', 'signature'] },
      { label: 'Разрывы', items: ['pageBreak', 'colBreak', 'hr'] },
      { label: 'Колонтитулы', items: ['headerFooter', 'pageNumbers'] },
      { label: 'Текст', items: ['quote', 'code', 'dropCap', 'comment'] }
    ] },
    { id: 'layout', label: 'Макет', groups: [
      { label: 'Страница', items: ['pageSize', 'orientation', 'margins', 'columns', 'pageColor', 'pageSetup'] },
      { label: 'Абзац', items: ['paraDialog', 'lineSpacing', 'indent', 'outdent', 'dir', 'hyphens'] },
      { label: 'Документ', items: ['docDefaults', 'properties'] }
    ] },
    { id: 'view', label: 'Вид', groups: [
      { label: 'Режим', items: ['viewMobile', 'viewPage', 'readMode'] },
      { label: 'Масштаб', items: ['zoomOut', 'zoomIn', 'zoom100', 'fitWidth'] },
      { label: 'Показать', items: ['navPane', 'guides', 'marks', 'statusToggle'] },
      { label: 'Окно', items: ['fullscreen', 'night', 'ribbonPos', 'quickToggle', 'customizeQuick', 'settings'] }
    ] },
    { id: 'review', label: 'Рецензирование', groups: [
      { label: 'Правописание', items: ['spell', 'language', 'wordCount'] },
      { label: 'Примечания', items: ['comment', 'commentsPane'] },
      { label: 'Поиск', items: ['find', 'replace'] },
      { label: 'Чтение', items: ['speak', 'protect'] }
    ] },
    { id: 'table', label: 'Таблица', ctx: true, groups: [
      { label: 'Строки и столбцы', items: ['rowAbove', 'rowBelow', 'colLeft', 'colRight', 'delRow', 'delCol', 'delTable'] },
      { label: 'Ячейки', items: ['mergeRight', 'mergeDown', 'splitCell', 'cellColor', 'cellAlign'] },
      { label: 'Таблица', items: ['tblStyle', 'tblBorders', 'headerRow', 'tblWidth', 'tblSort'] }
    ] },
    { id: 'image', label: 'Рисунок', ctx: true, groups: [
      { label: 'Размер', items: ['imgSize', 'imgRotate', 'imgBorder'] },
      { label: 'Положение', items: ['imgInline', 'imgLeft', 'imgCenter', 'imgRight'] },
      { label: 'Рисунок', items: ['imgAlt', 'imgShare', 'imgDelete'] }
    ] }
  ];

  function button(id, cls = 'rb', forQuick = false) {
    const c = C[id];
    if (!c) return null;
    if (c.kind === 'combo') {
      const b = h('button', { class: 'combo ' + (c.cls || ''), 'data-cmd': id, title: c.label }, h('span', { class: 'v', text: '' }), h('span', { class: 'caret', text: '▾' }));
      return b;
    }
    const b = h('button', { class: cls, 'data-cmd': id, title: c.label, 'aria-label': c.label });
    b.innerHTML = c.html || icon(c.icon);
    if (c.rot) b.firstChild.style.transform = 'rotate(90deg)';
    if (c.bar) b.append(h('span', { class: 'bar', style: { background: c.bar() } }));
    if (c.menu) b.append(h('span', { class: 'caret', text: '▾' }));
    if (!forQuick && S().showLabels && cls === 'rb' && ['paste', 'insertTable', 'insertImage', 'find', 'symbol', 'pageSize', 'margins', 'orientation', 'columns', 'viewMobile', 'viewPage', 'readMode', 'wordCount', 'headerFooter', 'navPane', 'speak', 'toc', 'insertLink', 'pageSetup', 'paraDialog'].includes(id))
      b.append(h('span', { class: 'lbl opt', text: c.label }));
    return b;
  }
  function updateBars() { $$('[data-cmd="fontColor"] .bar').forEach(b => b.style.background = lastColor); $$('[data-cmd="highlight"] .bar').forEach(b => b.style.background = lastHl); }

  function renderTabs() {
    const nav = $('#tabs');
    nav.innerHTML = '';
    for (const t of TABS) {
      if (t.ctx && state.ctxTab !== t.id) continue;
      nav.append(h('button', { class: (state.tab === t.id ? 'on ' : '') + (t.ctx ? 'ctx' : ''), text: t.label, onclick: () => selectTab(t.id) }));
    }
    nav.append(h('button', { class: 'pin', title: 'Режим ленты', html: icon(S().ribbonMode === 'pinned' ? 'pin' : 'unpin'), onclick: e => ribbonModeMenu(e.currentTarget) }));
  }
  function selectTab(id) {
    if (state.tab === id && state.ribbonShown && S().ribbonMode !== 'pinned') { state.ribbonShown = false; applyRibbonVisibility(); return; }
    state.tab = id;
    state.ribbonShown = true;
    renderTabs(); renderRibbon(); applyRibbonVisibility();
  }
  function renderRibbon() {
    const rb = $('#ribbon');
    rb.innerHTML = '';
    const tab = TABS.find(t => t.id === state.tab) || TABS[0];
    for (const g of tab.groups) {
      const items = h('div', { class: 'items' + (g.row ? ' row' : '') });
      if (g.gallery) {
        const gal = h('div', { class: 'stylegal' });
        for (const [k, v] of Object.entries(Ed.STYLES)) {
          const st = { h1: 'font-size:17px;font-weight:bold;color:#1F3864', h2: 'font-size:15px;font-weight:bold;color:#1F3864', h3: 'font-size:14px;font-weight:bold;color:#1F3864', title: 'font-size:18px', subtitle: 'color:#777', quote: 'font-style:italic', code: 'font-family:monospace' }[k] || '';
          gal.append(h('button', { 'data-style': k, html: `<span style="${st}">АаБб</span><br><small>${v.label}</small>`, onclick: () => Ed.applyStyle(k) }));
        }
        items.append(gal);
        items.classList.add('row');
      } else {
        for (const id of g.items) { const b = button(id); if (b) items.append(b); }
      }
      rb.append(h('div', { class: 'grp' }, items, h('div', { class: 'gl', text: g.label })));
    }
    // закрепить/открепить ленту
    updateStates(true);
  }
  function renderQuick() {
    const q = $('#quickbar');
    q.innerHTML = '';
    if (!S().quickbar) return;
    for (const id of S().quickItems) { const b = button(id, 'rb', true); if (b) q.append(b); }
    q.append(h('button', { class: 'rb', title: 'Настроить панель', html: icon('more'), onclick: () => quickDialog() }));
    updateStates(true);
  }

  // нажатия кнопок команд (делегирование)
  function onCmdClick(e) {
    const b = e.target.closest('[data-cmd]');
    if (!b || b.disabled) return;
    const c = C[b.dataset.cmd];
    if (!c) return;
    if (longPressFired) { longPressFired = false; return; }
    // отдельная стрелка меню: нажатие в правой трети кнопки
    if (c.menu) {
      const r = b.getBoundingClientRect();
      if (e.clientX > r.right - 16 || (b.closest('#quickbar') && c.menu && !c.run)) { c.menu(b); return; }
    }
    c.run && c.run(b);
    if (S().ribbonMode === 'auto' && b.closest('#ribbon') && !c.menu && c.kind !== 'combo') { /* оставляем ленту открытой для серии действий */ }
    setTimeout(() => updateStates(), 30);
  }
  // кнопки не забирают фокус у документа (иначе пропадёт выделение и клавиатура)
  function keepFocus(e) {
    if (e.target.closest('[data-cmd], #tabs button, .stylegal button')) e.preventDefault();
  }
  let lpTimer = null, longPressFired = false;
  function onLongPressStart(e) {
    const b = e.target.closest('#ribbon [data-cmd], #quickbar [data-cmd]');
    if (!b) return;
    clearTimeout(lpTimer);
    lpTimer = setTimeout(() => {
      longPressFired = true;
      const id = b.dataset.cmd, c = C[id];
      const inQuick = S().quickItems.includes(id);
      const items = [{ title: c.label }];
      if (c.menu) items.push({ label: 'Варианты…', action: () => c.menu(b) });
      items.push(inQuick ? { label: 'Убрать с панели быстрого доступа', icon: 'minus', action: () => { Store.set('quickItems', S().quickItems.filter(x => x !== id)); renderQuick(); } }
        : { label: 'Добавить на панель быстрого доступа', icon: 'plus', action: () => { Store.set('quickItems', [...S().quickItems, id]); Store.set('quickbar', true); applySettings(); } });
      UI.menu(b, items);
    }, 550);
  }
  const cancelLongPress = () => clearTimeout(lpTimer);

  let stTimer = null;
  function updateStates(now) {
    clearTimeout(stTimer);
    const go = () => {
      let cur;
      try { cur = Ed.current(); } catch (e) { return; }
      for (const b of $$('[data-cmd]')) {
        const c = C[b.dataset.cmd];
        if (!c) continue;
        if (c.active) b.classList.toggle('on', !!c.active(cur));
        if (c.enabled) b.disabled = !c.enabled();
        if (c.kind === 'combo') { const v = $('.v', b); if (v) { const val = c.value(cur); v.textContent = val; if (c.cls === 'font') v.style.fontFamily = Fonts.css(String(val)); } }
        if (c.iconFn) { const nm = c.iconFn(cur); if (b.dataset.icon !== nm) { b.dataset.icon = nm; b.innerHTML = icon(nm); } }
      }
      $$('.stylegal button').forEach(b => b.classList.toggle('on', b.dataset.style === cur.style));
      // контекстные вкладки
      const ctx = cur.image ? 'image' : cur.inTable ? 'table' : null;
      if (ctx !== state.ctxTab) {
        const wasCtx = state.ctxTab;
        state.ctxTab = ctx;
        if (ctx && S().ribbonMode !== 'hidden') { state.tab = ctx; state.ribbonShown = true; }
        else if (!ctx && TABS.find(t => t.id === state.tab)?.ctx) state.tab = 'home';
        if (wasCtx !== ctx) { renderTabs(); renderRibbon(); applyRibbonVisibility(); }
      }
    };
    if (now === true) go(); else stTimer = setTimeout(go, 120);
  }

  function ribbonModeMenu(anchor) {
    UI.menu(anchor, [
      { title: 'Лента' },
      { label: 'Закрепить ленту', icon: 'pin', on: S().ribbonMode === 'pinned', action: () => { Store.set('ribbonMode', 'pinned'); applySettings(); } },
      { label: 'Скрывать автоматически', icon: 'unpin', on: S().ribbonMode === 'auto', action: () => { Store.set('ribbonMode', 'auto'); applySettings(); } },
      { label: 'Только вкладки (скрыть ленту)', icon: 'chevUp', on: S().ribbonMode === 'hidden', action: () => { Store.set('ribbonMode', 'hidden'); state.ribbonShown = false; applySettings(); } },
      { sep: true },
      { label: S().ribbonPos === 'top' ? 'Переместить ленту вниз' : 'Переместить ленту вверх', icon: S().ribbonPos === 'top' ? 'down' : 'up', action: () => C.ribbonPos.run() },
      { label: 'Лента в одну строку', on: +S().ribbonRows === 1, action: () => { Store.set('ribbonRows', +S().ribbonRows === 1 ? 2 : 1); applySettings(); } },
      { label: 'Подписи кнопок', on: S().showLabels, action: () => { Store.set('showLabels', !S().showLabels); applySettings(); } },
      { label: 'Названия групп', on: S().groupLabels, action: () => { Store.set('groupLabels', !S().groupLabels); applySettings(); } },
      { label: 'Настроить панель быстрого доступа…', icon: 'gear', action: () => quickDialog() }
    ]);
  }
  function toggleRibbon() {
    if (S().ribbonMode === 'hidden') { Store.set('ribbonMode', 'pinned'); state.ribbonShown = true; }
    else if (S().ribbonMode === 'pinned') { Store.set('ribbonMode', 'hidden'); state.ribbonShown = false; }
    else state.ribbonShown = !state.ribbonShown;
    applySettings();
  }
  function applyRibbonVisibility() {
    const mode = S().ribbonMode;
    app.classList.toggle('ribbon-collapsed', (mode !== 'pinned' && !state.ribbonShown));
    app.classList.toggle('ribbon-hidden', mode === 'hidden' && !state.ribbonShown);
    const t = $('#ribbonToggle');
    if (t) t.innerHTML = icon(app.classList.contains('ribbon-collapsed') || app.classList.contains('ribbon-hidden') ? 'chevDown' : 'chevUp');
    $$('#tabs button:not(.pin)').forEach(b => { if (app.classList.contains('ribbon-collapsed')) b.classList.remove('on'); });
    if (!app.classList.contains('ribbon-collapsed')) renderTabs();
    requestAnimationFrame(() => { if (S().fitWidth) fitWidth(); });
  }

  // ===================================================================
  //                         НАСТРОЙКИ И ВИД
  // ===================================================================
  function applySettings() {
    const s = S();
    const root = document.documentElement;
    const dark = s.theme === 'dark' || (s.theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    root.classList.toggle('dark', dark);
    root.classList.remove('btn-s', 'btn-m', 'btn-l', 'btn-xl');
    root.classList.add('btn-' + s.btnSize);
    root.style.setProperty('--ui-scale', s.uiScale);
    root.classList.toggle('labels-off', !s.showLabels);
    root.classList.toggle('no-group-labels', !s.groupLabels);
    root.classList.toggle('ribbon-1row', +s.ribbonRows === 1);
    const paper = { white: ['#FFFFFF', '#000000'], sepia: ['#F4ECD8', '#3B2F1E'], gray: ['#E6E6E6', '#111111'], dark: ['#1E1E1E', '#DADADA'] }[s.paper] || ['#fff', '#000'];
    root.style.setProperty('--paper', state.meta && state.meta.pageColor && s.paper === 'white' ? state.meta.pageColor : paper[0]);
    root.style.setProperty('--paper-fg', paper[1]);
    app.classList.toggle('ribbon-bottom', s.ribbonPos === 'bottom');
    app.classList.toggle('quick-top', s.quickPos === 'top');
    app.classList.toggle('no-quickbar', !s.quickbar);
    app.classList.toggle('no-status', !s.statusbar);
    app.classList.toggle('no-guides', !s.guides);
    app.classList.toggle('view-mobile', s.view === 'mobile');
    app.classList.toggle('view-page', s.view === 'page');
    app.classList.toggle('ribbon-pinned', s.ribbonMode === 'pinned');
    Ed.doc.spellcheck = !!s.spellcheck;
    Ed.doc.classList.toggle('show-marks', !!s.marks);
    Ed.doc.classList.toggle('hyphens', !!s.hyphens);
    Ed.doc.setAttribute('autocapitalize', s.autoCapitalize ? 'sentences' : 'off');
    root.style.setProperty('--mobile-scale', s.mobileScale);
    if (isAndroid) {
      Android.setKeepScreenOn(!!s.keepScreenOn);
      Android.setFullscreen(!!s.fullscreen);
      const bar = getComputedStyle(root).getPropertyValue('--brand').trim() || '#2B579A';
      Android.setBarsColor(bar, false);
    }
    if (s.ribbonMode === 'pinned') state.ribbonShown = true;
    renderTabs(); renderRibbon(); renderQuick(); applyRibbonVisibility();
    applyZoom();
    schedulePages();
  }

  function setView(v) { Store.set('view', v); applySettings(); }
  function zoomVal() { return S().view === 'mobile' ? 1 : (parseFloat(getComputedStyle($('#page')).zoom) || 1); }
  function applyZoom() {
    const page = $('#page');
    if (S().view === 'mobile') { page.style.zoom = ''; $('#stZoom').textContent = Math.round(S().mobileScale * 100) + '%'; return; }
    if (S().fitWidth) return fitWidth();
    page.style.zoom = S().zoom;
    $('#stZoom').textContent = Math.round(S().zoom * 100) + '%';
    Ed.positionHandle();
  }
  function pageWidthPx() {
    const land = state.meta.orientation === 'landscape';
    const w = land ? Math.max(state.meta.pageW, state.meta.pageH) : Math.min(state.meta.pageW, state.meta.pageH);
    return w / 25.4 * 96;
  }
  function fitWidth() {
    if (S().view !== 'page') return;
    const ws = $('#workspace');
    const z = Math.max(0.2, Math.min(3, (ws.clientWidth - 16) / pageWidthPx()));
    $('#page').style.zoom = z.toFixed(3);
    $('#stZoom').textContent = Math.round(z * 100) + '%';
    Ed.positionHandle();
  }
  function setZoom(z) {
    if (S().view === 'mobile') { Store.set('mobileScale', Math.max(0.6, Math.min(2.5, +z.toFixed(2)))); applySettings(); return; }
    Store.set('fitWidth', false);
    Store.set('zoom', Math.max(0.2, Math.min(4, +z.toFixed(2))));
    applyZoom(); schedulePages();
  }
  function zoomBy(f) {
    if (S().view === 'mobile') return setZoom(S().mobileScale * f);
    setZoom(zoomVal() * f);
  }

  // жест «щипок» для масштаба
  (() => {
    const ws = $('#workspace');
    let start = null;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    ws.addEventListener('touchstart', e => {
      if (e.touches.length === 2) {
        start = { d: dist(e.touches), z: S().view === 'mobile' ? S().mobileScale : zoomVal() };
        $('#pageWrap').style.transformOrigin = `${(e.touches[0].clientX + e.touches[1].clientX) / 2 + ws.scrollLeft}px ${(e.touches[0].clientY + e.touches[1].clientY) / 2 - ws.getBoundingClientRect().top + ws.scrollTop}px`;
      }
    }, { passive: true });
    ws.addEventListener('touchmove', e => {
      if (!start || e.touches.length !== 2) return;
      e.preventDefault();
      const k = dist(e.touches) / start.d;
      $('#pageWrap').style.transform = `scale(${k})`;
      start.k = k;
    }, { passive: false });
    ws.addEventListener('touchend', () => {
      if (!start) return;
      $('#pageWrap').style.transform = '';
      if (start.k && Math.abs(start.k - 1) > 0.03) setZoom(start.z * start.k);
      start = null;
    });
  })();

  // ===================================================================
  //                    ПАРАМЕТРЫ ДОКУМЕНТА (meta)
  // ===================================================================
  function setMeta(patch, silent) {
    Object.assign(state.meta, patch);
    applyMeta();
    if (!silent) markDirty();
  }
  function applyMeta() {
    const m = state.meta;
    const land = m.orientation === 'landscape';
    const pw = land ? Math.max(m.pageW, m.pageH) : Math.min(m.pageW, m.pageH);
    const ph = land ? Math.min(m.pageW, m.pageH) : Math.max(m.pageW, m.pageH);
    const page = $('#page');
    page.style.width = pw + 'mm';
    page.style.minHeight = ph + 'mm';
    page.style.padding = `${m.margins.t}mm ${m.margins.r}mm ${m.margins.b}mm ${m.margins.l}mm`;
    const root = document.documentElement;
    root.style.setProperty('--doc-font', Fonts.css(m.defaultFont || 'Times New Roman'));
    root.style.setProperty('--doc-size', (m.defaultSize || 12) + 'pt');
    root.style.setProperty('--doc-lh', ((m.defaultLine || 1) * Fmt.LH).toFixed(3));
    root.style.setProperty('--p-after', (m.defaultAfter ?? 8) + 'pt');
    root.style.setProperty('--p-indent', (m.defaultIndent || 0) + 'cm');
    Ed.doc.style.columnCount = m.columns > 1 ? m.columns : '';
    Ed.doc.style.columnGap = m.columns > 1 ? '1.25cm' : '';
    Ed.doc.setAttribute('lang', m.lang || 'ru');
    $('#hdr').textContent = m.header || '';
    const num = m.pageNumbers && m.pageNumbers !== 'none' ? (m.pageNumFormat === 'n of N' ? 'Страница 1 из N' : '1') : '';
    $('#ftr').textContent = (m.footer || '') + (m.pageNumbers?.startsWith('bottom') ? (m.footer ? '\n' : '') + num : '');
    if (m.pageNumbers?.startsWith('top')) $('#hdr').textContent = (m.header || '') + (m.header ? '\n' : '') + num;
    $('#hdr').style.textAlign = $('#ftr').style.textAlign = m.pageNumbers?.endsWith('right') ? 'right' : m.pageNumbers?.endsWith('left') ? 'left' : 'center';
    // стиль печати
    const pos = { 'bottom-center': '@bottom-center', 'bottom-right': '@bottom-right', 'bottom-left': '@bottom-left', 'top-center': '@top-center', 'top-right': '@top-right' }[m.pageNumbers];
    const numContent = m.pageNumFormat === 'n of N' ? '"Страница " counter(page) " из " counter(pages)' : 'counter(page)';
    const cssStr = s => '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\A ') + '"';
    let boxes = '';
    const hdrCenter = m.header ? cssStr(m.header) : null, ftrCenter = m.footer ? cssStr(m.footer) : null;
    const box = { '@top-center': hdrCenter, '@bottom-center': ftrCenter };
    if (pos) box[pos] = box[pos] ? box[pos] + ' "\\A " ' + numContent : numContent;
    for (const [k, v] of Object.entries(box)) if (v) boxes += `${k} { content: ${v}; font: 10pt ${Fonts.css(m.defaultFont)}; color: #444; white-space: pre; }`;
    $('#printStyle').textContent = `@page { size: ${pw}mm ${ph}mm; margin: ${m.margins.t}mm ${m.margins.r}mm ${m.margins.b}mm ${m.margins.l}mm; ${boxes} }`;
    const s = S();
    root.style.setProperty('--paper', m.pageColor && s.paper === 'white' ? m.pageColor : ({ white: '#FFFFFF', sepia: '#F4ECD8', gray: '#E6E6E6', dark: '#1E1E1E' }[s.paper] || '#fff'));
    applyZoom();
    schedulePages();
  }

  // ===================================================================
  //              СТРАНИЦЫ: направляющие, номер текущей страницы
  // ===================================================================
  let pagesTimer = null, pageBreaks = [];
  function schedulePages() { clearTimeout(pagesTimer); pagesTimer = setTimeout(computePages, 400); }
  function computePages() {
    const g = $('#guides');
    g.innerHTML = '';
    pageBreaks = [];
    if (!state.meta) return;
    const m = state.meta;
    const land = m.orientation === 'landscape';
    const ph = land ? Math.min(m.pageW, m.pageH) : Math.max(m.pageW, m.pageH);
    const mmPx = 96 / 25.4;
    const contentH = (ph - m.margins.t - m.margins.b) * mmPx;
    const z = zoomVal();
    const docTop = Ed.doc.getBoundingClientRect().top;
    let pageStart = 0;
    const kids = [...Ed.doc.children];
    for (const b of kids) {
      const r = b.getBoundingClientRect();
      const top = (r.top - docTop) / z, bottom = (r.bottom - docTop) / z;
      if (b.classList.contains('page-break')) { pageStart = bottom; pageBreaks.push(bottom); continue; }
      if (bottom - pageStart > contentH + 1) {
        if (top > pageStart + 1 && bottom - top <= contentH) { pageStart = top; pageBreaks.push(top); }
        while (bottom - pageStart > contentH + 1) { pageStart += contentH; pageBreaks.push(pageStart); }
      }
    }
    const offset = m.margins.t * mmPx;
    if (S().view === 'page') {
      pageBreaks.forEach((y, i) => g.append(h('div', { class: 'g', style: { top: (offset + y) + 'px' } }, h('span', { text: 'стр. ' + (i + 2) }))));
      $('#page').style.minHeight = ((pageBreaks.length + 1) * ph) + 'mm';
    }
    updateStatus();
  }
  function pageOf(el) {
    const z = zoomVal();
    const y = (el.getBoundingClientRect().top - Ed.doc.getBoundingClientRect().top) / z;
    let p = 1;
    for (const b of pageBreaks) if (y >= b - 1) p++;
    return p;
  }
  function updateStatus() {
    const st = Ed.stats();
    $('#stWords').textContent = `${st.words} ${plural(st.words, 'слово', 'слова', 'слов')}`;
    const total = pageBreaks.length + 1;
    let cur = 1;
    const ce = Ed.caretEl();
    if (ce && Ed.doc.contains(ce)) cur = pageOf(ce);
    $('#stPage').textContent = `Стр. ${cur} из ${total}`;
  }
  const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? b : c; };

  // ===================================================================
  //                       ДОКУМЕНТ И ФАЙЛЫ
  // ===================================================================
  function markDirty() {
    if (!state.dirty) { state.dirty = true; app.classList.add('dirty'); }
    scheduleAutosave();
  }
  function markClean() { state.dirty = false; app.classList.remove('dirty'); }
  function setTitle(name) {
    state.file.name = name;
    $('#docTitle').textContent = name;
    document.title = name + ' — DocPad';
  }
  const baseName = n => (n || 'Документ').replace(/\.[^.]+$/, '');

  function loadDocument({ html, meta, name, uri = null, format = 'docx', canWrite = false, warning }) {
    PdfView.close();
    $('#workspace').hidden = false;
    state.meta = Object.assign(Fmt.defaultMeta(), meta || {});
    Ed.setHTML(html);
    state.file = { name: name || 'Документ', uri, format, canWrite };
    setTitle(state.file.name);
    applyMeta();
    applySettings();
    markClean();
    $('#workspace').scrollTop = 0;
    if (warning) setTimeout(() => UI.alert(warning, 'Обратите внимание'), 300);
    scheduleAutosave(true);
  }

  async function confirmDiscard() {
    if (!state.dirty) return true;
    const r = await UI.confirm('В документе есть несохранённые изменения. Сохранить их?', { title: 'Несохранённые изменения', ok: 'Сохранить', cancel: 'Отмена', third: 'Не сохранять' });
    if (r === true) return await save();
    return r === 'third';
  }

  async function newDocument(tplId = 'blank') {
    if (!(await confirmDiscard())) return;
    const t = Templates.list.find(x => x.id === tplId) || Templates.list[0];
    const meta = Fmt.defaultMeta();
    if (t.meta) {
      Object.assign(meta, t.meta);
      if (t.meta.marginsPreset) meta.margins = Object.assign({}, Fmt.MARGINS[t.meta.marginsPreset]);
      delete meta.marginsPreset;
    }
    loadDocument({ html: t.html(), meta, name: t.id === 'blank' ? 'Документ' : t.name, format: 'docx' });
    closeBackstage();
    if (doc().querySelector('.toc')) { computePages(); Ed.updateToc(pageOf); markClean(); }
    setTimeout(() => Ed.focus(), 50);
  }
  const doc = () => Ed.doc;

  async function openFile() {
    if (!(await confirmDiscard())) return;
    if (isAndroid) { Android.openDocument(); return; }
    const inp = $('#filePick');
    inp.accept = '.docx,.doc,.odt,.fodt,.rtf,.txt,.html,.htm,.md,.markdown,.pdf,.dotx';
    inp.onchange = async () => {
      const f = inp.files[0];
      inp.value = '';
      if (f) await openBytes(new Uint8Array(await f.arrayBuffer()), f.name, null, false);
    };
    inp.click();
  }

  /** Импорт байтов файла в редактор */
  async function openBytes(bytes, name, uri, canWrite) {
    closeBackstage();
    UI.toast('Открываю «' + name + '»…', 10000);
    try {
      const kind = Fmt.detect(bytes, name);
      let res;
      switch (kind) {
        case 'docx': res = await Docx.read(bytes); break;
        case 'odt': res = await Odt.read(bytes); break;
        case 'odt-flat': res = await Odt.read(bytes, true); break;
        case 'rtf': res = Rtf.read(bytes); break;
        case 'doc': res = Doc97.read(bytes); break;
        case 'html': res = TextFmt.readHtml(bytes); break;
        case 'md': res = TextFmt.readMd(bytes); break;
        case 'pdf': {
          state.pdfName = name;
          await PdfView.open(bytes, name);
          $('#workspace').hidden = true;
          setTitle(name);
          markClean();
          state.file = { name, uri, format: 'pdf', canWrite: false };
          if (uri) Store.addRecent({ name, uri, format: 'pdf' });
          UI.toast('PDF открыт для просмотра');
          return;
        }
        default: res = TextFmt.readTxt(bytes);
      }
      const writable = ['docx', 'odt', 'rtf', 'html', 'md', 'txt'].includes(kind);
      loadDocument({ html: res.html, meta: res.meta, name, uri, format: kind === 'odt-flat' ? 'odt' : kind, canWrite: writable && canWrite, warning: res.warning });
      if (uri) Store.addRecent({ name, uri, format: kind });
      UI.toast('Открыто: ' + name);
    } catch (e) {
      console.error(e);
      UI.alert('Не удалось открыть файл «' + name + '».\n\n' + (e.message || e));
    }
  }

  async function exportBytes(format) {
    const meta = Object.assign({}, state.meta, { title: state.meta.title || baseName(state.file.name) });
    Ed.renumberFootnotes && doc().querySelector('.footnotes') && Ed.renumberFootnotes();
    switch (format) {
      case 'docx': return Docx.write(doc(), meta);
      case 'odt': return Odt.write(doc(), meta);
      case 'rtf': return Rtf.write(doc(), meta);
      case 'html': return TextFmt.writeHtml(Ed.getHTML(), meta);
      case 'md': return TextFmt.writeMd(doc());
      case 'txt': return TextFmt.writeTxt(doc());
    }
    throw new Error('Неизвестный формат ' + format);
  }

  const pendingSaves = {};
  async function save() {
    if (state.file.format === 'pdf') return saveAs();
    const f = state.file;
    if (isAndroid && f.uri && f.canWrite && Fmt.FORMATS[f.format]?.write && f.format !== 'pdf') {
      try {
        const bytes = await exportBytes(f.format);
        const ok = Android.saveToUri(f.uri, Fmt.bytesToB64(bytes));
        if (ok) { markClean(); UI.toast('Сохранено: ' + f.name); Store.addRecent({ name: f.name, uri: f.uri, format: f.format }); clearAutosave(); return true; }
        UI.toast('Не удалось перезаписать файл — выберите место сохранения');
      } catch (e) { UI.alert('Ошибка сохранения: ' + e.message); return false; }
    }
    return saveAs();
  }

  function saveAs(preset) {
    return new Promise(resolve => {
      const name = h('input', { type: 'text', value: baseName(state.file.name) });
      let fmt = preset || (Fmt.FORMATS[state.file.format]?.write && state.file.format !== 'pdf' ? state.file.format : 'docx');
      const fmts = ['docx', 'odt', 'rtf', 'pdf', 'html', 'txt', 'md'];
      const list = h('div', { class: 'form' });
      const warn = h('div', { class: 'hint' });
      const setWarn = () => { warn.textContent = fmt === 'txt' ? 'Обычный текст не сохраняет оформление, таблицы и рисунки.' : fmt === 'md' ? 'Markdown сохраняет заголовки, списки, ссылки и простые таблицы.' : fmt === 'pdf' ? 'Откроется окно печати Android — выберите «Сохранить как PDF».' : fmt === 'rtf' ? 'RTF открывается в любом текстовом редакторе.' : ''; };
      for (const k of fmts) {
        const r = h('label', { class: 'chk' }, h('input', { type: 'radio', name: 'fmt', value: k, checked: k === fmt, onchange: () => { fmt = k; setWarn(); } }), Fmt.FORMATS[k].label);
        list.append(r);
      }
      setWarn();
      UI.dialog({
        title: 'Сохранить как', body: h('div', { class: 'form' }, UI.row('Имя файла', name), h('div', { class: 'hint', text: 'Формат' }), list, warn),
        buttons: [{ text: 'Отмена', value: false }, { text: 'Сохранить', primary: true, action: async close => {
          const fname = (name.value.trim() || 'Документ') + '.' + fmt;
          close(true);
          if (fmt === 'pdf') { print(true); resolve(false); return; }
          try {
            const bytes = await exportBytes(fmt);
            if (isAndroid) {
              const id = 'sv' + Date.now();
              pendingSaves[id] = { format: fmt, resolve };
              Android.saveAs(Fmt.bytesToB64(bytes), fname, Fmt.FORMATS[fmt].mime, id);
            } else {
              Fmt.download(bytes, fname, Fmt.FORMATS[fmt].mime);
              state.file.format = fmt;
              setTitle(fname); markClean(); clearAutosave();
              resolve(true);
            }
          } catch (e) { console.error(e); UI.alert('Ошибка сохранения: ' + e.message); resolve(false); }
        } }]
      }).then(v => { if (v === undefined || v === false) resolve(false); });
    });
  }

  function print(pdf) {
    if (state.file.format === 'pdf' && PdfView.isOpen()) { UI.toast('Этот PDF уже является PDF-файлом — используйте «Поделиться»'); return; }
    const title = baseName(state.file.name);
    if (pdf) UI.toast('В окне печати выберите принтер «Сохранить как PDF»', 3500);
    const imgSel = Ed.selImg;
    if (imgSel) Ed.selectImage(null);
    if (isAndroid) Android.printDocument(title); else window.print();
  }

  async function shareBytes(bytes, name, mime) {
    if (isAndroid) Android.share(Fmt.bytesToB64(bytes), name, mime);
    else Fmt.download(bytes, name, mime);
  }
  function shareDialog() {
    const list = h('div', { class: 'form' });
    const go = async fmt => {
      UI.closeTop();
      if (fmt === 'text') { const t = TextFmt.toText(doc()); if (isAndroid) Android.shareText(t); else { await navigator.clipboard?.writeText(t); UI.toast('Текст скопирован'); } return; }
      if (fmt === 'pdf') return print(true);
      const bytes = await exportBytes(fmt);
      shareBytes(bytes, baseName(state.file.name) + '.' + fmt, Fmt.FORMATS[fmt].mime);
    };
    for (const [k, l] of [['docx', 'Документ Word (.docx)'], ['pdf', 'PDF (через «Сохранить как PDF»)'], ['odt', 'OpenDocument (.odt)'], ['rtf', 'RTF'], ['html', 'Веб-страница (.html)'], ['txt', 'Файл .txt'], ['text', 'Только текст (в сообщение)']])
      list.append(h('button', { class: 'menu-item', onclick: () => go(k) }, h('span', { html: icon(k === 'pdf' ? 'pdf' : k === 'text' ? 'share' : 'file') }), l));
    UI.dialog({ title: 'Поделиться', body: list });
  }

  // ---------- автосохранение и восстановление ----------
  let autoTimer = null;
  function scheduleAutosave(now) {
    if (!S().autosave) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(autosave, now === true ? 500 : S().autosaveSec * 1000);
  }
  async function autosave() {
    if (!state.meta || state.file.format === 'pdf') return;
    try {
      await Store.put('kv', 'autosave', { html: Ed.getHTML(), meta: state.meta, file: state.file, dirty: state.dirty, time: Date.now() });
    } catch (e) { console.warn('autosave', e); }
  }
  async function clearAutosave() { await autosave(); }

  async function restore() {
    try {
      const a = await Store.get('kv', 'autosave');
      if (a && a.html != null) {
        loadDocument({ html: a.html, meta: a.meta, name: a.file?.name, uri: a.file?.uri, format: a.file?.format, canWrite: a.file?.canWrite });
        if (a.dirty) { state.dirty = true; app.classList.add('dirty'); }
        return true;
      }
    } catch (e) {}
    return false;
  }

  // ---------- библиотека документов внутри приложения ----------
  async function saveToLibrary() {
    const name = await UI.prompt('Название документа', baseName(state.file.name), { title: 'Сохранить в «Мои документы»' });
    if (!name) return;
    await Store.put('library', name, { html: Ed.getHTML(), meta: state.meta, time: Date.now(), size: Ed.getHTML().length });
    setTitle(name);
    if (!state.file.uri) markClean();
    UI.toast('Сохранено в приложении: ' + name);
  }

  // ===================================================================
  //                         FILE (backstage)
  // ===================================================================
  async function openBackstage() {
    const bs = $('#backstage');
    bs.innerHTML = '';
    const body = h('div', { class: 'bs-body' });
    bs.append(h('div', { class: 'bs-head' }, h('button', { html: icon('back'), onclick: closeBackstage }), h('b', { text: 'Файл' }), h('div', { class: 'grow' }),
      h('button', { html: icon('gear'), title: 'Настройки', onclick: () => { closeBackstage(); settingsDialog(); } })), body);
    const tile = (ic, label, fn) => h('button', { onclick: fn }, h('span', { html: icon(ic) }), label);
    body.append(h('div', { class: 'bs-grid', style: { marginTop: '8px' } },
      tile('newdoc', 'Создать', () => newDocDialog()), tile('open', 'Открыть', () => { closeBackstage(); openFile(); }),
      tile('save', 'Сохранить', () => { closeBackstage(); save(); }), tile('saveas', 'Сохранить как', () => { closeBackstage(); saveAs(); }),
      tile('library', 'В приложение', () => { closeBackstage(); saveToLibrary(); }), tile('pdf', 'Экспорт PDF', () => { closeBackstage(); print(true); }),
      tile('print', 'Печать', () => { closeBackstage(); print(); }), tile('share', 'Поделиться', () => { closeBackstage(); shareDialog(); }),
      tile('info', 'Свойства', () => { closeBackstage(); propertiesDialog(); }), tile('gear', 'Настройки', () => { closeBackstage(); settingsDialog(); }),
      tile('info', 'О программе', () => aboutDialog())));
    body.append(h('h3', { text: 'Создать по шаблону' }));
    const tg = h('div', { class: 'bs-grid' });
    for (const t of Templates.list) {
      const th = h('div', { class: 'tpl-thumb', html: t.html() });
      th.querySelectorAll('[contenteditable]').forEach(x => x.removeAttribute('contenteditable'));
      tg.append(h('button', { onclick: () => newDocument(t.id) }, th, t.name));
    }
    body.append(tg);
    const rec = Store.recent();
    if (rec.length && isAndroid) {
      body.append(h('h3', { text: 'Последние файлы' }));
      for (const r of rec) {
        const it = h('div', { class: 'list-item' }, h('span', { html: icon('file') }), h('div', { class: 't' }, h('b', { text: r.name }), h('small', { text: new Date(r.time).toLocaleString('ru-RU') + ' · ' + (r.format || '').toUpperCase() })),
          h('button', { class: 'x', html: icon('close'), title: 'Убрать из списка', onclick: e => { e.stopPropagation(); Store.removeRecent(r.uri); it.remove(); } }));
        it.addEventListener('click', async () => { if (!(await confirmDiscard())) return; closeBackstage(); UI.toast('Открываю…'); Android.reopen(r.uri); });
        body.append(it);
      }
    }
    const lib = await Store.all('library').catch(() => []);
    if (lib.length) {
      body.append(h('h3', { text: 'Мои документы (в приложении)' }));
      for (const { key, value } of lib.sort((a, b) => b.value.time - a.value.time)) {
        const it = h('div', { class: 'list-item' }, h('span', { html: icon('library') }), h('div', { class: 't' }, h('b', { text: key }), h('small', { text: new Date(value.time).toLocaleString('ru-RU') })),
          h('button', { class: 'x', html: icon('trash'), title: 'Удалить', onclick: async e => { e.stopPropagation(); if (await UI.confirm(`Удалить «${key}» из приложения?`, { ok: 'Удалить' })) { await Store.del('library', key); it.remove(); } } }));
        it.addEventListener('click', async () => { if (!(await confirmDiscard())) return; loadDocument({ html: value.html, meta: value.meta, name: key, format: 'docx' }); closeBackstage(); });
        body.append(it);
      }
    }
    bs.hidden = false;
    UI.pushLayer(bs, closeBackstage);
  }
  function closeBackstage() { const bs = $('#backstage'); if (!bs.hidden) { bs.hidden = true; UI.removeLayer(bs); } }
  function newDocDialog() {
    const box = h('div', { class: 'bs-grid', style: { padding: 0 } });
    for (const t of Templates.list) {
      const th = h('div', { class: 'tpl-thumb', html: t.html() });
      box.append(h('button', { onclick: () => { UI.closeTop(); newDocument(t.id); } }, th, t.name));
    }
    UI.dialog({ title: 'Создать документ', body: box, cls: 'wide' });
  }

  // ===================================================================
  //                              ДИАЛОГИ
  // ===================================================================
  function fontPicker(anchor) {
    const cur = Ed.current().font;
    const box = h('div', { class: 'font-list', style: { width: 'min(92vw, 360px)' } });
    const search = h('input', { type: 'search', placeholder: 'Поиск шрифта…', style: { margin: '8px', width: 'calc(100% - 16px)' } });
    const list = h('div');
    let pp;
    const render = () => {
      list.innerHTML = '';
      const q = search.value.trim().toLowerCase();
      const all = Fonts.list().filter(f => !q || f.family.toLowerCase().includes(q));
      if (!q && S().recentFonts.length) {
        list.append(h('div', { class: 'menu-title', text: 'Недавние' }));
        S().recentFonts.forEach(f => list.append(item(f)));
      }
      let grp = null;
      for (const f of all) {
        if (f.group !== grp) { grp = f.group; list.append(h('div', { class: 'menu-title', text: grp })); }
        list.append(item(f.family));
      }
      if (q && !all.length) list.append(h('button', { class: 'menu-item', text: `Использовать «${search.value.trim()}»`, onclick: () => { pp.close(); Ed.fontName(search.value.trim()); } }));
      list.append(h('div', { class: 'menu-sep' }), h('button', { class: 'menu-item', onclick: () => { pp.close(); userFontsDialog(); } }, h('span', { html: icon('plus') }), 'Добавить свой шрифт (TTF/OTF)…'));
    };
    const item = f => h('button', { class: 'menu-item' + (f === cur ? ' on' : ''), style: { fontFamily: Fonts.css(f) }, onclick: () => { pp.close(); Ed.fontName(f); } }, f);
    search.addEventListener('input', render);
    box.append(search, list);
    render();
    pp = UI.popup(anchor, box);
  }
  function sizePicker(anchor) {
    const cur = Ed.current().size;
    const sizes = [8, 9, 10, 10.5, 11, 12, 13, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 54, 60, 72, 96];
    const box = h('div', { style: { width: '170px' } });
    const inp = h('input', { type: 'number', value: cur, step: 0.5, min: 1, max: 1638, style: { margin: '8px', width: 'calc(100% - 16px)' }, inputmode: 'decimal' });
    let pp;
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { pp.close(); Ed.fontSize(parseFloat(inp.value) || cur); } });
    box.append(inp, h('button', { class: 'menu-item', text: 'Применить', onclick: () => { pp.close(); Ed.fontSize(parseFloat(inp.value) || cur); } }), h('div', { class: 'menu-sep' }));
    sizes.forEach(s => box.append(h('button', { class: 'menu-item' + (s === cur ? ' on' : ''), text: String(s).replace('.', ','), onclick: () => { pp.close(); Ed.fontSize(s); } })));
    pp = UI.popup(anchor, box);
  }

  function fontDialog() {
    const cur = Ed.current();
    const st = { font: cur.font, size: cur.size, bold: cur.bold, italic: cur.italic, u: cur.underline ? 'solid' : 'none', strike: cur.strike, dstrike: false, sup: cur.sup, sub: cur.sub, caps: false, smallcaps: false, color: null, spacing: 0, hidden: false };
    const prev = h('div', { class: 'preview-box', text: 'Съешь же ещё этих мягких французских булок. AaBbCc 123' });
    const upd = () => {
      Object.assign(prev.style, { fontFamily: Fonts.css(st.font), fontSize: st.size + 'pt', fontWeight: st.bold ? 'bold' : 'normal', fontStyle: st.italic ? 'italic' : 'normal',
        textDecorationLine: [st.u !== 'none' ? 'underline' : '', st.strike || st.dstrike ? 'line-through' : ''].join(' ').trim() || 'none', textDecorationStyle: st.dstrike ? 'double' : (st.u !== 'none' ? st.u : 'solid'),
        textTransform: st.caps ? 'uppercase' : 'none', fontVariant: st.smallcaps ? 'small-caps' : 'normal', color: st.color || '#000', letterSpacing: st.spacing + 'pt' });
    };
    const fontSel = h('input', { type: 'text', value: st.font, list: 'fontsList' });
    const dl = h('datalist', { id: 'fontsList' }, Fonts.list().map(f => h('option', { value: f.family })));
    fontSel.addEventListener('input', () => { st.font = fontSel.value; upd(); });
    const size = UI.num(st.size, { min: 1, max: 1638, step: 0.5, onChange: v => { st.size = v; upd(); } });
    size.addEventListener('input', () => { st.size = parseFloat(size.value) || st.size; upd(); });
    const styleSel = UI.select([['n', 'Обычный'], ['b', 'Полужирный'], ['i', 'Курсив'], ['bi', 'Полужирный курсив']], (st.bold ? 'b' : '') + (st.italic ? 'i' : '') || 'n', v => { st.bold = v.includes('b'); st.italic = v.includes('i'); upd(); });
    const uSel = UI.select([['none', 'Нет'], ['solid', 'Одинарное'], ['double', 'Двойное'], ['dotted', 'Точечное'], ['dashed', 'Штриховое'], ['wavy', 'Волнистое']], st.u, v => { st.u = v; upd(); });
    const colBtn = h('button', { class: 'btn', text: 'Цвет текста', onclick: e => UI.palette(e.currentTarget, c => { st.color = c === 'auto' ? null : c; colBtn.style.color = st.color || ''; upd(); }, { none: null, auto: 'Авто' }) });
    const chk = (label, key, other) => UI.check(label, st[key], v => { st[key] = v; if (v && other) { st[other] = false; form.querySelector(`[data-k="${other}"] input`).checked = false; } upd(); });
    const effects = h('fieldset', null, h('legend', { text: 'Видоизменение' }),
      ...[['Зачёркнутый', 'strike', 'dstrike'], ['Двойное зачёркивание', 'dstrike', 'strike'], ['Надстрочный', 'sup', 'sub'], ['Подстрочный', 'sub', 'sup'], ['Малые прописные', 'smallcaps', 'caps'], ['Все прописные', 'caps', 'smallcaps']].map(([l, k, o]) => { const c = chk(l, k, o); c.dataset.k = k; return c; }));
    const spacing = UI.num(0, { step: 0.1, onChange: v => { st.spacing = v || 0; upd(); } });
    const form = h('div', { class: 'form' }, dl, UI.row('Шрифт', fontSel), UI.row('Начертание', styleSel), UI.row('Размер (пт)', size), UI.row('Подчёркивание', uSel),
      h('div', null, colBtn), effects, UI.row('Межзнаковый интервал (пт)', spacing), h('div', { class: 'hint', text: 'Образец' }), prev);
    upd();
    UI.dialog({ title: 'Шрифт', body: form, buttons: [{ text: 'Отмена' }, { text: 'Применить', primary: true, action: () => {
      const css = {
        'font-family': Fonts.css(st.font), 'font-size': st.size + 'pt', 'font-weight': st.bold ? 'bold' : 'normal', 'font-style': st.italic ? 'italic' : 'normal',
        'text-decoration-line': [st.u !== 'none' ? 'underline' : '', st.strike || st.dstrike ? 'line-through' : ''].join(' ').trim() || 'none',
        'text-decoration-style': st.dstrike ? 'double' : (st.u !== 'none' ? st.u : null), 'text-transform': st.caps ? 'uppercase' : 'none',
        'font-variant': st.smallcaps ? 'small-caps' : 'normal', 'letter-spacing': st.spacing ? st.spacing + 'pt' : 'normal', color: st.color || null,
        'vertical-align': st.sup ? 'super' : st.sub ? 'sub' : 'baseline', ...(st.sup || st.sub ? { 'font-size': (st.size * 0.65).toFixed(1) + 'pt' } : {})
      };
      Ed.css(css);
      Ed.fontName && Store.S().recentFonts && (() => { const rf = S().recentFonts.filter(x => x !== st.font); rf.unshift(st.font); Store.set('recentFonts', rf.slice(0, 8)); })();
      return true;
    } }] });
  }

  function paragraphDialog() {
    const b = Ed.blocks()[0];
    if (!b) return UI.toast('Поставьте курсор в абзац');
    const cs = getComputedStyle(b);
    const pt = px => +(parseFloat(px) * 0.75).toFixed(1);
    const cm = px => +(parseFloat(px) / 96 * 2.54).toFixed(2);
    const fs = parseFloat(cs.fontSize);
    const st = {
      align: cs.textAlign === 'start' ? 'left' : cs.textAlign, left: cm(cs.marginLeft), right: cm(cs.marginRight), first: cm(cs.textIndent),
      before: pt(cs.marginTop), after: pt(cs.marginBottom), lh: cs.lineHeight === 'normal' ? 1 : +(parseFloat(cs.lineHeight) / fs / Fmt.LH).toFixed(2), lhExact: /pt$/.test(b.style.lineHeight) ? parseFloat(b.style.lineHeight) : 0,
      pbb: false, keep: b.style.breakInside === 'avoid'
    };
    const al = UI.seg([['left', 'Влево'], ['center', 'Центр'], ['right', 'Вправо'], ['justify', 'Ширина']], st.align, v => st.align = v);
    const n = (k, step = 0.1) => UI.num(st[k], { step, onChange: v => st[k] = isNaN(v) ? 0 : v });
    const firstType = UI.select([['none', 'Нет'], ['first', 'Отступ'], ['hang', 'Выступ']], st.first > 0 ? 'first' : st.first < 0 ? 'hang' : 'none');
    const firstVal = UI.num(Math.abs(st.first) || 1.25, { step: 0.05 });
    const lhMode = UI.select([['mult', 'Множитель'], ['exact', 'Точно (пт)']], st.lhExact ? 'exact' : 'mult');
    const lhVal = UI.num(st.lhExact || st.lh, { step: 0.05 });
    const pbb = UI.check('С новой страницы', false, v => st.pbb = v);
    const keep = UI.check('Не разрывать абзац', st.keep, v => st.keep = v);
    const form = h('div', { class: 'form' },
      h('fieldset', null, h('legend', { text: 'Выравнивание' }), al),
      h('fieldset', null, h('legend', { text: 'Отступы, см' }), UI.row('Слева', n('left', 0.25)), UI.row('Справа', n('right', 0.25)), UI.row('Первая строка', h('div', { class: 'r2' }, firstType, firstVal))),
      h('fieldset', null, h('legend', { text: 'Интервал' }), UI.row('Перед (пт)', n('before', 1)), UI.row('После (пт)', n('after', 1)), UI.row('Междустрочный', h('div', { class: 'r2' }, lhMode, lhVal)),
        h('div', { class: 'hint', text: '1 — одинарный, 1,5 — полуторный, 2 — двойной' })),
      h('fieldset', null, h('legend', { text: 'Положение на странице' }), pbb, keep));
    UI.dialog({ title: 'Абзац', body: form, buttons: [{ text: 'Отмена' }, { text: 'Применить', primary: true, action: () => {
      const fv = parseFloat(firstVal.value) || 0;
      const first = firstType.value === 'first' ? fv : firstType.value === 'hang' ? -fv : 0;
      const lv = parseFloat(lhVal.value) || 1;
      Ed.blockStyle(x => {
        x.style.textAlign = st.align === 'left' ? '' : st.align;
        x.style.marginLeft = st.left ? st.left + 'cm' : '';
        x.style.marginRight = st.right ? st.right + 'cm' : '';
        x.style.textIndent = first ? first + 'cm' : '0';
        if (first < 0 && !st.left) x.style.marginLeft = (-first) + 'cm';
        x.style.marginTop = st.before + 'pt';
        x.style.marginBottom = st.after + 'pt';
        x.style.lineHeight = lhMode.value === 'exact' ? lv + 'pt' : (lv * Fmt.LH).toFixed(3);
        x.style.breakInside = st.keep ? 'avoid' : '';
        if (st.pbb) x.style.breakBefore = 'page';
      });
      return true;
    } }] });
  }

  function pageSetupDialog() {
    const m = state.meta;
    const st = { w: m.pageW, h: m.pageH, o: m.orientation, t: m.margins.t, r: m.margins.r, b: m.margins.b, l: m.margins.l, cols: m.columns || 1 };
    const sizeSel = UI.select([...Object.keys(Fmt.PAGE_SIZES).map(k => [k, k]), ['custom', 'Другой']], Object.entries(Fmt.PAGE_SIZES).find(([k, [w, hh]]) => Math.abs(w - Math.min(st.w, st.h)) < 1 && Math.abs(hh - Math.max(st.w, st.h)) < 1)?.[0] || 'custom', v => {
      if (Fmt.PAGE_SIZES[v]) { [st.w, st.h] = Fmt.PAGE_SIZES[v]; wI.value = st.w; hI.value = st.h; }
    });
    const wI = UI.num(st.w, { step: 0.1, onChange: v => st.w = v }), hI = UI.num(st.h, { step: 0.1, onChange: v => st.h = v });
    const o = UI.seg([['portrait', 'Книжная'], ['landscape', 'Альбомная']], st.o, v => st.o = v);
    const mg = k => UI.num(st[k], { step: 0.5, min: 0, onChange: v => st[k] = v });
    const cols = UI.seg([[1, '1'], [2, '2'], [3, '3'], [4, '4']], st.cols, v => st.cols = v);
    const presets = h('div', { class: 'seg' }, ...[['normal', 'Обычные'], ['gost', 'ГОСТ'], ['narrow', 'Узкие'], ['office', '2,54 см']].map(([k, l]) => h('button', { type: 'button', text: l, onclick: () => {
      const p = Fmt.MARGINS[k];
      Object.assign(st, { t: p.t, r: p.r, b: p.b, l: p.l });
      [mt, mr, mb, ml].forEach((inp, i) => inp.value = [p.t, p.r, p.b, p.l][i]);
    } })));
    const mt = mg('t'), mr = mg('r'), mb = mg('b'), ml = mg('l');
    const form = h('div', { class: 'form' },
      h('fieldset', null, h('legend', { text: 'Размер бумаги' }), UI.row('Формат', sizeSel), UI.row('Ширина, мм', wI), UI.row('Высота, мм', hI), UI.row('Ориентация', o)),
      h('fieldset', null, h('legend', { text: 'Поля, мм' }), presets, UI.row('Верхнее', mt), UI.row('Нижнее', mb), UI.row('Левое', ml), UI.row('Правое', mr)),
      h('fieldset', null, h('legend', { text: 'Колонки' }), cols));
    UI.dialog({ title: 'Параметры страницы', body: form, buttons: [{ text: 'Отмена' }, { text: 'OK', primary: true, action: () => {
      setMeta({ pageW: +wI.value || st.w, pageH: +hI.value || st.h, orientation: st.o, margins: { t: +mt.value, r: +mr.value, b: +mb.value, l: +ml.value }, columns: +st.cols });
      return true;
    } }] });
  }

  function headerFooterDialog() {
    const m = state.meta;
    const hd = h('textarea', { value: m.header || '', placeholder: 'Текст вверху каждой страницы' });
    hd.value = m.header || '';
    const ft = h('textarea', { placeholder: 'Текст внизу каждой страницы' });
    ft.value = m.footer || '';
    const pn = UI.select([['none', 'Без номеров'], ['bottom-center', 'Внизу по центру'], ['bottom-right', 'Внизу справа'], ['bottom-left', 'Внизу слева'], ['top-center', 'Вверху по центру'], ['top-right', 'Вверху справа']], m.pageNumbers || 'none');
    const fmt = UI.check('Формат «Страница X из Y»', m.pageNumFormat === 'n of N');
    UI.dialog({ title: 'Колонтитулы и номера страниц', body: h('div', { class: 'form' }, h('label', { text: 'Верхний колонтитул' }), hd, h('label', { text: 'Нижний колонтитул' }), ft, UI.row('Номера страниц', pn), fmt,
      h('div', { class: 'hint', text: 'Колонтитулы и номера видны при печати, в PDF и в сохранённых DOCX/ODT/RTF.' })),
      buttons: [{ text: 'Отмена' }, { text: 'OK', primary: true, action: () => { setMeta({ header: hd.value, footer: ft.value, pageNumbers: pn.value, pageNumFormat: fmt.input.checked ? 'n of N' : 'n' }); return true; } }] });
  }

  function docDefaultsDialog() {
    const m = state.meta;
    const font = h('input', { type: 'text', value: m.defaultFont, list: 'fontsList2' });
    const dl = h('datalist', { id: 'fontsList2' }, Fonts.list().map(f => h('option', { value: f.family })));
    const size = UI.num(m.defaultSize, { step: 0.5 });
    const line = UI.num(m.defaultLine, { step: 0.05 });
    const after = UI.num(m.defaultAfter ?? 0, { step: 1 });
    const indent = UI.num(m.defaultIndent || 0, { step: 0.25 });
    const asDef = UI.check('Использовать для новых документов', false);
    UI.dialog({ title: 'Обычный стиль документа', body: h('div', { class: 'form' }, dl, UI.row('Шрифт', font), UI.row('Размер, пт', size), UI.row('Межстрочный (множитель)', line), UI.row('Интервал после абзаца, пт', after), UI.row('Отступ первой строки, см', indent), asDef,
      h('div', { class: 'hint', text: 'Применяется ко всем абзацам без собственного оформления. Для документов по ГОСТ: Times New Roman, 14 пт, 1,5, отступ 1,25 см.' })),
      buttons: [{ text: 'Отмена' }, { text: 'Применить', primary: true, action: () => {
        const patch = { defaultFont: font.value || 'Times New Roman', defaultSize: +size.value || 12, defaultLine: +line.value || 1, defaultAfter: +after.value || 0, defaultIndent: +indent.value || 0 };
        setMeta(patch);
        if (asDef.input.checked) { Store.set('defaultFont', patch.defaultFont); Store.set('defaultSize', patch.defaultSize); Store.set('defaultLine', patch.defaultLine); Store.set('defaultAfter', patch.defaultAfter); Store.set('defaultIndent', patch.defaultIndent); }
        return true;
      } }] });
  }

  function tablePicker(anchor) {
    const box = h('div');
    const grid = h('div', { class: 'tbl-picker' });
    const label = h('div', { class: 'menu-title', text: 'Таблица 1 × 1' });
    let pp, R = 1, Cc = 1;
    for (let r = 1; r <= 8; r++) for (let c = 1; c <= 8; c++) {
      const d = h('div', { 'data-r': r, 'data-c': c });
      grid.append(d);
    }
    const hl = (r, c) => { R = r; Cc = c; label.textContent = `Таблица ${c} × ${r}`; $$('div', grid).forEach(d => d.classList.toggle('on', +d.dataset.r <= r && +d.dataset.c <= c)); };
    const pick = e => { const d = e.target.closest('[data-r]'); if (d) hl(+d.dataset.r, +d.dataset.c); };
    grid.addEventListener('pointerdown', pick);
    grid.addEventListener('pointermove', e => { if (e.buttons || e.pointerType === 'mouse') { const el = document.elementFromPoint(e.clientX, e.clientY); if (el && el.dataset.r) hl(+el.dataset.r, +el.dataset.c); } });
    grid.addEventListener('pointerup', () => { pp.close(); Ed.insertTable(R, Cc); });
    hl(2, 2);
    box.append(label, grid, h('button', { class: 'menu-item', text: 'Указать размер…', onclick: () => { pp.close(); tableDialog(); } }));
    pp = UI.popup(anchor, box);
  }
  function tableDialog() {
    const r = UI.num(3, { min: 1, max: 200 }), c = UI.num(3, { min: 1, max: 30 });
    const b = UI.check('Показывать границы', true);
    UI.dialog({ title: 'Вставить таблицу', body: h('div', { class: 'form' }, UI.row('Строк', r), UI.row('Столбцов', c), b),
      buttons: [{ text: 'Отмена' }, { text: 'Вставить', primary: true, action: () => { Ed.insertTable(Math.max(1, +r.value), Math.max(1, +c.value), { borders: b.input.checked }); return true; } }] });
  }

  function linkDialog() {
    const a = Ed.caretEl()?.closest('a');
    const sel = Ed.selectedText();
    const url = h('input', { type: 'url', value: a ? a.getAttribute('href') : '', placeholder: 'https://…', autofocus: true });
    const text = h('input', { type: 'text', value: a ? a.textContent : sel, placeholder: 'Текст ссылки' });
    const heads = Ed.headings();
    const hsel = heads.length ? UI.select([['', '— место в документе —'], ...heads.map((x, i) => [i, x.textContent.slice(0, 60)])], '', v => { if (v !== '') { url.value = '#' + Ed.ensureId(heads[+v]); if (!text.value) text.value = heads[+v].textContent; } }) : null;
    const buttons = [{ text: 'Отмена' }];
    if (a) buttons.push({ text: 'Удалить ссылку', danger: true, action: () => { Ed.unlink(); return true; } });
    buttons.push({ text: 'OK', primary: true, action: () => {
      let u = url.value.trim();
      if (!u) return false;
      if (!/^(https?:|mailto:|tel:|#|ftp:)/i.test(u)) u = (/^[^@\s]+@[^@\s]+$/.test(u) ? 'mailto:' : 'https://') + u;
      Ed.link(u, text.value.trim() && text.value !== sel ? text.value.trim() : null);
      return true;
    } });
    UI.dialog({ title: a ? 'Изменить ссылку' : 'Вставить ссылку', body: h('div', { class: 'form' }, UI.row('Адрес', url), UI.row('Текст', text), hsel ? UI.row('Или раздел', hsel) : null), buttons });
  }
  function linkPopup(a) {
    if (state.reading) return;
    const href = a.getAttribute('href') || '';
    UI.menu(a, [{ title: href.length > 40 ? href.slice(0, 40) + '…' : href },
      { label: 'Открыть ссылку', icon: 'link', action: () => openLink(href) }, { label: 'Изменить', icon: 'edit', action: () => linkDialog() },
      { label: 'Копировать адрес', icon: 'copy', action: () => { if (isAndroid) Android.setClipboard(href, ''); else navigator.clipboard?.writeText(href); UI.toast('Скопировано'); } },
      { label: 'Удалить ссылку', icon: 'unlink', action: () => Ed.unlink() }]);
  }
  function openLink(href) {
    if (!href) return;
    if (href.startsWith('#')) { const t = doc().querySelector(href); t && t.scrollIntoView({ behavior: 'smooth' }); return; }
    if (isAndroid) Android.openUrl(href); else window.open(href, '_blank');
  }
  function commentPopup(span) {
    const id = span.dataset.id;
    UI.menu(span, [{ title: (span.dataset.author || 'Примечание') + (span.dataset.date ? ' · ' + new Date(span.dataset.date).toLocaleDateString('ru-RU') : '') },
      { label: span.dataset.text || '(пусто)' },
      { label: 'Изменить', icon: 'edit', action: async () => { const t = await UI.prompt('Текст примечания', span.dataset.text); if (t != null) Ed.run(() => doc().querySelectorAll(`.dp-comment[data-id="${id}"]`).forEach(s => s.dataset.text = t), { keepFocus: false }); } },
      { label: 'Удалить примечание', icon: 'trash', action: () => Ed.removeComment(id) }]);
  }

  function pickImage() {
    Ed.focus();
    const inp = $('#filePick');
    inp.accept = 'image/*';
    inp.multiple = true;
    inp.onchange = () => { [...inp.files].forEach(f => readImageFile(f)); inp.value = ''; inp.multiple = false; };
    inp.click();
  }
  /** Загрузка рисунка с уменьшением слишком больших изображений */
  function readImageFile(file) {
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = S().imageMaxPx;
        let src = fr.result, w = img.naturalWidth, hh = img.naturalHeight;
        const isPng = /png|gif/.test(file.type);
        if (Math.max(w, hh) > max || (!/png|jpeg|gif/.test(file.type))) {
          const k = Math.min(1, max / Math.max(w, hh));
          const c = document.createElement('canvas');
          c.width = Math.round(w * k); c.height = Math.round(hh * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          src = c.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.88);
          w = c.width; hh = c.height;
        }
        const maxW = Ed.doc.clientWidth || 600;
        Ed.insertImage(src, Math.min(w, maxW));
      };
      img.onerror = () => UI.toast('Не удалось прочитать рисунок');
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  function symbolDialog(startCat) {
    const cats = Object.keys(Symbols.popular);
    let cat = startCat || (S().recentSymbols.length ? 'Недавние' : cats[0]);
    const catBar = h('div', { class: 'sym-cats' });
    const grid = h('div', { class: 'sym-grid' });
    const blockSel = UI.select([['', 'Все символы Юникода: выберите блок…'], ...Symbols.blocks.map((b, i) => [i, `${b[0]} (U+${b[1].toString(16).toUpperCase().padStart(4, '0')})`])], '', v => { if (v !== '') { cat = null; renderCats(); renderGrid(Symbols.blockChars(Symbols.blocks[+v][1], Symbols.blocks[+v][2])); } });
    const code = h('input', { type: 'text', placeholder: 'Код: 00A9 или ©', style: { flex: 1 } });
    const info = h('div', { class: 'hint', text: 'Нажмите на символ, чтобы вставить. Окно остаётся открытым.' });
    const insert = ch => {
      Ed.insertText(ch);
      const rs = S().recentSymbols.filter(x => x !== ch);
      rs.unshift(ch); Store.set('recentSymbols', rs.slice(0, 40));
      info.textContent = `Вставлено: ${ch}  ·  U+${ch.codePointAt(0).toString(16).toUpperCase().padStart(4, '0')}`;
    };
    const renderGrid = chars => {
      grid.innerHTML = '';
      const frag = document.createDocumentFragment();
      for (const ch of chars) frag.append(h('button', { text: ch, title: 'U+' + ch.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'), onclick: () => insert(ch) }));
      grid.append(frag);
    };
    const renderCats = () => {
      catBar.innerHTML = '';
      const all = (S().recentSymbols.length ? ['Недавние'] : []).concat(cats);
      for (const c of all) catBar.append(h('button', { class: c === cat ? 'on' : '', text: c, onclick: () => { cat = c; renderCats(); renderGrid(c === 'Недавние' ? S().recentSymbols : Symbols.popularChars(c)); } }));
    };
    renderCats();
    renderGrid(cat === 'Недавние' ? S().recentSymbols : Symbols.popularChars(cat));
    const codeBtn = h('button', { class: 'btn', text: 'Вставить', onclick: () => {
      const v = code.value.trim();
      if (!v) return;
      const hex = v.replace(/^(U\+|0x|\\u)/i, '');
      if (/^[0-9a-f]{2,6}$/i.test(hex)) { try { insert(String.fromCodePoint(parseInt(hex, 16))); } catch (e) { UI.toast('Неверный код'); } }
      else insert(v);
    } });
    UI.dialog({ title: 'Символы', cls: 'wide', body: h('div', { class: 'form' }, catBar, blockSel, grid, h('div', { style: { display: 'flex', gap: '8px' } }, code, codeBtn), info) });
  }

  function dateDialog() {
    const d = new Date();
    const fmts = [
      d.toLocaleDateString('ru-RU'), d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) ,
      d.toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }), d.toISOString().slice(0, 10),
      `«${d.getDate()}» ${d.toLocaleDateString('ru-RU', { month: 'long', day: 'numeric' }).replace(/^\d+\s*/, '')} ${d.getFullYear()} г.`,
      d.toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' }), d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }), d.toLocaleString('ru-RU')
    ];
    const box = h('div');
    fmts.forEach(f => box.append(h('button', { class: 'menu-item', text: f, onclick: () => { UI.closeTop(); Ed.insertText(f); } })));
    UI.dialog({ title: 'Дата и время', body: box });
  }

  function wordCountDialog() {
    const all = Ed.stats(), sel = Ed.selectedText() ? Ed.stats(true) : null;
    computePages();
    const rows = [['Страниц', pageBreaks.length + 1, ''], ['Слов', all.words, sel?.words], ['Знаков (без пробелов)', all.charsNoSpaces, sel?.charsNoSpaces], ['Знаков (с пробелами)', all.chars, sel?.chars], ['Абзацев', all.paragraphs, sel?.paragraphs]];
    const t = h('table', { style: { width: '100%', borderCollapse: 'collapse' } },
      h('tr', null, h('th', { text: '', style: { textAlign: 'left' } }, ''), h('th', { text: 'Документ', style: { textAlign: 'right' } }), sel ? h('th', { text: 'Выделение', style: { textAlign: 'right' } }) : null),
      rows.map(([l, a, b]) => h('tr', { style: { borderTop: '1px solid var(--line)' } }, h('td', { text: l, style: { padding: '8px 0' } }), h('td', { text: a.toLocaleString('ru-RU'), style: { textAlign: 'right' } }), sel ? h('td', { text: b != null && b !== '' ? b.toLocaleString('ru-RU') : '', style: { textAlign: 'right' } }) : null)));
    const read = Math.max(1, Math.round(all.words / 180));
    UI.dialog({ title: 'Статистика', body: h('div', null, t, h('p', { class: 'hint', text: `Время чтения ≈ ${read} мин. Авторский лист ≈ ${(all.chars / 40000).toFixed(2)}.` })), buttons: [{ text: 'Закрыть', primary: true }] });
  }

  function propertiesDialog() {
    const m = state.meta;
    const title = h('input', { type: 'text', value: m.title || '' });
    const author = h('input', { type: 'text', value: S().author || '', placeholder: 'Ваше имя (для примечаний и свойств)' });
    const st = Ed.stats();
    UI.dialog({ title: 'Свойства документа', body: h('div', { class: 'form' }, UI.row('Файл', h('span', { text: state.file.name })), UI.row('Формат', h('span', { text: (state.file.format || '').toUpperCase() })),
      UI.row('Заголовок', title), UI.row('Автор', author), UI.row('Размер страницы', h('span', { text: `${m.pageW} × ${m.pageH} мм, ${m.orientation === 'landscape' ? 'альбомная' : 'книжная'}` })),
      UI.row('Шрифт по умолчанию', h('span', { text: `${m.defaultFont}, ${m.defaultSize} пт` })), UI.row('Слов', h('span', { text: st.words })),
      state.file.uri ? h('div', { class: 'hint', text: state.file.canWrite ? 'Файл можно перезаписать кнопкой «Сохранить».' : 'Файл открыт только для чтения — «Сохранить» предложит выбрать место.' }) : null),
      buttons: [{ text: 'Отмена' }, { text: 'OK', primary: true, action: () => { setMeta({ title: title.value }); Store.set('author', author.value); return true; } }] });
  }

  function navPane() {
    const sp = $('#sidepane');
    const scrim = h('div', { class: 'scrim', onclick: () => close() });
    const close = () => { sp.hidden = true; scrim.remove(); UI.removeLayer(sp); };
    const body = h('div', { class: 'sp-body' });
    const heads = Ed.headings();
    computePages();
    if (!heads.length) body.append(h('div', { class: 'hint', style: { padding: '14px' }, text: 'В документе нет заголовков. Примените стили «Заголовок 1…6» (вкладка «Главная» → «Стили»), чтобы перемещаться по разделам.' }));
    for (const hd of heads) {
      const lvl = +hd.tagName[1];
      body.append(h('div', { class: 'nav-item', style: { paddingLeft: (14 + (lvl - 1) * 16) + 'px', fontWeight: lvl === 1 ? '600' : '400' }, onclick: () => {
        close();
        hd.scrollIntoView({ block: 'start', behavior: 'smooth' });
        const r = document.createRange(); r.selectNodeContents(hd); r.collapse(true); Ed.setRange(r);
      } }, h('span', { text: hd.textContent.trim() || '(пустой заголовок)' }), h('small', { class: 'hint', text: '  стр. ' + pageOf(hd) })));
    }
    sp.innerHTML = '';
    sp.append(h('div', { class: 'sp-head' }, h('span', { html: icon('nav') }), 'Навигация', h('div', { class: 'grow' }), h('button', { class: 'tb', html: icon('close'), style: { border: 0, background: 'none' }, onclick: close })), body);
    document.body.append(scrim);
    sp.hidden = false;
    UI.pushLayer(sp, close);
  }
  function commentsPane() {
    const sp = $('#sidepane');
    const scrim = h('div', { class: 'scrim', onclick: () => close() });
    const close = () => { sp.hidden = true; scrim.remove(); UI.removeLayer(sp); };
    const body = h('div', { class: 'sp-body' });
    const list = Ed.comments();
    if (!list.length) body.append(h('div', { class: 'hint', style: { padding: '14px' }, text: 'Примечаний нет. Выделите текст и нажмите «Примечание».' }));
    for (const c of list) {
      body.append(h('div', { class: 'nav-item', onclick: () => { close(); c.el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } },
        h('div', { class: 'hint', text: (c.author || '') + (c.date ? ' · ' + new Date(c.date).toLocaleString('ru-RU') : '') }),
        h('div', { text: c.text }), h('div', { class: 'hint', text: '«' + c.quote.slice(0, 80) + '»' }),
        h('button', { class: 'btn danger', text: 'Удалить', style: { marginTop: '6px' }, onclick: e => { e.stopPropagation(); Ed.removeComment(c.id); e.target.closest('.nav-item').remove(); } })));
    }
    sp.innerHTML = '';
    sp.append(h('div', { class: 'sp-head' }, h('span', { html: icon('comment') }), 'Примечания', h('div', { class: 'grow' }), h('button', { class: 'tb', html: icon('close'), style: { border: 0, background: 'none' }, onclick: close })), body);
    document.body.append(scrim);
    sp.hidden = false;
    UI.pushLayer(sp, close);
  }

  // ---------- поиск и замена ----------
  function openFind(withReplace) {
    const fb = $('#findbar');
    state.findOpen = true;
    fb.hidden = false;
    fb.innerHTML = '';
    const q = h('input', { type: 'text', placeholder: 'Найти в документе', value: Ed.selectedText().slice(0, 100) });
    const rep = h('input', { type: 'text', placeholder: 'Заменить на' });
    const cnt = h('span', { class: 'cnt', text: '' });
    const opts = { cs: false, ww: false, re: false };
    const run = () => {
      const n = Ed.Find.set({ q: q.value, ...opts });
      cnt.textContent = n < 0 ? 'ошибка' : q.value ? (n ? `${n}` : 'нет') : '';
    };
    const go = d => { Ed.Find.go(d); const i = Ed.Find.info(); cnt.textContent = i.n ? `${i.cur + 1}/${i.n}` : 'нет'; };
    q.addEventListener('input', run);
    q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(e.shiftKey ? -1 : 1); } if (e.key === 'Escape') closeFind(); });
    const btn = (ic, title, fn) => h('button', { class: 'rb', title, html: icon(ic), onclick: fn });
    const repRow = h('div', { class: 'row' }, rep,
      h('button', { class: 'btn', text: 'Заменить', onclick: () => { Ed.Find.replaceOne(rep.value); const i = Ed.Find.info(); cnt.textContent = i.n ? `${i.cur + 1}/${i.n}` : 'нет'; } }),
      h('button', { class: 'btn', text: 'Все', onclick: () => { const n = Ed.Find.replaceAll(rep.value); UI.toast(`Заменено: ${n}`); run(); } }));
    repRow.hidden = !withReplace;
    const optRow = h('div', { class: 'opts' },
      UI.check('Учитывать регистр', false, v => { opts.cs = v; run(); }), UI.check('Слово целиком', false, v => { opts.ww = v; run(); }), UI.check('Рег. выражения', false, v => { opts.re = v; run(); }));
    optRow.hidden = true;
    fb.append(h('div', { class: 'row' }, q, cnt, btn('chevUp', 'Предыдущее', () => go(-1)), btn('chevDown', 'Следующее', () => go(1)),
      btn('replace', 'Замена', () => { repRow.hidden = !repRow.hidden; }), btn('more', 'Параметры', () => { optRow.hidden = !optRow.hidden; }), btn('close', 'Закрыть', closeFind)), repRow, optRow);
    setTimeout(() => { q.focus(); q.select(); run(); }, 50);
    UI.pushLayer(fb, closeFind);
  }
  function closeFind() {
    const fb = $('#findbar');
    if (fb.hidden) return;
    fb.hidden = true;
    state.findOpen = false;
    Ed.Find.clear();
    UI.removeLayer(fb);
  }

  // ---------- буфер обмена ----------
  function copySel() {
    const r = Ed.range();
    if (!r || r.collapsed) { UI.toast('Ничего не выделено'); return; }
    const div = document.createElement('div');
    div.append(r.cloneContents());
    if (isAndroid) Android.setClipboard(r.toString(), div.innerHTML);
    else document.execCommand('copy');
  }
  async function pasteFromClipboard(plain) {
    Ed.focus();
    if (isAndroid) {
      const html = plain ? '' : Android.getClipboardHtml();
      const text = Android.getClipboardText();
      if (!html && !text) return UI.toast('Буфер обмена пуст');
      Ed.pasteData(html, text, plain);
      return;
    }
    try {
      if (!plain && navigator.clipboard.read) {
        const items = await navigator.clipboard.read();
        for (const it of items) {
          if (it.types.includes('text/html')) { Ed.pasteData(await (await it.getType('text/html')).text(), '', false); return; }
          const imgType = it.types.find(t => t.startsWith('image/'));
          if (imgType) { readImageFile(await it.getType(imgType)); return; }
        }
      }
      Ed.pasteData('', await navigator.clipboard.readText(), true);
    } catch (e) { UI.toast('Нет доступа к буферу — используйте долгое нажатие → «Вставить»'); }
  }

  // ---------- формат по образцу ----------
  function startPainter() {
    if (state.painter) { state.painter = null; updateStates(); return; }
    const e = Ed.caretEl();
    if (!e) return;
    const cs = getComputedStyle(e);
    let deco = '', el = e;
    while (el && el !== Ed.doc) { const l = getComputedStyle(el).textDecorationLine; if (l && l !== 'none') deco += ' ' + l; if (Ed.blockOf(el) === el) break; el = el.parentElement; }
    state.painter = { 'font-family': cs.fontFamily, 'font-size': cs.fontSize, 'font-weight': cs.fontWeight, 'font-style': cs.fontStyle, color: cs.color, 'text-decoration-line': deco.trim() || 'none', 'background-color': cs.backgroundColor };
    UI.toast('Выделите текст, к которому применить формат');
    updateStates();
  }
  function painterApply() {
    if (!state.painter) return;
    const r = Ed.range();
    if (!r || r.collapsed) return;
    const p = state.painter;
    state.painter = null;
    Ed.css(p);
    updateStates();
  }

  // ---------- буквица ----------
  function dropCap() {
    const b = Ed.blocks()[0];
    if (!b || !b.textContent.trim()) return UI.toast('Поставьте курсор в абзац с текстом');
    Ed.run(() => {
      const w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT);
      let t;
      while ((t = w.nextNode()) && !t.data.trim());
      if (!t) return;
      const i = t.data.search(/\S/);
      const rest = t.splitText(i + 1);
      const letter = t.splitText(i);
      const span = h('span', { style: 'float:left;font-size:3.2em;line-height:0.85;margin:0.05em 0.08em 0 0;font-weight:bold' });
      letter.before(span); span.append(letter);
      void rest;
    });
  }

  // ---------- чтение вслух ----------
  let speaking = false;
  function speak() {
    if (speaking) { stopSpeak(); return; }
    const text = Ed.selectedText() || Ed.text();
    if (!text.trim()) return UI.toast('Нет текста для чтения');
    if (isAndroid && Android.speak) { Android.speak(text, state.meta.lang || 'ru'); speaking = true; UI.toast('Чтение вслух… Нажмите ещё раз, чтобы остановить'); return; }
    if (window.speechSynthesis) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = { ru: 'ru-RU', uk: 'uk-UA', en: 'en-US', de: 'de-DE' }[state.meta.lang] || 'ru-RU';
      u.onend = () => { speaking = false; };
      speechSynthesis.speak(u);
      speaking = true;
    } else UI.toast('Синтез речи недоступен');
  }
  function stopSpeak() { speaking = false; if (isAndroid && Android.stopSpeak) Android.stopSpeak(); else if (window.speechSynthesis) speechSynthesis.cancel(); }

  // ---------- режим чтения ----------
  function setReading(on) {
    state.reading = on;
    app.classList.toggle('reading', on);
    Ed.doc.contentEditable = on ? 'false' : 'true';
    Ed.selectImage(null);
    const rb = $('#readbar');
    rb.hidden = !on;
    rb.innerHTML = '';
    if (on) {
      document.activeElement && document.activeElement.blur();
      rb.append(
        h('button', { title: 'Редактировать', html: icon('edit'), onclick: () => setReading(false) }),
        h('button', { title: 'Крупнее', text: 'A+', onclick: () => zoomBy(1.1) }),
        h('button', { title: 'Мельче', text: 'A−', onclick: () => zoomBy(1 / 1.1) }),
        h('button', { title: 'Тема', html: icon('moon'), onclick: () => { const order = ['white', 'sepia', 'dark']; Store.set('paper', order[(order.indexOf(S().paper) + 1) % order.length]); applySettings(); } }),
        h('button', { title: 'Читать вслух', html: icon('speak'), onclick: () => speak() }),
        h('button', { title: 'Навигация', html: icon('nav'), onclick: () => navPane() }));
      UI.pushLayer(rb, () => setReading(false));
    } else UI.removeLayer(rb);
    updateStates();
  }

  // ---------- настройки ----------
  function settingsDialog() {
    const s = S();
    const set = (k, v) => { Store.set(k, v); applySettings(); };
    const sec = (title, ...kids) => h('fieldset', null, h('legend', { text: title }), ...kids);
    const form = h('div', { class: 'form' },
      sec('Оформление',
        UI.row('Тема', UI.seg([['system', 'Авто'], ['light', 'Светлая'], ['dark', 'Тёмная']], s.theme, v => set('theme', v))),
        UI.row('Цвет листа', UI.seg([['white', 'Белый'], ['sepia', 'Сепия'], ['gray', 'Серый'], ['dark', 'Тёмный']], s.paper, v => set('paper', v))),
        UI.row('Размер кнопок', UI.seg([['s', 'S'], ['m', 'M'], ['l', 'L'], ['xl', 'XL']], s.btnSize, v => set('btnSize', v))),
        UI.row('Масштаб интерфейса', UI.select([[0.85, '85%'], [0.9, '90%'], [1, '100%'], [1.1, '110%'], [1.2, '120%'], [1.35, '135%']], s.uiScale, v => set('uiScale', +v))),
        UI.check('Подписи у основных кнопок', s.showLabels, v => set('showLabels', v)),
        UI.check('Названия групп на ленте', s.groupLabels, v => set('groupLabels', v))),
      sec('Лента и панели',
        UI.row('Лента', UI.seg([['pinned', 'Закреплена'], ['auto', 'Автоскрытие'], ['hidden', 'Скрыта']], s.ribbonMode, v => set('ribbonMode', v))),
        UI.row('Положение ленты', UI.seg([['top', 'Сверху'], ['bottom', 'Снизу']], s.ribbonPos, v => set('ribbonPos', v))),
        UI.row('Высота ленты', UI.seg([[1, 'Одна строка'], [2, 'Две строки']], +s.ribbonRows, v => set('ribbonRows', +v))),
        UI.check('Панель быстрого доступа', s.quickbar, v => set('quickbar', v)),
        UI.row('Положение панели', UI.seg([['bottom', 'Внизу'], ['top', 'Вверху']], s.quickPos, v => set('quickPos', v))),
        h('button', { class: 'btn', text: 'Выбрать кнопки панели быстрого доступа…', onclick: () => quickDialog() }),
        UI.check('Строка состояния (страницы, слова, масштаб)', s.statusbar, v => set('statusbar', v)),
        h('div', { class: 'hint', text: 'Совет: долгое нажатие на любую кнопку ленты добавляет её на панель быстрого доступа.' })),
      sec('Отображение документа',
        UI.row('Вид', UI.seg([['mobile', 'Мобильный'], ['page', 'Страница']], s.view, v => set('view', v))),
        UI.check('Подгонять страницу по ширине экрана', s.fitWidth, v => set('fitWidth', v)),
        UI.check('Показывать границы страниц', s.guides, v => set('guides', v)),
        UI.check('Показывать знаки абзаца ¶', s.marks, v => set('marks', v)),
        UI.check('Автоматические переносы слов', s.hyphens, v => set('hyphens', v)),
        UI.check('Полноэкранный режим', s.fullscreen, v => set('fullscreen', v)),
        UI.check('Не выключать экран', s.keepScreenOn, v => set('keepScreenOn', v))),
      sec('Правка',
        UI.check('Проверка орфографии', s.spellcheck, v => set('spellcheck', v)),
        UI.check('Заглавная буква в начале предложения', s.autoCapitalize, v => set('autoCapitalize', v)),
        UI.check('«Ёлочки» вместо "кавычек" и тире вместо --', s.smartQuotes, v => set('smartQuotes', v)),
        UI.check('Вставлять из буфера только текст', s.pastePlain, v => set('pastePlain', v)),
        UI.row('Макс. размер рисунка', UI.select([[1000, '1000 px'], [1600, '1600 px'], [2000, '2000 px'], [3000, '3000 px'], [6000, 'без уменьшения']], s.imageMaxPx, v => set('imageMaxPx', +v)))),
      sec('Новые документы',
        UI.row('Шрифт', (() => { const i = h('input', { type: 'text', value: s.defaultFont, list: 'fontsList3' }); i.addEventListener('change', () => set('defaultFont', i.value)); return h('div', null, i, h('datalist', { id: 'fontsList3' }, Fonts.list().map(f => h('option', { value: f.family })))); })()),
        UI.row('Размер, пт', UI.num(s.defaultSize, { step: 0.5, onChange: v => set('defaultSize', v || 12) })),
        UI.row('Межстрочный', UI.num(s.defaultLine, { step: 0.05, onChange: v => set('defaultLine', v || 1) })),
        UI.row('После абзаца, пт', UI.num(s.defaultAfter, { step: 1, onChange: v => set('defaultAfter', v || 0) })),
        UI.row('Отступ 1-й строки, см', UI.num(s.defaultIndent, { step: 0.25, onChange: v => set('defaultIndent', v || 0) })),
        UI.row('Формат бумаги', UI.select(Object.keys(Fmt.PAGE_SIZES).map(k => [k, k]), s.pageSize, v => set('pageSize', v))),
        UI.row('Поля', UI.select([['normal', 'Обычные'], ['gost', 'ГОСТ'], ['office', 'Офисные 2,54'], ['narrow', 'Узкие'], ['moderate', 'Средние'], ['wide', 'Широкие']], s.marginsPreset, v => set('marginsPreset', v))),
        UI.row('Язык', UI.select([['ru', 'Русский'], ['uk', 'Українська'], ['en', 'English']], s.lang, v => set('lang', v))),
        UI.row('Автор', (() => { const i = h('input', { type: 'text', value: s.author, placeholder: 'Имя для примечаний' }); i.addEventListener('change', () => set('author', i.value)); return i; })())),
      sec('Сохранение',
        UI.check('Автосохранение (восстановление после закрытия)', s.autosave, v => set('autosave', v)),
        UI.row('Интервал', UI.select([[5, '5 с'], [15, '15 с'], [30, '30 с'], [60, '1 мин']], s.autosaveSec, v => set('autosaveSec', +v)))),
      sec('Шрифты', h('div', { class: 'hint', text: `Встроено шрифтов: ${Fonts.bundledCount()}. Свои шрифты: ${Fonts.userFonts().length}.` }), h('button', { class: 'btn', text: 'Управление своими шрифтами…', onclick: () => userFontsDialog() })),
      h('button', { class: 'btn danger', text: 'Сбросить все настройки', onclick: async () => { if (await UI.confirm('Вернуть настройки по умолчанию?')) { Store.reset(); applySettings(); UI.closeTop(); } } })
    );
    UI.dialog({ title: 'Настройки', body: form, cls: 'wide', buttons: [{ text: 'Готово', primary: true }] });
  }

  function quickDialog() {
    const box = h('div', { class: 'qa-list' });
    const render = () => {
      box.innerHTML = '';
      const sel = S().quickItems;
      box.append(h('div', { class: 'menu-title', text: 'На панели (порядок)' }));
      sel.forEach((id, i) => {
        const c = C[id]; if (!c) return;
        box.append(h('div', { class: 'list-item' }, h('span', { html: c.html || icon(c.icon) }), h('div', { class: 't', text: c.label }),
          h('div', { class: 'ord' }, h('button', { html: icon('up'), onclick: () => { if (i) { const a = sel.slice(); [a[i - 1], a[i]] = [a[i], a[i - 1]]; Store.set('quickItems', a); render(); renderQuick(); } } }),
            h('button', { html: icon('down'), onclick: () => { if (i < sel.length - 1) { const a = sel.slice(); [a[i + 1], a[i]] = [a[i], a[i + 1]]; Store.set('quickItems', a); render(); renderQuick(); } } }),
            h('button', { html: icon('minus'), onclick: () => { Store.set('quickItems', sel.filter(x => x !== id)); render(); renderQuick(); } }))));
      });
      box.append(h('div', { class: 'menu-title', text: 'Добавить' }));
      const seen = new Set();
      for (const t of TABS) for (const g of t.groups) for (const id of g.items || []) {
        if (seen.has(id) || sel.includes(id) || C[id]?.kind === 'combo') continue;
        seen.add(id);
        const c = C[id];
        box.append(h('div', { class: 'list-item', onclick: () => { Store.set('quickItems', [...S().quickItems, id]); render(); renderQuick(); } },
          h('span', { html: c.html || icon(c.icon) }), h('div', { class: 't' }, h('b', { text: c.label }), h('small', { text: t.label })), h('span', { html: icon('plus') })));
      }
      for (const id of ['undo', 'redo', 'save', 'alignMenu', 'readMode', 'viewMobile', 'viewPage', 'zoomIn', 'zoomOut', 'print', 'share', 'settings']) {
        if (sel.includes(id) || seen.has(id)) continue;
        const c = C[id];
        box.append(h('div', { class: 'list-item', onclick: () => { Store.set('quickItems', [...S().quickItems, id]); render(); renderQuick(); } },
          h('span', { html: c.html || icon(c.icon) }), h('div', { class: 't' }, h('b', { text: c.label }), h('small', { text: 'Общие' })), h('span', { html: icon('plus') })));
      }
    };
    render();
    UI.dialog({ title: 'Панель быстрого доступа', body: box, buttons: [
      { text: 'По умолчанию', action: () => { Store.set('quickItems', Store.DEFAULTS.quickItems.slice()); render(); renderQuick(); return false; } },
      { text: 'Готово', primary: true }] });
  }

  async function userFontsDialog() {
    const box = h('div', { class: 'form' });
    const render = () => {
      box.innerHTML = '';
      box.append(h('div', { class: 'hint', text: 'Добавьте файлы шрифтов (.ttf, .otf, .woff, .woff2) из памяти телефона — они появятся в списке шрифтов. Для полужирного и курсива добавьте отдельные файлы (например, MyFont-Bold.ttf).' }));
      const list = Fonts.userFonts();
      if (!list.length) box.append(h('div', { class: 'hint', text: 'Пока нет своих шрифтов.' }));
      for (const f of list) box.append(h('div', { class: 'list-item' }, h('div', { class: 't', style: { fontFamily: Fonts.css(f.family), fontSize: '18px' }, text: f.family }),
        h('button', { class: 'x', html: icon('trash'), onclick: async () => { await Fonts.removeUserFont(f.family); render(); } })));
      box.append(h('button', { class: 'btn primary', text: 'Добавить шрифт…', onclick: () => {
        const inp = $('#filePick');
        inp.accept = '.ttf,.otf,.woff,.woff2,font/*,application/x-font-ttf,application/x-font-otf,application/octet-stream';
        inp.multiple = true;
        inp.onchange = async () => {
          for (const f of inp.files) { try { const n = await Fonts.addUserFont(f); UI.toast('Добавлен шрифт: ' + n); } catch (e) { UI.alert('Не удалось загрузить шрифт ' + f.name + ': ' + e.message); } }
          inp.value = ''; inp.multiple = false; render();
        };
        inp.click();
      } }));
    };
    render();
    UI.dialog({ title: 'Свои шрифты', body: box, buttons: [{ text: 'Готово', primary: true }] });
  }

  function aboutDialog() {
    const v = isAndroid && Android.appVersion ? Android.appVersion() : 'веб';
    UI.dialog({ title: 'О программе', body: h('div', { class: 'form' },
      h('p', { html: `<b>DocPad</b> ${esc(v)} — текстовый редактор для Android.` }),
      h('p', { text: 'Открывает: DOCX, DOC (текст), ODT, RTF, TXT, HTML, Markdown, PDF (просмотр). Сохраняет: DOCX, ODT, RTF, PDF, HTML, TXT, Markdown.' }),
      h('p', { class: 'hint', text: 'Используются библиотеки pdf.js (Apache 2.0) и marked (MIT). Шрифты — из коллекции Google Fonts (OFL/Apache).' })),
      buttons: [{ text: 'OK', primary: true }] });
  }

  // ---------- PDF ----------
  async function pdfToDoc() {
    UI.toast('Извлекаю текст из PDF…', 6000);
    const html = await PdfView.toHtml();
    const name = baseName(state.pdfName || 'PDF') + '.docx';
    loadDocument({ html: html || '<p>В PDF нет текстового слоя (возможно, это скан).</p>', meta: Fmt.defaultMeta(), name, format: 'docx' });
    state.dirty = true; app.classList.add('dirty');
  }
  function closePdf() { PdfView.close(); $('#workspace').hidden = false; restore().then(ok => { if (!ok) newDocument('blank'); }); }

  // ===================================================================
  //                         ОБРАТНЫЕ ВЫЗОВЫ ANDROID
  // ===================================================================
  async function onFileOpened(info) {
    try {
      const b64 = Android.takeFile(info.id);
      if (!b64) throw new Error('Пустой файл');
      const bytes = Fmt.b64ToBytes(b64);
      if (info.source === 'intent' && state.dirty && !(await confirmDiscard())) return;
      await openBytes(bytes, info.name || 'document', info.uri, !!info.canWrite);
    } catch (e) { UI.alert('Ошибка открытия: ' + e.message); }
  }
  function onSaveResult(id, ok, uri, name) {
    const p = pendingSaves[id];
    delete pendingSaves[id];
    if (!ok) { UI.toast('Сохранение отменено'); p && p.resolve(false); return; }
    state.file.uri = uri;
    state.file.canWrite = true;
    if (p) state.file.format = p.format;
    setTitle(name || state.file.name);
    markClean();
    Store.addRecent({ name: state.file.name, uri, format: state.file.format });
    UI.toast('Сохранено: ' + state.file.name);
    autosave();
    p && p.resolve(true);
  }
  function onSharedText(text) {
    const html = text.split(/\r?\n/).map(l => `<p>${esc(l) || '<br>'}</p>`).join('');
    if (state.dirty || Ed.text().trim()) Ed.insertHTML(html);
    else loadDocument({ html, meta: Fmt.defaultMeta(), name: 'Новый текст' });
  }
  function onBack() {
    if (UI.closeTop()) return true;
    if (state.painter) { state.painter = null; updateStates(); return true; }
    if (Ed.selImg) { Ed.selectImage(null); return true; }
    if (S().ribbonMode === 'auto' && state.ribbonShown) { state.ribbonShown = false; applyRibbonVisibility(); return true; }
    if (PdfView.isOpen()) { closePdf(); return true; }
    autosave();
    return false;
  }

  // ===================================================================
  //                             ЗАПУСК
  // ===================================================================
  async function init() {
    Store.loadSettings();
    // CSS для экспорта (отключает экранные цвета листа)
    document.head.append(h('style', { text: 'html.exporting { --paper: #fff !important; --paper-fg: #000 !important; } html.exporting #doc .dp-comment { background: none !important; }' }));
    $$('#topbar [data-cmd]').forEach(b => { const c = C[b.dataset.cmd]; if (c) b.innerHTML = c.html || icon(c.icon); });
    await Fonts.init();
    document.addEventListener('pointerdown', keepFocus, true);
    document.addEventListener('click', onCmdClick);
    document.addEventListener('pointerdown', onLongPressStart);
    ['pointerup', 'pointercancel', 'pointerleave', 'scroll'].forEach(ev => document.addEventListener(ev, cancelLongPress, true));
    document.addEventListener('contextmenu', e => { if (e.target.closest('[data-cmd]')) e.preventDefault(); });
    $('#docTitle').addEventListener('click', async () => {
      const n = await UI.prompt('Имя документа', baseName(state.file.name), { title: 'Переименовать' });
      if (n) { const ext = (state.file.name.match(/\.[^.]+$/) || [''])[0]; setTitle(n + ext); }
    });
    Ed.on('change', () => { markDirty(); schedulePages(); updateStates(); Ed.positionHandle(); });
    Ed.on('selection', () => { updateStates(); clearTimeout(stBarT); stBarT = setTimeout(updateStatus, 300); });
    document.addEventListener('pointerup', () => setTimeout(painterApply, 10));
    // скрывать ленту при наборе текста (режим «автоскрытие»)
    Ed.doc.addEventListener('focus', () => { if (S().ribbonMode === 'auto' && state.ribbonShown) { state.ribbonShown = false; applyRibbonVisibility(); } });
    Ed.doc.addEventListener('pointerdown', () => { if (S().ribbonMode === 'auto' && state.ribbonShown) { state.ribbonShown = false; applyRibbonVisibility(); } });
    window.addEventListener('resize', () => { if (S().fitWidth) fitWidth(); schedulePages(); });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => applySettings());
    document.addEventListener('keydown', onKey);
    window.addEventListener('beforeunload', () => { autosave(); });
    document.addEventListener('visibilitychange', () => { if (document.hidden) autosave(); });

    const restored = await restore();
    if (!restored) newDocument('blank');
    applySettings();
    updateBars();
  }
  let stBarT = null;

  function onKey(e) {
    const k = e.key.toLowerCase();
    const mod = e.ctrlKey || e.metaKey;
    if (e.key === 'Escape') { if (UI.closeTop()) e.preventDefault(); return; }
    if (!mod) { if (e.key === 'F3') { e.preventDefault(); Ed.Find.go(e.shiftKey ? -1 : 1); } return; }
    const map = {
      s: () => e.shiftKey ? saveAs() : save(), o: openFile, n: () => newDocDialog(), p: () => print(), f: () => openFind(false), h: () => openFind(true),
      b: () => Ed.exec('bold'), i: () => Ed.exec('italic'), u: () => Ed.exec('underline'), z: () => e.shiftKey ? Ed.Hist.redo() : Ed.Hist.undo(), y: () => Ed.Hist.redo(),
      l: () => Ed.align('left'), e: () => Ed.align('center'), r: () => Ed.align('right'), j: () => Ed.align('justify'), k: () => linkDialog(),
      enter: () => Ed.pageBreak(), ']': () => Ed.growFont(1), '[': () => Ed.growFont(-1), '=': () => e.shiftKey ? Ed.exec('superscript') : Ed.exec('subscript'),
      d: () => fontDialog(), '1': () => Ed.lineHeight(Fmt.LH), '2': () => Ed.lineHeight(2 * Fmt.LH), '5': () => Ed.lineHeight(1.5 * Fmt.LH), ' ': () => Ed.clearFormat()
    };
    const fn = map[k];
    if (fn) { e.preventDefault(); fn(); }
  }

  return {
    init, state, onFileOpened, onSaveResult, onSharedText, onBack, onError: msg => UI.alert(msg), onFileCancelled: () => {}, onPause: () => autosave(),
    readImageFile, linkPopup, openLink, commentPopup, pdfToDoc, closePdf, openBytes, save, saveAs, exportBytes, loadDocument, setMeta, computePages, C, newDocument, applySettings
  };
})();

document.addEventListener('DOMContentLoaded', () => App.init());
