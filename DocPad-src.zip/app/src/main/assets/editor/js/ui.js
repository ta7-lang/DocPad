/* Элементы интерфейса: диалоги, меню, палитры, уведомления */
'use strict';
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k in el && typeof v !== 'string') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const UI = (() => {
  const layer = () => $('#layer');
  const stack = [];   // открытые слои (для кнопки «Назад»)

  function pushLayer(el, close) { stack.push({ el, close }); }
  function closeTop() {
    const t = stack.pop();
    if (!t) return false;
    t.close();
    return true;
  }
  function removeLayer(el) {
    const i = stack.findIndex(x => x.el === el);
    if (i >= 0) stack.splice(i, 1);
  }

  /** Модальный диалог. Возвращает промис со значением, переданным в close(). */
  function dialog({ title, body, buttons = [], cls = '', onOpen, dismissable = true }) {
    return new Promise(resolve => {
      let closed = false;
      const bg = h('div', { class: 'modal-bg' });
      const m = h('div', { class: 'modal ' + cls });
      const close = val => {
        if (closed) return;
        closed = true;
        bg.remove();
        removeLayer(bg);
        resolve(val);
      };
      const head = h('div', { class: 'mh' }, h('span', null, title || ''),
        h('button', { class: 'x', html: '×', 'aria-label': 'Закрыть', onclick: () => close(undefined) }));
      const mb = h('div', { class: 'mb' });
      if (typeof body === 'string') mb.innerHTML = body; else if (body) mb.append(body);
      m.append(head, mb);
      if (buttons.length) {
        const mf = h('div', { class: 'mf' });
        for (const b of buttons) {
          mf.append(h('button', {
            class: 'btn' + (b.primary ? ' primary' : '') + (b.danger ? ' danger' : ''),
            text: b.text,
            onclick: async () => {
              if (b.action) {
                const r = await b.action(close, mb);
                if (r === false) return;
                if (r !== undefined && !closed) return close(r);
              }
              if (!closed) close(b.value);
            }
          }));
        }
        m.append(mf);
      }
      bg.append(m);
      if (dismissable) bg.addEventListener('pointerdown', e => { if (e.target === bg) close(undefined); });
      layer().append(bg);
      pushLayer(bg, () => close(undefined));
      onOpen && onOpen(mb, close);
      const f = mb.querySelector('[autofocus]');
      if (f) setTimeout(() => { f.focus(); f.select && f.select(); }, 50);
    });
  }

  function alert(msg, title = 'DocPad') {
    return dialog({ title, body: h('div', { text: msg, style: { whiteSpace: 'pre-wrap' } }), buttons: [{ text: 'OK', primary: true, value: true }] });
  }
  function confirm(msg, { title = 'Подтверждение', ok = 'Да', cancel = 'Отмена', third } = {}) {
    const buttons = [{ text: cancel, value: false }];
    if (third) buttons.push({ text: third, value: 'third' });
    buttons.push({ text: ok, primary: true, value: true });
    return dialog({ title, body: h('div', { text: msg, style: { whiteSpace: 'pre-wrap' } }), buttons });
  }
  function prompt(label, value = '', { title = '', type = 'text', placeholder = '' } = {}) {
    const inp = h('input', { type, value, placeholder, autofocus: true });
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('.modal .btn.primary', layer())?.click(); } });
    return dialog({
      title: title || label, body: h('div', { class: 'form' }, title ? h('div', { text: label }) : null, inp),
      buttons: [{ text: 'Отмена', value: null }, { text: 'OK', primary: true, action: () => inp.value }]
    });
  }

  /** Всплывающая панель у кнопки. */
  function popup(anchor, content, { onClose, width } = {}) {
    const bg = h('div', { style: { position: 'fixed', inset: 0, zIndex: 65 } });
    const p = h('div', { class: 'popup' });
    if (width) p.style.width = width;
    p.append(content);
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      bg.remove(); p.remove(); removeLayer(p);
      onClose && onClose();
    };
    bg.addEventListener('pointerdown', e => { e.preventDefault(); close(); });
    layer().append(bg, p);
    // позиционирование
    const vw = window.innerWidth, vh = window.innerHeight;
    const r = anchor ? anchor.getBoundingClientRect() : { left: vw / 2 - 100, right: vw / 2 + 100, top: vh / 3, bottom: vh / 3, width: 200 };
    const pw = Math.min(p.offsetWidth, vw - 8);
    let left = Math.max(4, Math.min(r.left, vw - pw - 4));
    p.style.left = left + 'px';
    const ph = p.offsetHeight;
    const below = vh - r.bottom, above = r.top;
    if (below >= ph + 8 || below >= above) { p.style.top = (r.bottom + 4) + 'px'; p.style.maxHeight = (below - 12) + 'px'; }
    else { p.style.top = Math.max(4, r.top - Math.min(ph, above - 8) - 4) + 'px'; p.style.maxHeight = (above - 12) + 'px'; }
    pushLayer(p, close);
    // кнопки внутри меню не должны забирать фокус у документа
    p.addEventListener('pointerdown', e => { if (!e.target.closest('input,select,textarea')) e.preventDefault(); });
    return { el: p, close };
  }

  /** Меню: items = [{label, icon, action, on, sep, title, disabled, style}] */
  function menu(anchor, items, opts = {}) {
    const box = h('div', { class: opts.cls || '' });
    let pp;
    for (const it of items) {
      if (it.sep) { box.append(h('div', { class: 'menu-sep' })); continue; }
      if (it.title) { box.append(h('div', { class: 'menu-title', text: it.title })); continue; }
      const b = h('button', { class: 'menu-item' + (it.on ? ' on' : ''), disabled: it.disabled },
        it.icon ? h('span', { html: icon(it.icon) }) : null,
        h('span', { text: it.label, style: it.style || null }), it.small ? h('small', { text: it.small }) : null);
      b.addEventListener('click', () => { pp.close(); it.action && it.action(); });
      box.append(b);
    }
    pp = popup(anchor, box, opts);
    return pp;
  }

  const THEME_COLORS = [
    ['#FFFFFF', '#000000', '#E7E6E6', '#44546A', '#4472C4', '#ED7D31', '#A5A5A5', '#FFC000', '#5B9BD5', '#70AD47'],
    ['#F2F2F2', '#7F7F7F', '#D0CECE', '#D6DCE4', '#D9E2F3', '#FBE5D5', '#EDEDED', '#FFF2CC', '#DEEBF6', '#E2EFD9'],
    ['#D8D8D8', '#595959', '#AEABAB', '#ADB9CA', '#B4C6E7', '#F7CAAC', '#DBDBDB', '#FEE599', '#BDD7EE', '#C5E0B3'],
    ['#BFBFBF', '#3F3F3F', '#757070', '#8496B0', '#8EAADB', '#F4B183', '#C9C9C9', '#FFD965', '#9CC3E5', '#A8D08D'],
    ['#A5A5A5', '#262626', '#3A3838', '#323F4F', '#2F5496', '#C55A11', '#7B7B7B', '#BF9000', '#2E75B5', '#538135'],
    ['#7F7F7F', '#0C0C0C', '#171616', '#222A35', '#1F3864', '#833C0B', '#525252', '#7F6000', '#1E4E79', '#375623']
  ];
  const STD_COLORS = ['#C00000', '#FF0000', '#FFC000', '#FFFF00', '#92D050', '#00B050', '#00B0F0', '#0070C0', '#002060', '#7030A0'];
  const HIGHLIGHTS = ['#FFFF00', '#00FF00', '#00FFFF', '#FF00FF', '#0000FF', '#FF0000', '#000080', '#008080', '#008000', '#800080', '#800000', '#808000', '#808080', '#C0C0C0', '#000000'];

  /** Палитра цветов. onPick(color|null) */
  function palette(anchor, onPick, { none = 'Нет цвета', highlight = false, auto = null } = {}) {
    const box = h('div', { class: 'palette' });
    let pp;
    const pick = c => {
      pp.close();
      if (c) {
        const rc = Store.S().recentColors.filter(x => x !== c);
        rc.unshift(c); Store.set('recentColors', rc.slice(0, 10));
      }
      onPick(c);
    };
    const row = arr => h('div', { class: 'sw-row' }, arr.map(c => h('div', { class: 'sw', title: c, style: { background: c }, onclick: () => pick(c) })));
    if (auto) box.append(h('button', { class: 'menu-item', text: auto, onclick: () => pick('auto') }));
    if (none) box.append(h('button', { class: 'menu-item', onclick: () => pick(null) }, h('div', { class: 'sw none' }), none));
    if (highlight) {
      box.append(h('div', { class: 'menu-title', text: 'Маркер' }), row(HIGHLIGHTS.slice(0, 10)), row(HIGHLIGHTS.slice(10)));
    } else {
      box.append(h('div', { class: 'menu-title', text: 'Цвета темы' }));
      THEME_COLORS.forEach(r => box.append(row(r)));
      box.append(h('div', { class: 'menu-title', text: 'Стандартные' }), row(STD_COLORS));
    }
    const rc = Store.S().recentColors;
    if (rc.length) box.append(h('div', { class: 'menu-title', text: 'Последние' }), row(rc));
    const custom = h('input', { type: 'color', value: '#2B579A', style: { width: '56px', height: '36px', border: 0, background: 'none' } });
    custom.addEventListener('change', () => pick(custom.value));
    box.append(h('div', { class: 'menu-title', text: 'Другой цвет' }), h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, custom,
      h('span', { class: 'hint', text: 'выберите любой цвет' })));
    pp = popup(anchor, box);
    return pp;
  }

  let toastTimer;
  function toast(msg, ms = 2200) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms);
  }

  /** Сегментированный переключатель */
  function seg(options, value, onChange) {
    const box = h('div', { class: 'seg' });
    for (const [v, label] of options) {
      const b = h('button', { type: 'button', class: v === value ? 'on' : '', text: label });
      b.addEventListener('click', () => {
        $$('button', box).forEach(x => x.classList.remove('on'));
        b.classList.add('on');
        box.value = v;
        onChange && onChange(v);
      });
      box.append(b);
    }
    box.value = value;
    return box;
  }

  function row(label, ctrl) { return h('div', { class: 'r' }, h('label', { text: label }), ctrl); }
  function check(label, checked, onChange) {
    const inp = h('input', { type: 'checkbox', checked: !!checked });
    inp.addEventListener('change', () => onChange && onChange(inp.checked));
    const l = h('label', { class: 'chk' }, inp, label);
    l.input = inp;
    return l;
  }
  function select(options, value, onChange) {
    const s = h('select', null, options.map(([v, l]) => h('option', { value: v, text: l, selected: String(v) === String(value) })));
    s.addEventListener('change', () => onChange && onChange(s.value));
    return s;
  }
  function num(value, { min, max, step = 1, onChange } = {}) {
    const i = h('input', { type: 'number', value, min, max, step, inputmode: 'decimal' });
    i.addEventListener('change', () => onChange && onChange(parseFloat(i.value)));
    return i;
  }

  return { dialog, alert, confirm, prompt, popup, menu, palette, toast, seg, row, check, select, num, closeTop, stack, pushLayer, removeLayer };
})();
