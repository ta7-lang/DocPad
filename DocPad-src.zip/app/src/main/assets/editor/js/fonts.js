/* Каталог шрифтов: офисные имена (с метрически совместимыми заменами), встроенные
   в приложение (скачиваются при сборке), системные шрифты Android и шрифты,
   добавленные пользователем (TTF/OTF/WOFF/WOFF2). */
'use strict';
const Fonts = (() => {
  // Привычные имена из Word. Если встроенная замена есть — она подключена в fonts.css под этим же именем.
  const OFFICE = [
    ['Arial', 'sans'], ['Arial Narrow', 'sans'], ['Bookman Old Style', 'serif'], ['Calibri', 'sans'], ['Calibri Light', 'sans'],
    ['Cambria', 'serif'], ['Candara', 'sans'], ['Century Gothic', 'sans'], ['Comic Sans MS', 'hand'], ['Consolas', 'mono'],
    ['Constantia', 'serif'], ['Corbel', 'sans'], ['Courier New', 'mono'], ['Franklin Gothic', 'sans'], ['Garamond', 'serif'],
    ['Georgia', 'serif'], ['Helvetica', 'sans'], ['Impact', 'sans'], ['Lucida Console', 'mono'], ['Palatino Linotype', 'serif'],
    ['Segoe UI', 'sans'], ['Tahoma', 'sans'], ['Times New Roman', 'serif'], ['Trebuchet MS', 'sans'], ['Verdana', 'sans']
  ];
  // Шрифты, которые есть в Android «из коробки»
  const SYSTEM = [
    ['Roboto', 'sans'], ['sans-serif', 'sans'], ['sans-serif-light', 'sans'], ['sans-serif-medium', 'sans'], ['sans-serif-black', 'sans'],
    ['sans-serif-thin', 'sans'], ['sans-serif-condensed', 'sans'], ['sans-serif-smallcaps', 'sans'], ['Noto Sans', 'sans'],
    ['serif', 'serif'], ['Noto Serif', 'serif'], ['monospace', 'mono'], ['serif-monospace', 'mono'], ['Droid Sans Mono', 'mono'],
    ['Cutive Mono', 'mono'], ['casual', 'hand'], ['Coming Soon', 'hand'], ['cursive', 'hand'], ['Dancing Script', 'hand'],
    ['Carrois Gothic SC', 'sans'], ['Noto Color Emoji', 'sans']
  ];
  const FALLBACK = { sans: 'sans-serif', serif: 'serif', mono: 'monospace', hand: 'cursive', display: 'sans-serif' };
  let bundled = [];     // [{family, cat}]
  let user = [];        // [{family}]
  const cats = new Map();

  function guessCat(name) {
    if (cats.has(name)) return cats.get(name);
    if (/mono|courier|consol|code|typewriter/i.test(name)) return 'mono';
    if (/sans|arial|helvet|verdana|tahoma|calibri|segoe|roboto|gothic|grotesk|inter|open|ubuntu|nunito|montserrat|lato/i.test(name)) return 'sans';
    if (/script|hand|brush|comic|casual|caveat|marck|pacifico|lobster/i.test(name)) return 'hand';
    return 'serif';
  }
  /** CSS-значение font-family для имени шрифта */
  function css(name) {
    const generic = ['sans-serif', 'serif', 'monospace', 'cursive', 'fantasy', 'system-ui'];
    if (generic.includes(name)) return name;
    return `"${name.replace(/"/g, '')}", ${FALLBACK[guessCat(name)] || 'serif'}`;
  }
  /** Первое имя из значения font-family */
  function first(cssValue) {
    if (!cssValue) return '';
    const m = cssValue.match(/^\s*(?:"([^"]+)"|'([^']+)'|([^,]+))/);
    return m ? (m[1] || m[2] || m[3]).trim() : cssValue;
  }

  async function init() {
    OFFICE.forEach(([n, c]) => cats.set(n, c));
    SYSTEM.forEach(([n, c]) => cats.set(n, c));
    try {
      const r = await fetch('fonts/fonts.json');
      if (r.ok) {
        const j = await r.json();
        bundled = (j.families || []).map(f => ({ family: f.family, cat: f.cat || guessCat(f.family) }));
        bundled.forEach(f => cats.set(f.family, f.cat));
      }
    } catch (e) { /* шрифты не скачаны при сборке — работаем с системными */ }
    await loadUserFonts();
  }

  async function loadUserFonts() {
    user = [];
    try {
      const all = await Store.all('fonts');
      for (const { key, value } of all) {
        const fam = value.family || key;
        try {
          const ff = new FontFace(fam, value.data, value.desc || {});
          await ff.load();
          document.fonts.add(ff);
          if (!user.find(u => u.family === fam)) user.push({ family: fam });
        } catch (e) { console.warn('font', key, e); }
      }
    } catch (e) {}
  }

  /** Добавить файл шрифта пользователя */
  async function addUserFont(file) {
    const data = await file.arrayBuffer();
    let name = file.name.replace(/\.(ttf|otf|woff2?|ttc)$/i, '').replace(/[-_]+(regular|normal)$/i, '');
    const desc = {};
    const m = name.match(/^(.*?)[-_ ]+(bold ?italic|bolditalic|bold|italic|light|medium|semibold|black|thin)$/i);
    if (m) {
      name = m[1];
      const st = m[2].toLowerCase();
      if (st.includes('italic')) desc.style = 'italic';
      if (st.includes('bold')) desc.weight = st.includes('semi') ? '600' : '700';
      else if (st === 'light') desc.weight = '300';
      else if (st === 'medium') desc.weight = '500';
      else if (st === 'black') desc.weight = '900';
      else if (st === 'thin') desc.weight = '100';
    }
    name = name.replace(/[_]+/g, ' ').trim();
    // разные начертания одного семейства храним под разными ключами, но регистрируем под одним именем
    const storeKey = name + (desc.weight ? '#' + desc.weight : '') + (desc.style ? '#' + desc.style : '');
    const ff = new FontFace(name, data, desc);
    await ff.load();
    document.fonts.add(ff);
    await Store.put('fonts', storeKey, { data, desc, family: name });
    if (!user.find(u => u.family === name)) user.push({ family: name });
    return name;
  }
  async function removeUserFont(family) {
    const all = await Store.all('fonts');
    for (const { key, value } of all) if ((value.family || key) === family) await Store.del('fonts', key);
    user = user.filter(u => u.family !== family);
  }

  function list() {
    const seen = new Set();
    const out = [];
    const add = (family, group) => { if (!seen.has(family)) { seen.add(family); out.push({ family, group }); } };
    user.forEach(u => add(u.family, 'Мои шрифты'));
    OFFICE.forEach(([n]) => add(n, 'Офисные'));
    bundled.forEach(b => add(b.family, 'Встроенные'));
    SYSTEM.forEach(([n]) => add(n, 'Системные Android'));
    return out;
  }
  function userFonts() { return user.slice(); }
  function bundledCount() { return bundled.length; }

  return { init, list, css, first, addUserFont, removeUserFont, userFonts, bundledCount, loadUserFonts, guessCat };
})();
