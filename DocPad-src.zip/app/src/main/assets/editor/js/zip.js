/* Минимальная реализация ZIP (чтение и запись) без сторонних библиотек.
   Использует встроенные в WebView CompressionStream / DecompressionStream. */
'use strict';
const Zip = (() => {
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  async function streamThrough(data, stream) {
    const s = new Blob([data]).stream().pipeThrough(stream);
    return new Uint8Array(await new Response(s).arrayBuffer());
  }
  const inflate = d => streamThrough(d, new DecompressionStream('deflate-raw'));
  const deflate = d => streamThrough(d, new CompressionStream('deflate-raw'));
  const enc = new TextEncoder();
  const dec = new TextDecoder('utf-8');

  /** Читает ZIP. Возвращает объект { files: {path: entry}, text(path), bytes(path), has(path), list() } */
  async function read(input) {
    const u8 = input instanceof Uint8Array ? input : new Uint8Array(input);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Файл повреждён или не является ZIP-архивом');
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const entries = {};
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const flags = dv.getUint16(p + 8, true);
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const nlen = dv.getUint16(p + 28, true);
      const xlen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const off = dv.getUint32(p + 42, true);
      const nameBytes = u8.subarray(p + 46, p + 46 + nlen);
      const name = (flags & 0x800) ? dec.decode(nameBytes) : Array.from(nameBytes, b => String.fromCharCode(b)).join('');
      entries[name] = { name, method, csize, off };
      p += 46 + nlen + xlen + clen;
    }
    const cache = {};
    async function bytes(name) {
      const e = entries[name] || entries[Object.keys(entries).find(k => k.toLowerCase() === String(name).toLowerCase())];
      if (!e) return null;
      if (cache[e.name]) return cache[e.name];
      const lnl = dv.getUint16(e.off + 26, true), lxl = dv.getUint16(e.off + 28, true);
      const start = e.off + 30 + lnl + lxl;
      const raw = u8.subarray(start, start + e.csize);
      let out;
      if (e.method === 0) out = raw.slice();
      else if (e.method === 8) out = await inflate(raw);
      else throw new Error('Неподдерживаемый метод сжатия ZIP: ' + e.method);
      cache[e.name] = out;
      return out;
    }
    return {
      files: entries,
      list: () => Object.keys(entries),
      has: n => !!entries[n],
      bytes,
      text: async n => { const b = await bytes(n); return b ? dec.decode(b) : null; }
    };
  }

  function dosTime(d) {
    return {
      time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1),
      date: ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
    };
  }

  /** Создаёт ZIP. files: [{name, data: string|Uint8Array, store?: bool}] */
  async function write(files) {
    const parts = [], central = [];
    let offset = 0;
    const { time, date } = dosTime(new Date());
    for (const f of files) {
      const data = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
      const nameB = enc.encode(f.name);
      const crc = crc32(data);
      let method = 0, comp = data;
      if (!f.store && data.length > 64) {
        const d = await deflate(data);
        if (d.length < data.length) { method = 8; comp = d; }
      }
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x800, true);
      lh.setUint16(8, method, true); lh.setUint16(10, time, true); lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true); lh.setUint32(18, comp.length, true); lh.setUint32(22, data.length, true);
      lh.setUint16(26, nameB.length, true); lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), nameB, comp);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x800, true); ch.setUint16(10, method, true); ch.setUint16(12, time, true);
      ch.setUint16(14, date, true); ch.setUint32(16, crc, true); ch.setUint32(20, comp.length, true);
      ch.setUint32(24, data.length, true); ch.setUint16(28, nameB.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), nameB);
      offset += 30 + nameB.length + comp.length;
    }
    const cdSize = central.reduce((s, a) => s + a.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
    const all = [...parts, ...central, new Uint8Array(end.buffer)];
    const out = new Uint8Array(all.reduce((s, a) => s + a.length, 0));
    let o = 0;
    for (const a of all) { out.set(a, o); o += a.length; }
    return out;
  }

  return { read, write, crc32 };
})();
