/* Чтение и запись ODT (OpenDocument Text — LibreOffice, OpenOffice, WPS) */
'use strict';
const Odt = (() => {
  const NS = {
    office: 'urn:oasis:names:tc:opendocument:xmlns:office:1.0', style: 'urn:oasis:names:tc:opendocument:xmlns:style:1.0',
    text: 'urn:oasis:names:tc:opendocument:xmlns:text:1.0', table: 'urn:oasis:names:tc:opendocument:xmlns:table:1.0',
    draw: 'urn:oasis:names:tc:opendocument:xmlns:drawing:1.0', fo: 'urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0',
    xlink: 'http://www.w3.org/1999/xlink', svg: 'urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0',
    dc: 'http://purl.org/dc/elements/1.1/', meta: 'urn:oasis:names:tc:opendocument:xmlns:meta:1.0'
  };
  const parse = s => new DOMParser().parseFromString(s, 'application/xml');
  const A = (el, ns, n) => el ? el.getAttributeNS(NS[ns], n) : null;
  const kids = (el, n) => el ? [...el.children].filter(c => c.localName === n) : [];
  const deep = (el, n) => el ? [...el.getElementsByTagNameNS('*', n)] : [];

  // ===================== ЧТЕНИЕ =====================
  async function read(bytes, flat) {
    let content, stylesX, zip = null;
    if (flat) { content = parse(Fmt.decodeText(bytes)); stylesX = content; }
    else {
      zip = await Zip.read(bytes);
      content = parse(await zip.text('content.xml'));
      const st = await zip.text('styles.xml');
      stylesX = st ? parse(st) : null;
    }
    const ctx = { styles: {}, fonts: {}, lists: {}, zip, meta: Fmt.defaultMeta(), imgPromises: [], notes: [] };
    ctx.meta.defaultIndent = 0;
    for (const doc of [stylesX, content]) {
      if (!doc) continue;
      for (const ff of deep(doc, 'font-face')) ctx.fonts[A(ff, 'style', 'name')] = (A(ff, 'svg', 'font-family') || A(ff, 'style', 'name') || '').replace(/^['"]|['"]$/g, '');
      for (const s of deep(doc, 'style')) {
        if (s.parentElement && s.parentElement.localName === 'default-style') continue;
        const tp = deep(s, 'text-properties')[0], pp = deep(s, 'paragraph-properties')[0], cp = deep(s, 'table-cell-properties')[0];
        ctx.styles[A(s, 'style', 'name')] = {
          family: A(s, 'style', 'family'), parent: A(s, 'style', 'parent-style-name'), display: A(s, 'style', 'display-name') || '',
          t: tp ? attrs(tp) : {}, p: pp ? attrs(pp) : {}, c: cp ? attrs(cp) : {}, listStyle: A(s, 'style', 'list-style-name')
        };
      }
      for (const ds of deep(doc, 'default-style')) {
        if (A(ds, 'style', 'family') !== 'paragraph') continue;
        const tp = deep(ds, 'text-properties')[0];
        if (tp) { const t = attrs(tp); if (t['font-name']) ctx.meta.defaultFont = ctx.fonts[t['font-name']] || t['font-name']; if (t['font-size']) ctx.meta.defaultSize = Fmt.toPt(t['font-size']); }
      }
      for (const ls of deep(doc, 'list-style')) {
        const lv = {};
        for (const l of ls.children) lv[+A(l, 'text', 'level') - 1] = { bullet: l.localName === 'list-level-style-bullet', fmt: A(l, 'style', 'num-format') || '1', start: +(A(l, 'text', 'start-value') || 1) };
        ctx.lists[A(ls, 'style', 'name')] = lv;
      }
    }
    const std = ctx.styles.Standard || ctx.styles.Default;
    if (std) {
      const t = chain(ctx, 'Standard', 't');
      if (t['font-name']) ctx.meta.defaultFont = ctx.fonts[t['font-name']] || t['font-name'];
      if (t['font-size'] && !/%/.test(t['font-size'])) ctx.meta.defaultSize = Fmt.toPt(t['font-size']);
    }
    ctx.meta.defaultAfter = 0; ctx.meta.defaultLine = 1;
    // параметры страницы
    if (stylesX) {
      const pl = deep(stylesX, 'page-layout-properties')[0];
      if (pl) {
        const mm = v => v ? +(Fmt.toPt(v) / 72 * 25.4).toFixed(1) : null;
        const w = mm(A(pl, 'fo', 'page-width')), hh = mm(A(pl, 'fo', 'page-height'));
        if (w && hh) { ctx.meta.pageW = w; ctx.meta.pageH = hh; }
        ctx.meta.orientation = A(pl, 'style', 'print-orientation') === 'landscape' ? 'landscape' : 'portrait';
        const m = ctx.meta.margins;
        m.t = mm(A(pl, 'fo', 'margin-top')) ?? m.t; m.b = mm(A(pl, 'fo', 'margin-bottom')) ?? m.b;
        m.l = mm(A(pl, 'fo', 'margin-left')) ?? m.l; m.r = mm(A(pl, 'fo', 'margin-right')) ?? m.r;
        const cols = deep(pl, 'columns')[0];
        if (cols && +A(cols, 'fo', 'column-count') > 1) ctx.meta.columns = +A(cols, 'fo', 'column-count');
      }
      const mp = deep(stylesX, 'master-page')[0];
      if (mp) for (const [tag, key] of [['header', 'header'], ['footer', 'footer']]) {
        const hf = kids(mp, tag)[0];
        if (!hf) continue;
        if (deep(hf, 'page-number').length) ctx.meta.pageNumbers = (key === 'header' ? 'top-' : 'bottom-') + 'center';
        const txt = deep(hf, 'p').map(p => [...p.childNodes].filter(n => n.nodeType === 3 || (n.localName !== 'page-number' && n.localName !== 'page-count')).map(n => n.textContent).join('')).join('\n').trim();
        ctx.meta[key] = txt;
      }
    }
    const body = deep(content, 'text')[0] && deep(content, 'body')[0] ? deep(deep(content, 'body')[0], 'text')[0] : null;
    const out = document.createElement('div');
    if (body) blocks(body, out, ctx, null);
    await Promise.all(ctx.imgPromises);
    if (ctx.notes.length) out.append(h('div', { class: 'footnotes' }, h('ol', null, ctx.notes.map(n => h('li', { id: n.id, text: n.text })))));
    const t = deep(content, 'title')[0];
    if (t) ctx.meta.title = t.textContent;
    return { html: out.innerHTML, meta: ctx.meta };
  }
  function attrs(el) { const o = {}; for (const a of el.attributes) o[a.localName] = a.value; return o; }
  function chain(ctx, name, key) {
    const list = [];
    let s = ctx.styles[name], g = 0;
    while (s && g++ < 20) { list.unshift(s); s = ctx.styles[s.parent]; }
    return Object.assign({}, ...list.map(x => x[key]));
  }
  function textCss(t, ctx) {
    const c = [];
    const fn = t['font-name'] || t['font-family'];
    if (fn) c.push('font-family:' + Fonts.css(ctx.fonts[fn] || fn.replace(/^['"]|['"]$/g, '')).replace(/"/g, "'"));
    if (t['font-size'] && !/%/.test(t['font-size'])) c.push(`font-size:${+Fmt.toPt(t['font-size']).toFixed(1)}pt`);
    if (t['font-weight']) c.push('font-weight:' + (t['font-weight'] === 'bold' || +t['font-weight'] >= 600 ? 'bold' : 'normal'));
    if (t['font-style']) c.push('font-style:' + (t['font-style'] === 'italic' ? 'italic' : 'normal'));
    const dec = [];
    if (t['text-underline-style'] && t['text-underline-style'] !== 'none') dec.push('underline');
    if (t['text-line-through-style'] && t['text-line-through-style'] !== 'none') dec.push('line-through');
    if (dec.length) c.push('text-decoration-line:' + dec.join(' '));
    if (t['text-underline-type'] === 'double') c.push('text-decoration-style:double');
    if (t['color'] && t['color'] !== '#000000') c.push('color:' + t['color']);
    if (t['background-color'] && t['background-color'] !== 'transparent') c.push('background-color:' + t['background-color']);
    if (t['text-transform'] === 'uppercase') c.push('text-transform:uppercase');
    if (t['font-variant'] === 'small-caps') c.push('font-variant:small-caps');
    if (t['letter-spacing'] && t['letter-spacing'] !== 'normal') c.push(`letter-spacing:${Fmt.toPt(t['letter-spacing']).toFixed(2)}pt`);
    return c;
  }
  function paraCss(p) {
    const c = [];
    const al = p['text-align'];
    if (al && al !== 'start' && al !== 'left') c.push('text-align:' + ({ end: 'right', center: 'center', justify: 'justify', right: 'right' }[al] || 'left'));
    for (const [k, css] of [['margin-top', 'margin-top'], ['margin-bottom', 'margin-bottom'], ['margin-left', 'margin-left'], ['margin-right', 'margin-right'], ['text-indent', 'text-indent']]) {
      if (p[k] != null && !/%/.test(p[k])) { const v = Fmt.toPt(p[k]); if (v != null && (v || k === 'margin-bottom' || k === 'margin-top')) c.push(`${css}:${+v.toFixed(1)}pt`); }
    }
    if (p['line-height'] && p['line-height'] !== 'normal') {
      c.push('line-height:' + (/%$/.test(p['line-height']) ? +(parseFloat(p['line-height']) / 100 * Fmt.LH).toFixed(3) : Fmt.toPt(p['line-height']).toFixed(1) + 'pt'));
    }
    if (p['background-color'] && p['background-color'] !== 'transparent') c.push('background-color:' + p['background-color']);
    return c;
  }

  function blocks(container, out, ctx, listStyle) {
    for (const el of container.children) {
      const n = el.localName;
      if (n === 'p' || n === 'h') out.append(...para(el, ctx));
      else if (n === 'list') out.append(list(el, ctx, listStyle || A(el, 'text', 'style-name'), 0));
      else if (n === 'table') out.append(table(el, ctx));
      else if (n === 'section' || n === 'index-body' || n === 'table-of-content' || n === 'alphabetical-index' || n === 'illustration-index' || n === 'soft-page-break' || n === 'tracked-changes') {
        if (n === 'tracked-changes') continue;
        blocks(el, out, ctx, listStyle);
      }
    }
  }
  function para(el, ctx) {
    const sname = A(el, 'text', 'style-name');
    const st = ctx.styles[sname] || {};
    const pp = chain(ctx, sname, 'p'), tp = chain(ctx, sname, 't');
    let tag = 'p', cls = '';
    if (el.localName === 'h') tag = 'h' + Math.min(6, Math.max(1, +(A(el, 'text', 'outline-level') || 1)));
    else {
      let s = st, g = 0;
      while (s && g++ < 10) {
        const dn = (s.display || '').toLowerCase();
        if (/^heading (\d)/.test(dn)) { tag = 'h' + Math.min(6, +dn.match(/(\d)/)[1]); break; }
        if (dn === 'title') { cls = 'title'; break; }
        if (dn === 'subtitle') { cls = 'subtitle'; break; }
        if (/quot/.test(dn)) { tag = 'blockquote'; break; }
        s = ctx.styles[s.parent];
      }
    }
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    const css = paraCss(pp).concat(textCss(tp, ctx));
    if (css.length) node.setAttribute('style', css.join(';'));
    const res = [];
    if (pp['break-before'] === 'page') res.push(h('div', { class: 'page-break' }));
    inlines(el, node, ctx);
    if (!node.childNodes.length) node.innerHTML = '<br>';
    res.push(node);
    if (pp['break-after'] === 'page') res.push(h('div', { class: 'page-break' }));
    return res;
  }
  function inlines(el, target, ctx) {
    for (const n of el.childNodes) {
      if (n.nodeType === 3) { target.append(n.data.replace(/[\n\r]+/g, ' ')); continue; }
      if (n.nodeType !== 1) continue;
      switch (n.localName) {
        case 'span': {
          const css = textCss(chain(ctx, A(n, 'text', 'style-name'), 't'), ctx);
          const t = chain(ctx, A(n, 'text', 'style-name'), 't');
          let wrap = target;
          if (t['text-position'] && /^(super|sub|[-\d])/.test(t['text-position'])) {
            const isSup = /^super/.test(t['text-position']) || parseFloat(t['text-position']) > 0;
            wrap = document.createElement(isSup ? 'sup' : 'sub'); target.append(wrap);
          }
          if (css.length) { const s = document.createElement('span'); s.setAttribute('style', css.join(';')); wrap.append(s); inlines(n, s, ctx); }
          else inlines(n, wrap, ctx);
          break;
        }
        case 'a': { const a = document.createElement('a'); a.href = A(n, 'xlink', 'href') || '#'; target.append(a); inlines(n, a, ctx); break; }
        case 's': target.append(' '.repeat(+(A(n, 'text', 'c') || 1))); break;
        case 'tab': target.append('\t'); break;
        case 'line-break': target.append(document.createElement('br')); break;
        case 'frame': {
          const im = deep(n, 'image')[0];
          if (!im) { const tb = deep(n, 'text-box')[0]; if (tb) target.append(tb.textContent); break; }
          const href = A(im, 'xlink', 'href');
          const img = document.createElement('img');
          const w = Fmt.toPt(A(n, 'svg', 'width'));
          if (w) img.style.width = Math.round(w / 0.75) + 'px';
          const fs = chain(ctx, A(n, 'draw', 'style-name'), 'p');
          target.append(img);
          if (href && ctx.zip) {
            const ext = (href.match(/\.(\w+)$/) || [])[1]?.toLowerCase();
            ctx.imgPromises.push(ctx.zip.bytes(href).then(b => { if (b && Fmt.MIME_BY_EXT[ext]) img.src = Fmt.bytesToDataUrl(b, Fmt.MIME_BY_EXT[ext]); else img.remove(); }).catch(() => img.remove()));
          } else {
            const bin = deep(im, 'binary-data')[0];
            if (bin) img.src = 'data:image/png;base64,' + bin.textContent.replace(/\s/g, '');
            else img.remove();
          }
          break;
        }
        case 'note': {
          const id = 'fn' + (ctx.notes.length + 1);
          ctx.notes.push({ id, text: deep(n, 'note-body')[0]?.textContent.trim() || '' });
          target.append(h('sup', { class: 'fn', 'data-fn': id, contenteditable: 'false', text: String(ctx.notes.length) }));
          break;
        }
        case 'annotation': {
          // примечание: текст до annotation-end
          const txt = deep(n, 'p').map(p => p.textContent).join('\n');
          const author = deep(n, 'creator')[0]?.textContent || '';
          target.append(h('span', { class: 'dp-comment', 'data-id': 'c' + Math.random().toString(36).slice(2, 7), 'data-text': txt, 'data-author': author, text: '​' }));
          break;
        }
        case 'soft-page-break': case 'bookmark': case 'bookmark-start': case 'bookmark-end': case 'annotation-end': case 'sequence-decls': break;
        default: inlines(n, target, ctx);
      }
    }
  }
  const NUMFMT = { '1': null, a: 'lower-alpha', A: 'upper-alpha', i: 'lower-roman', I: 'upper-roman', 'а': 'lower-alpha', 'А': 'upper-alpha' };
  function list(el, ctx, styleName, level) {
    const ls = (ctx.lists[styleName] || {})[level] || { bullet: true };
    const lst = document.createElement(ls.bullet ? 'ul' : 'ol');
    if (!ls.bullet) {
      if (NUMFMT[ls.fmt]) lst.style.listStyleType = NUMFMT[ls.fmt];
      if (ls.start > 1) lst.setAttribute('start', ls.start);
    }
    for (const it of el.children) {
      if (it.localName !== 'list-item' && it.localName !== 'list-header') continue;
      const li = document.createElement('li');
      let first = true;
      for (const c of it.children) {
        if (c.localName === 'p' || c.localName === 'h') {
          const [p] = para(c, ctx).filter(x => !x.classList.contains('page-break'));
          if (first) { li.append(...p.childNodes); if (p.getAttribute('style')) li.setAttribute('style', p.getAttribute('style').replace(/(^|;)\s*(margin-left|text-indent)[^;]*/g, '')); first = false; }
          else { li.append(document.createElement('br'), ...p.childNodes); }
        } else if (c.localName === 'list') li.append(list(c, ctx, A(c, 'text', 'style-name') || styleName, level + 1));
      }
      if (!li.childNodes.length) li.innerHTML = '<br>';
      lst.append(li);
    }
    return lst;
  }
  function table(el, ctx) {
    const t = document.createElement('table');
    t.dataset.borders = '0';
    const tb = document.createElement('tbody');
    t.append(tb);
    const rowsOf = e => {
      const out = [];
      for (const c of e.children) {
        if (c.localName === 'table-row') out.push(c);
        else if (/table-(header-rows|rows|row-group)/.test(c.localName)) out.push(...rowsOf(c));
      }
      return out;
    };
    for (const r of rowsOf(el)) {
      const tr = document.createElement('tr');
      for (const c of r.children) {
        if (c.localName !== 'table-cell') continue;
        const td = document.createElement('td');
        const cs = +(A(c, 'table', 'number-columns-spanned') || 1), rs = +(A(c, 'table', 'number-rows-spanned') || 1);
        if (cs > 1) td.colSpan = cs;
        if (rs > 1) td.rowSpan = rs;
        const cp = chain(ctx, A(c, 'table', 'style-name'), 'c');
        if (cp['background-color'] && cp['background-color'] !== 'transparent') td.style.backgroundColor = cp['background-color'];
        const border = cp['border'] || cp['border-top'] || cp['border-left'];
        if (border && !/^(none|hidden)/.test(border) && !/^0(\.0+)?(pt|cm|mm|in|px)?\s/.test(border)) t.dataset.borders = '1';
        if (cp['vertical-align'] === 'middle') td.style.verticalAlign = 'middle';
        blocks(c, td, ctx, null);
        if (!td.childNodes.length) td.innerHTML = '<br>';
        tr.append(td);
      }
      tb.append(tr);
    }
    return t;
  }

  // ===================== ЗАПИСЬ =====================
  const X = Fmt.xmlEsc;
  async function write(docEl, meta) {
    document.documentElement.classList.add('exporting');
    try { return await writeInner(docEl, meta); } finally { document.documentElement.classList.remove('exporting'); }
  }
  async function writeInner(docEl, meta) {
    const zoom = parseFloat(getComputedStyle(document.getElementById('page')).zoom) || 1;
    const W = { tStyles: new Map(), pStyles: new Map(), lists: [], pics: [], fonts: new Set([meta.defaultFont]), zoom, tbl: 0, notes: 0, fnText: {} };
    docEl.querySelectorAll('.footnotes li').forEach(li => W.fnText[li.id] = li.textContent);
    let body = '';
    for (const n of docEl.childNodes) {
      if (n.nodeType === 1 && n.classList.contains('footnotes')) continue;
      body += blockX(n, W, {});
    }
    const auto = [...W.pStyles.values()].map(s => s.xml).join('') + [...W.tStyles.values()].map(s => s.xml).join('') + W.lists.map(l => l.xml).join('') +
      '<style:style style:name="PB" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:break-before="page"/></style:style>' +
      '<style:style style:name="fr1" style:family="graphic"><style:graphic-properties style:wrap="none" style:vertical-pos="top" style:vertical-rel="paragraph" style:horizontal-pos="center" style:horizontal-rel="paragraph"/></style:style>' +
      '<style:style style:name="frL" style:family="graphic"><style:graphic-properties style:wrap="right" style:vertical-pos="top" style:vertical-rel="paragraph" style:horizontal-pos="left" style:horizontal-rel="paragraph"/></style:style>' +
      '<style:style style:name="frR" style:family="graphic"><style:graphic-properties style:wrap="left" style:vertical-pos="top" style:vertical-rel="paragraph" style:horizontal-pos="right" style:horizontal-rel="paragraph"/></style:style>' +
      (W.tblStyles || '');
    const fontDecls = '<office:font-face-decls>' + [...W.fonts].filter(Boolean).map(f => `<style:font-face style:name="${X(f)}" svg:font-family="'${X(f)}'"/>`).join('') + '</office:font-face-decls>';
    const DECL = 'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0" office:version="1.3"';
    const content = `<?xml version="1.0" encoding="UTF-8"?>\n<office:document-content ${DECL}>${fontDecls}<office:automatic-styles>${auto}</office:automatic-styles><office:body><office:text>${body || '<text:p/>'}</office:text></office:body></office:document-content>`;

    const land = meta.orientation === 'landscape';
    let pw = meta.pageW, ph = meta.pageH;
    if (land && pw < ph) [pw, ph] = [ph, pw];
    const mg = meta.margins;
    const pn = meta.pageNumbers || 'none';
    const pnAlign = pn.endsWith('right') ? 'end' : pn.endsWith('left') ? 'start' : 'center';
    const pnXml = meta.pageNumFormat === 'n of N' ? 'Страница <text:page-number text:select-page="current">1</text:page-number> из <text:page-count>1</text:page-count>' : '<text:page-number text:select-page="current">1</text:page-number>';
    const hf = (txt, num) => (txt ? txt.split('\n').map(l => `<text:p text:style-name="Header">${X(l)}</text:p>`).join('') : '') + (num ? `<text:p text:style-name="${pnAlign === 'center' ? 'Header' : pnAlign === 'end' ? 'HeaderR' : 'HeaderL'}">${pnXml}</text:p>` : '');
    const hasH = meta.header || pn.startsWith('top'), hasF = meta.footer || pn.startsWith('bottom');
    const lh = meta.defaultLine || 1;
    const styles = `<?xml version="1.0" encoding="UTF-8"?>\n<office:document-styles ${DECL}>${fontDecls}<office:styles>` +
      `<style:default-style style:family="paragraph"><style:paragraph-properties fo:margin-bottom="${meta.defaultAfter ?? 0}pt" fo:line-height="${Math.round(lh * 100)}%"/><style:text-properties style:font-name="${X(meta.defaultFont)}" fo:font-size="${meta.defaultSize}pt" fo:language="${meta.lang === 'en' ? 'en' : meta.lang === 'uk' ? 'uk' : 'ru'}" fo:country="${meta.lang === 'en' ? 'US' : meta.lang === 'uk' ? 'UA' : 'RU'}"/></style:default-style>` +
      `<style:style style:name="Standard" style:family="paragraph" style:class="text">${meta.defaultIndent ? `<style:paragraph-properties fo:text-indent="${meta.defaultIndent}cm"/>` : ''}</style:style>` +
      '<style:style style:name="Heading" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:class="text"><style:paragraph-properties fo:margin-top="12pt" fo:margin-bottom="6pt" fo:keep-with-next="always" fo:text-indent="0cm"/><style:text-properties fo:font-weight="bold" fo:color="#1f3864"/></style:style>' +
      [40, 32, 28, 24, 22, 22].map((sz, i) => `<style:style style:name="Heading_20_${i + 1}" style:display-name="Heading ${i + 1}" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Standard" style:default-outline-level="${i + 1}" style:class="text"><style:text-properties fo:font-size="${sz / 2}pt"${i === 3 || i === 5 ? ' fo:font-style="italic"' : ''}/></style:style>`).join('') +
      '<style:style style:name="Title" style:family="paragraph" style:parent-style-name="Standard" style:class="chapter"><style:paragraph-properties fo:text-indent="0cm" fo:margin-bottom="6pt"/><style:text-properties fo:font-size="28pt"/></style:style>' +
      '<style:style style:name="Subtitle" style:family="paragraph" style:parent-style-name="Standard" style:class="chapter"><style:paragraph-properties fo:text-indent="0cm"/><style:text-properties fo:font-size="15pt" fo:color="#5a5a5a"/></style:style>' +
      '<style:style style:name="Quotations" style:display-name="Quotations" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:margin-left="1cm" fo:margin-right="1cm" fo:text-indent="0cm"/><style:text-properties fo:font-style="italic"/></style:style>' +
      '<style:style style:name="Preformatted_20_Text" style:display-name="Preformatted Text" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:margin-bottom="0cm" fo:text-indent="0cm" fo:background-color="#f5f5f5"/><style:text-properties style:font-name="Courier New" fo:font-size="10pt"/></style:style>' +
      '<style:style style:name="Table_20_Contents" style:display-name="Table Contents" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:margin-bottom="0cm" fo:text-indent="0cm"/></style:style>' +
      '<style:style style:name="Header" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:text-align="center" fo:margin-bottom="0cm" fo:text-indent="0cm"/><style:text-properties fo:font-size="10pt"/></style:style>' +
      '<style:style style:name="HeaderR" style:family="paragraph" style:parent-style-name="Header"><style:paragraph-properties fo:text-align="end"/></style:style>' +
      '<style:style style:name="HeaderL" style:family="paragraph" style:parent-style-name="Header"><style:paragraph-properties fo:text-align="start"/></style:style>' +
      '<style:style style:name="Internet_20_link" style:display-name="Internet link" style:family="text"><style:text-properties fo:color="#0563c1" style:text-underline-style="solid" style:text-underline-width="auto" style:text-underline-color="font-color"/></style:style>' +
      '<style:style style:name="Footnote" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:text-indent="0cm"/><style:text-properties fo:font-size="10pt"/></style:style>' +
      `</office:styles><office:automatic-styles><style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="${pw}mm" fo:page-height="${ph}mm" style:print-orientation="${land ? 'landscape' : 'portrait'}" fo:margin-top="${mg.t}mm" fo:margin-bottom="${mg.b}mm" fo:margin-left="${mg.l}mm" fo:margin-right="${mg.r}mm"${meta.pageColor ? ` fo:background-color="${meta.pageColor}"` : ''}>${meta.columns > 1 ? `<style:columns fo:column-count="${meta.columns}" fo:column-gap="0.5cm"/>` : ''}</style:page-layout-properties>` +
      `${hasH ? '<style:header-style><style:header-footer-properties fo:min-height="0.5cm" fo:margin-bottom="0.3cm"/></style:header-style>' : ''}${hasF ? '<style:footer-style><style:header-footer-properties fo:min-height="0.5cm" fo:margin-top="0.3cm"/></style:footer-style>' : ''}</style:page-layout></office:automatic-styles>` +
      `<office:master-styles><style:master-page style:name="Standard" style:page-layout-name="pm1">${hasH ? `<style:header>${hf(meta.header, pn.startsWith('top'))}</style:header>` : ''}${hasF ? `<style:footer>${hf(meta.footer, pn.startsWith('bottom'))}</style:footer>` : ''}</style:master-page></office:master-styles></office:document-styles>`;
    const now = new Date().toISOString().replace(/\.\d+Z$/, '');
    const metaX = `<?xml version="1.0" encoding="UTF-8"?>\n<office:document-meta ${DECL}><office:meta><meta:generator>DocPad</meta:generator><dc:title>${X(meta.title || '')}</dc:title><dc:creator>${X(Store.S().author || '')}</dc:creator><dc:date>${now}</dc:date></office:meta></office:document-meta>`;
    const manifest = `<?xml version="1.0" encoding="UTF-8"?>\n<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.3"><manifest:file-entry manifest:full-path="/" manifest:version="1.3" manifest:media-type="application/vnd.oasis.opendocument.text"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/>` +
      W.pics.map(p => `<manifest:file-entry manifest:full-path="Pictures/${p.name}" manifest:media-type="${p.mime}"/>`).join('') + '</manifest:manifest>';
    return Zip.write([
      { name: 'mimetype', data: 'application/vnd.oasis.opendocument.text', store: true },
      { name: 'content.xml', data: content }, { name: 'styles.xml', data: styles }, { name: 'meta.xml', data: metaX },
      { name: 'META-INF/manifest.xml', data: manifest },
      ...W.pics.map(p => ({ name: 'Pictures/' + p.name, data: p.bytes, store: true }))
    ]);
  }

  function pStyle(el, W, parent, extra = '') {
    const ps = Fmt.paraStyle(el);
    const props = [];
    if (ps.align !== 'left') props.push(`fo:text-align="${{ center: 'center', right: 'end', justify: 'justify' }[ps.align]}"`);
    props.push(`fo:margin-top="${ps.mt.toFixed(1)}pt" fo:margin-bottom="${ps.mb.toFixed(1)}pt"`);
    if (ps.ml || ps.mr) props.push(`fo:margin-left="${ps.ml.toFixed(1)}pt" fo:margin-right="${ps.mr.toFixed(1)}pt"`);
    props.push(`fo:text-indent="${ps.ti.toFixed(1)}pt"`);
    if (ps.lhExact) props.push(`fo:line-height="${ps.lhExact}pt"`); else if (ps.lh) props.push(`fo:line-height="${Math.round(ps.lh * 100)}%"`);
    if (ps.bg) props.push(`fo:background-color="#${ps.bg}"`);
    if (ps.rtl) props.push('style:writing-mode="rl-tb"');
    if (extra) props.push(extra);
    const key = parent + '|' + props.join(' ');
    if (!W.pStyles.has(key)) {
      const name = 'P' + (W.pStyles.size + 1);
      W.pStyles.set(key, { name, xml: `<style:style style:name="${name}" style:family="paragraph" style:parent-style-name="${parent}"><style:paragraph-properties ${props.join(' ')}/></style:style>` });
    }
    return W.pStyles.get(key).name;
  }
  function tStyle(el, W) {
    const r = Fmt.runStyle(el);
    W.fonts.add(r.font);
    const p = [`style:font-name="${X(r.font)}"`, `fo:font-size="${r.size}pt"`];
    if (r.b) p.push('fo:font-weight="bold"'); else p.push('fo:font-weight="normal"');
    if (r.i) p.push('fo:font-style="italic"');
    if (r.color && r.color !== '000000') p.push(`fo:color="#${r.color}"`);
    if (r.bg) p.push(`fo:background-color="#${r.bg}"`);
    if (r.u) p.push(`style:text-underline-style="${r.u === 'dotted' ? 'dotted' : r.u === 'dashed' ? 'dash' : r.u === 'wavy' ? 'wave' : 'solid'}" style:text-underline-width="auto" style:text-underline-color="font-color"${r.u === 'double' ? ' style:text-underline-type="double"' : ''}`);
    if (r.strike) p.push('style:text-line-through-style="solid"');
    if (r.vert) p.push(`style:text-position="${r.vert === 'super' ? 'super' : 'sub'} 58%"`);
    if (r.caps) p.push('fo:text-transform="uppercase"');
    if (r.smallCaps) p.push('fo:font-variant="small-caps"');
    if (r.spacing) p.push(`fo:letter-spacing="${(r.spacing * 0.75).toFixed(2)}pt"`);
    const key = p.join(' ');
    if (!W.tStyles.has(key)) {
      const name = 'T' + (W.tStyles.size + 1);
      W.tStyles.set(key, { name, xml: `<style:style style:name="${name}" style:family="text"><style:text-properties ${key}/></style:style>` });
    }
    return W.tStyles.get(key).name;
  }

  const isBlock = t => /^(P|H[1-6]|DIV|UL|OL|LI|TABLE|BLOCKQUOTE|PRE|HR|SECTION|ARTICLE|FIGURE)$/.test(t);
  function blockX(n, W, ctx) {
    if (n.nodeType === 3) return n.data.trim() ? `<text:p>${X(n.data)}</text:p>` : '';
    if (n.nodeType !== 1) return '';
    const t = n.tagName;
    if (n.classList.contains('page-break')) { W.pendingBreak = true; return ''; }
    if (n.classList.contains('col-break')) return '';
    if (t === 'HR') return '<text:p>' + '—'.repeat(30) + '</text:p>';
    if (t === 'TABLE') return tableX(n, W);
    if (t === 'UL' || t === 'OL') return listX(n, W, 0);
    if (n.classList.contains('toc')) {
      return [...n.querySelectorAll('.toc-title, a')].map(a => `<text:p text:style-name="${a.classList.contains('toc-title') ? 'Heading_20_1' : 'Standard'}">${X(a.classList.contains('toc-title') ? a.textContent : (a.querySelector('.t')?.textContent || '') + '\t' + (a.querySelector('.n')?.textContent || ''))}</text:p>`).join('');
    }
    if ((t === 'BLOCKQUOTE' || t === 'DIV' || t === 'SECTION') && [...n.children].some(c => isBlock(c.tagName))) return [...n.childNodes].map(c => blockX(c, W, Object.assign({}, ctx, t === 'BLOCKQUOTE' ? { parent: 'Quotations' } : {}))).join('');
    return paraX(n, [...n.childNodes], W, ctx);
  }
  function parentOf(n, ctx) {
    if (/^H[1-6]$/.test(n.tagName)) return 'Heading_20_' + n.tagName[1];
    if (n.tagName === 'PRE') return 'Preformatted_20_Text';
    if (n.tagName === 'BLOCKQUOTE') return 'Quotations';
    if (n.classList && n.classList.contains('title')) return 'Title';
    if (n.classList && n.classList.contains('subtitle')) return 'Subtitle';
    if (/^(TD|TH)$/.test(n.tagName)) return 'Table_20_Contents';
    return ctx.parent || 'Standard';
  }
  function paraX(el, nodes, W, ctx) {
    const parent = parentOf(el, ctx);
    const brk = W.pendingBreak ? 'fo:break-before="page"' : '';
    W.pendingBreak = false;
    const sn = pStyle(el, W, parent, brk);
    const inner = nodes.map(c => inlineX(c, W)).join('');
    const tag = /^H[1-6]$/.test(el.tagName) ? 'text:h' : 'text:p';
    const lvl = tag === 'text:h' ? ` text:outline-level="${el.tagName[1]}"` : '';
    return `<${tag} text:style-name="${sn}"${lvl}>${inner}</${tag}>`;
  }
  function textX(s) {
    let out = '';
    const parts = s.replace(/​/g, '').split(/(\t|\n| {2,})/);
    for (const p of parts) {
      if (!p) continue;
      if (p === '\t') out += '<text:tab/>';
      else if (p === '\n') out += '<text:line-break/>';
      else if (/^ {2,}$/.test(p)) out += ` <text:s text:c="${p.length - 1}"/>`;
      else out += X(p);
    }
    return out;
  }
  function inlineX(n, W) {
    if (n.nodeType === 3) {
      if (!n.data.replace(/​/g, '')) return '';
      return `<text:span text:style-name="${tStyle(n.parentElement, W)}">${textX(n.data)}</text:span>`;
    }
    if (n.nodeType !== 1) return '';
    const t = n.tagName;
    if (t === 'BR') return Fmt.trailingBr(n) ? '' : '<text:line-break/>';
    if (t === 'IMG') return imgX(n, W);
    if (t === 'A' && n.getAttribute('href')) {
      return `<text:a xlink:type="simple" xlink:href="${X(n.getAttribute('href'))}" text:style-name="Internet_20_link">${[...n.childNodes].map(c => inlineX(c, W)).join('')}</text:a>`;
    }
    if (t === 'SUP' && n.classList.contains('fn')) {
      W.notes++;
      return `<text:note text:id="ftn${W.notes}" text:note-class="footnote"><text:note-citation>${W.notes}</text:note-citation><text:note-body><text:p text:style-name="Footnote">${X(W.fnText[n.dataset.fn] || '')}</text:p></text:note-body></text:note>`;
    }
    if (n.classList.contains('dp-comment') && !W['c_' + n.dataset.id]) {
      W['c_' + n.dataset.id] = 1;
      const ann = `<office:annotation><dc:creator>${X(n.dataset.author || '')}</dc:creator><text:p>${X(n.dataset.text || '')}</text:p></office:annotation>`;
      return ann + [...n.childNodes].map(c => inlineX(c, W)).join('');
    }
    if (t === 'UL' || t === 'OL' || t === 'TABLE') return X(n.innerText);
    return [...n.childNodes].map(c => inlineX(c, W)).join('');
  }
  function imgX(img, W) {
    let d = img.src.startsWith('data:') ? Fmt.dataUrlToBytes(img.src) : null;
    let ext = d && Fmt.EXT_BY_MIME[d.mime];
    if (!d || !ext) {
      try { const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight; c.getContext('2d').drawImage(img, 0, 0); d = Fmt.dataUrlToBytes(c.toDataURL('image/png')); ext = 'png'; }
      catch (e) { return ''; }
    }
    const name = `img${W.pics.length + 1}.${ext}`;
    W.pics.push({ name, bytes: d.bytes, mime: d.mime });
    const [iw, ih] = Fmt.imageSize(img);
    const w = iw * 0.75, hh = ih * 0.75;
    const st = img.classList.contains('float-left') ? 'frL' : img.classList.contains('float-right') ? 'frR' : 'fr1';
    const anchor = st === 'fr1' ? 'as-char' : 'paragraph';
    return `<draw:frame draw:style-name="${st}" draw:name="${name}" text:anchor-type="${anchor}" svg:width="${w.toFixed(1)}pt" svg:height="${hh.toFixed(1)}pt" draw:z-index="0"><draw:image xlink:href="Pictures/${name}" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/></draw:frame>`;
  }
  function listX(list, W, level, styleName) {
    if (!styleName) {
      styleName = 'L' + (W.lists.length + 1);
      const levels = [];
      const collect = (l, lv) => { if (lv > 9) return; if (!levels[lv]) levels[lv] = { ul: l.tagName === 'UL', type: getComputedStyle(l).listStyleType, start: +l.getAttribute('start') || 1 }; l.querySelectorAll(':scope > li > ul, :scope > li > ol').forEach(s => collect(s, lv + 1)); };
      collect(list, 0);
      const fmt = { 'lower-alpha': 'a', 'upper-alpha': 'A', 'lower-roman': 'i', 'upper-roman': 'I', 'lower-latin': 'a', 'upper-latin': 'A' };
      let xml = `<text:list-style style:name="${styleName}">`;
      for (let i = 0; i < 10; i++) {
        const L = levels[i] || { ul: list.tagName === 'UL', type: 'disc', start: 1 };
        const pos = `<style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="listtab" text:list-tab-stop-position="${(i + 1) * 1.27}cm" fo:text-indent="-0.635cm" fo:margin-left="${(i + 1) * 1.27}cm"/></style:list-level-properties>`;
        if (L.ul) xml += `<text:list-level-style-bullet text:level="${i + 1}" text:bullet-char="${L.type === 'circle' ? '◦' : L.type === 'square' ? '▪' : list.classList.contains('checklist') ? '☐' : '•'}">${pos}</text:list-level-style-bullet>`;
        else xml += `<text:list-level-style-number text:level="${i + 1}" style:num-suffix="." style:num-format="${fmt[L.type] || '1'}"${L.start > 1 ? ` text:start-value="${L.start}"` : ''}>${pos}</text:list-level-style-number>`;
      }
      W.lists.push({ name: styleName, xml: xml + '</text:list-style>' });
    }
    let out = `<text:list${level === 0 ? ` text:style-name="${styleName}"` : ''}>`;
    for (const li of list.children) {
      if (li.tagName !== 'LI') continue;
      const inl = [], nested = [];
      for (const c of li.childNodes) (c.nodeType === 1 && (c.tagName === 'UL' || c.tagName === 'OL') ? nested : inl).push(c);
      const prefix = list.classList.contains('checklist') ? (li.dataset.checked === '1' ? '☑ ' : '') : '';
      const blocksIn = inl.filter(c => c.nodeType === 1 && isBlock(c.tagName));
      out += '<text:list-item>';
      if (blocksIn.length) out += inl.map(c => c.nodeType === 1 && isBlock(c.tagName) ? blockX(c, W, {}) : '').join('');
      else out += paraX(li, inl, W, {}).replace(/^(<text:p[^>]*>)/, '$1' + X(prefix));
      for (const nl of nested) out += listX(nl, W, level + 1, styleName);
      out += '</text:list-item>';
    }
    return out + '</text:list>';
  }
  function tableX(t, W) {
    const name = 'Table' + (++W.tbl);
    const rows = [...t.rows];
    const G = [];
    rows.forEach((tr, r) => {
      G[r] = G[r] || [];
      let c = 0;
      for (const td of tr.cells) {
        while (G[r][c]) c++;
        for (let i = 0; i < (td.rowSpan || 1); i++) for (let j = 0; j < (td.colSpan || 1); j++) { G[r + i] = G[r + i] || []; G[r + i][c + j] = td; }
        c += td.colSpan || 1;
      }
    });
    const ncol = Math.max(1, ...G.map(r => r.length));
    const tw = Fmt.paperWidth(t) * 0.75;
    const borders = t.dataset.borders !== '0';
    W.tblStyles = (W.tblStyles || '') + `<style:style style:name="${name}" style:family="table"><style:table-properties style:width="${tw.toFixed(1)}pt" table:align="margins"/></style:style>`;
    const cellStyle = (bg, va) => {
      const key = `${name}.C${bg || ''}${va || ''}`;
      W.cellStyles = W.cellStyles || new Set();
      if (!W.cellStyles.has(key)) {
        W.cellStyles.add(key);
        W.tblStyles += `<style:style style:name="${key}" style:family="table-cell"><style:table-cell-properties fo:padding="0.1cm" fo:border="${borders ? '0.5pt solid #000000' : 'none'}"${bg ? ` fo:background-color="#${bg}"` : ''}${va ? ` style:vertical-align="${va}"` : ''}/></style:style>`;
      }
      return key;
    };
    let x = `<table:table table:name="${name}" table:style-name="${name}"><table:table-column table:number-columns-repeated="${ncol}"/>`;
    for (let r = 0; r < G.length; r++) {
      x += '<table:table-row>';
      for (let c = 0; c < ncol; c++) {
        const td = G[r][c];
        if (!td) { x += `<table:table-cell table:style-name="${cellStyle()}"><text:p/></table:table-cell>`; continue; }
        const startR = G.findIndex(row => row.includes(td)), startC = G[startR].indexOf(td);
        if (startR !== r || startC !== c) { x += '<table:covered-table-cell/>'; continue; }
        const cs = getComputedStyle(td);
        const bg = Fmt.toHex(cs.backgroundColor);
        const va = cs.verticalAlign === 'middle' ? 'middle' : cs.verticalAlign === 'bottom' ? 'bottom' : null;
        let inner = '';
        const kids = [...td.childNodes];
        if (kids.some(k => k.nodeType === 1 && isBlock(k.tagName))) {
          let inl = [];
          const flush = () => { if (inl.length) { inner += paraX(td, inl, W, {}); inl = []; } };
          for (const k of kids) { if (k.nodeType === 1 && isBlock(k.tagName)) { flush(); inner += blockX(k, W, { parent: 'Table_20_Contents' }); } else inl.push(k); }
          flush();
        } else inner = paraX(td, kids, W, {});
        x += `<table:table-cell table:style-name="${cellStyle(bg, va)}" office:value-type="string"${(td.colSpan || 1) > 1 ? ` table:number-columns-spanned="${td.colSpan}"` : ''}${(td.rowSpan || 1) > 1 ? ` table:number-rows-spanned="${td.rowSpan}"` : ''}>${inner || '<text:p/>'}</table:table-cell>`;
      }
      x += '</table:table-row>';
    }
    return x + '</table:table>';
  }

  return { read, write };
})();
