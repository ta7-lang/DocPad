/* Чтение и запись RTF */
'use strict';
const Rtf = (() => {
  const CHARSET_CP = { 0: 1252, 77: 10000, 128: 932, 129: 949, 134: 936, 136: 950, 161: 1253, 162: 1254, 163: 1258, 177: 1255, 178: 1256, 186: 1257, 204: 1251, 222: 874, 238: 1250 };
  const decoders = {};
  const dec = cp => { try { return decoders[cp] || (decoders[cp] = new TextDecoder('windows-' + cp)); } catch (e) { return decoders[1252] || (decoders[1252] = new TextDecoder('windows-1252')); } };

  // ===================== ЧТЕНИЕ =====================
  function read(bytes) {
    const src = new TextDecoder('latin1').decode(bytes);
    const meta = Fmt.defaultMeta();
    meta.defaultAfter = 0; meta.defaultLine = 1; meta.defaultIndent = 0;
    const fonts = {}, colors = [];
    let ansiCp = 1252;
    const out = document.createElement('div');
    const freshChar = () => ({ b: false, i: false, ul: false, strike: false, fs: 24, f: null, cf: 0, cb: 0, sup: false, sub: false, caps: false, uc: 1, dest: null, hidden: false });
    const freshPara = () => ({ align: null, li: 0, ri: 0, fi: 0, sb: 0, sa: 0, sl: 0, slmult: 0, intbl: false, ls: 0, ilvl: 0, style: null });
    let st = freshChar(), pp = freshPara();
    const stack = [];
    let p = null, pendingBytes = [], skipChars = 0;
    let table = null, row = null, cellEl = null, listStack = [], listText = '';
    let pict = null, fontTmp = null, colorTmp = null, defF = null;
    const pictures = [];

    const curCp = () => { const f = fonts[st.f]; return f && f.cp ? f.cp : ansiCp; };
    function container() {
      if (pp.intbl) {
        if (!table) { table = h('table', { 'data-borders': '1' }, h('tbody')); out.append(table); }
        if (!row) { row = h('tr'); table.tBodies[0].append(row); }
        if (!cellEl) { cellEl = h('td'); row.append(cellEl); }
        return cellEl;
      }
      if (table) { table = null; row = null; cellEl = null; }
      return out;
    }
    function newPara() {
      const c = container();
      let el;
      if (pp.ls && !pp.intbl) {
        const numbered = /^\s*(\d+|[a-zA-Zа-яА-Я]|[ivxlcIVXLC]+)[.)]/.test(listText);
        const tag = numbered ? 'OL' : 'UL';
        while (listStack.length > pp.ilvl + 1) listStack.pop();
        let top = listStack[listStack.length - 1];
        if (!top || listStack.length < pp.ilvl + 1 || top.tagName !== tag || top.__ls !== pp.ls) {
          if (top && listStack.length === pp.ilvl + 1) listStack.pop();
          const lst = document.createElement(tag); lst.__ls = pp.ls;
          const parent = listStack[listStack.length - 1];
          if (parent && parent.lastElementChild) parent.lastElementChild.append(lst); else out.append(lst);
          listStack.push(lst); top = lst;
        }
        el = document.createElement('li');
        top.append(el);
      } else {
        listStack = [];
        el = document.createElement(pp.style && /^h[1-6]$/.test(pp.style) ? pp.style : 'p');
        c.append(el);
      }
      const css = [];
      if (pp.align && pp.align !== 'left') css.push('text-align:' + pp.align);
      if (!pp.ls) {
        if (pp.li) css.push(`margin-left:${pp.li / 20}pt`);
        if (pp.fi) css.push(`text-indent:${pp.fi / 20}pt`);
      }
      if (pp.ri) css.push(`margin-right:${pp.ri / 20}pt`);
      if (pp.sb) css.push(`margin-top:${pp.sb / 20}pt`);
      if (pp.sa) css.push(`margin-bottom:${pp.sa / 20}pt`);
      if (pp.sl) css.push('line-height:' + (pp.slmult ? +(Math.abs(pp.sl) / 240 * Fmt.LH).toFixed(3) : Math.abs(pp.sl) / 20 + 'pt'));
      if (css.length) el.setAttribute('style', css.join(';'));
      return el;
    }
    const ensureP = () => p || (p = newPara());
    function flushBytes() {
      if (!pendingBytes.length) return;
      const s = dec(curCp()).decode(new Uint8Array(pendingBytes));
      pendingBytes = [];
      text(s, true);
    }
    function runCss() {
      const c = [];
      const f = fonts[st.f];
      if (f && st.f !== defF) c.push('font-family:' + Fonts.css(f.name).replace(/"/g, "'"));
      if (st.fs && st.fs !== meta.defaultSize * 2) c.push(`font-size:${st.fs / 2}pt`);
      if (st.b) c.push('font-weight:bold');
      if (st.i) c.push('font-style:italic');
      const d = [];
      if (st.ul) d.push('underline');
      if (st.strike) d.push('line-through');
      if (d.length) c.push('text-decoration-line:' + d.join(' '));
      if (st.cf && colors[st.cf]) c.push('color:' + colors[st.cf]);
      if (st.cb && colors[st.cb]) c.push('background-color:' + colors[st.cb]);
      if (st.caps) c.push('text-transform:uppercase');
      return c.join(';');
    }
    function text(s, decoded) {
      if (!decoded) { if (pendingBytes.length) flushBytes(); }
      if (st.dest) {
        if (st.dest === 'fonttbl' && fontTmp) fontTmp.name += s;
        else if (st.dest === 'listtext') listText += s;
        else if (st.dest === 'title') meta.title += s;
        else if (st.dest === 'pict' && pict) pict.hex += s;
        return;
      }
      if (st.hidden || !s) return;
      const target = ensureP();
      const css = runCss();
      let node = document.createTextNode(s);
      if (st.sup || st.sub) { const e = document.createElement(st.sup ? 'sup' : 'sub'); e.append(node); node = e; }
      const last = target.lastChild;
      if (css && last && last.nodeType === 1 && last.tagName === 'SPAN' && last.getAttribute('style') === css && node.nodeType === 3) last.append(node);
      else if (!css && last && last.nodeType === 3 && node.nodeType === 3) last.data += s;
      else if (css) { const sp = document.createElement('span'); sp.setAttribute('style', css); sp.append(node); target.append(sp); }
      else target.append(node);
    }
    function endPara() {
      flushBytes();
      const el = ensureP();
      if (!el.childNodes.length) el.innerHTML = '<br>';
      p = null; listText = '';
    }

    const IGNORE_DEST = new Set(['stylesheet', 'listtable', 'listoverridetable', 'revtbl', 'rsidtbl', 'generator', 'xmlnstbl', 'mmathPr', 'themedata', 'colorschememapping', 'latentstyles', 'datastore', 'fldinst', 'header', 'footer', 'headerl', 'headerr', 'headerf', 'footerl', 'footerr', 'footerf', 'footnote', 'annotation', 'atnid', 'atnauthor', 'pnseclvl', 'pntxta', 'pntxtb', 'bkmkstart', 'bkmkend', 'object', 'nonshppict', 'shpinst', 'author', 'operator', 'company', 'creatim', 'revtim', 'printim', 'buptim', 'comment', 'subject', 'keywords', 'doccomm', 'userprops', 'filetbl', 'pgdsctbl', 'wgrffmtfilter', 'xe', 'tc', 'background', 'blipuid', 'pnseclvl', 'fchars', 'lchars', 'template', 'docvar', 'listpicture', 'protusertbl', 'defchp', 'defpap']);
    let i = 0;
    const n = src.length;
    let starDest = false;
    while (i < n) {
      const ch = src[i];
      if (ch === '{') { flushBytes(); stack.push(Object.assign({}, st)); i++; continue; }
      if (ch === '}') {
        flushBytes();
        if (st.dest === 'fonttbl' && fontTmp && stack.length && stack[stack.length - 1].dest !== 'fonttbl') { /* конец таблицы */ }
        if (st.dest === 'pict' && pict && (!stack.length || stack[stack.length - 1].dest !== 'pict')) { pictures.push(pict); placePict(pict); pict = null; }
        st = stack.pop() || freshChar();
        i++; continue;
      }
      if (ch === '\\') {
        const nx = src[i + 1];
        if (nx === "'") {
          const hex = src.substr(i + 2, 2);
          i += 4;
          if (skipChars > 0) { skipChars--; continue; }
          if (st.dest && st.dest !== 'fonttbl' && st.dest !== 'listtext' && st.dest !== 'title') continue;
          pendingBytes.push(parseInt(hex, 16));
          continue;
        }
        if (nx === '\\' || nx === '{' || nx === '}') { if (skipChars > 0) skipChars--; else text(nx); i += 2; continue; }
        if (nx === '~') { text('\u00A0'); i += 2; continue; }
        if (nx === '-') { text('\u00AD'); i += 2; continue; }
        if (nx === '_') { text('\u2011'); i += 2; continue; }
        if (nx === '*') { starDest = true; i += 2; continue; }
        if (nx === '\n' || nx === '\r') { if (!st.dest) { endPara(); } i += 2; continue; }
        const m = /^([a-zA-Z]+)(-?\d+)? ?/.exec(src.substr(i + 1, 40));
        if (!m) { i += 2; continue; }
        i += 1 + m[0].length;
        const w = m[1], arg = m[2] != null ? parseInt(m[2], 10) : null;
        if (w !== 'u' && w !== "'" && pendingBytes.length) flushBytes();
        if (starDest) {
          starDest = false;
          if (w !== 'shppict' && w !== 'listtext') { st.dest = 'skip'; continue; }
        }
        if (st.dest === 'skip' || (st.dest && IGNORE_DEST.has(st.dest))) {
          if (w === 'bin' && arg) i += arg;
          continue;
        }
        if (skipChars > 0 && w !== 'u') { skipChars = 0; }
        switch (w) {
          case 'ansicpg': ansiCp = arg; break;
          case 'deff': defF = arg; break;
          case 'fonttbl': st.dest = 'fonttbl'; break;
          case 'colortbl': st.dest = 'colortbl'; colorTmp = { r: 0, g: 0, b: 0, set: false }; break;
          case 'red': if (colorTmp) { colorTmp.r = arg; colorTmp.set = true; } break;
          case 'green': if (colorTmp) { colorTmp.g = arg; colorTmp.set = true; } break;
          case 'blue': if (colorTmp) { colorTmp.b = arg; colorTmp.set = true; } break;
          case 'info': st.dest = 'info'; break;
          case 'title': st.dest = 'title'; break;
          case 'pict': st.dest = 'pict'; pict = { hex: '', type: 'png', w: 0, h: 0, gw: 0, gh: 0, sx: 100, sy: 100 }; break;
          case 'pngblip': if (pict) pict.type = 'png'; break;
          case 'jpegblip': if (pict) pict.type = 'jpeg'; break;
          case 'emfblip': case 'wmetafile': case 'macpict': case 'dibitmap': case 'wbitmap': if (pict) pict.type = 'unsupported'; break;
          case 'picwgoal': if (pict) pict.gw = arg; break;
          case 'pichgoal': if (pict) pict.gh = arg; break;
          case 'picw': if (pict) pict.w = arg; break;
          case 'pich': if (pict) pict.h = arg; break;
          case 'picscalex': if (pict) pict.sx = arg; break;
          case 'picscaley': if (pict) pict.sy = arg; break;
          case 'listtext': case 'pntext': st.dest = 'listtext'; listText = ''; break;
          case 'fldrslt': break;
          case 'paperw': meta.pageW = +Fmt.twToMm(arg).toFixed(1); break;
          case 'paperh': meta.pageH = +Fmt.twToMm(arg).toFixed(1); break;
          case 'margl': meta.margins.l = +Fmt.twToMm(arg).toFixed(1); break;
          case 'margr': meta.margins.r = +Fmt.twToMm(arg).toFixed(1); break;
          case 'margt': meta.margins.t = +Fmt.twToMm(arg).toFixed(1); break;
          case 'margb': meta.margins.b = +Fmt.twToMm(arg).toFixed(1); break;
          case 'landscape': meta.orientation = 'landscape'; break;
          // символы
          case 'f':
            if (st.dest === 'fonttbl') { fontTmp = { name: '', cp: null }; fonts[arg] = fontTmp; }
            else st.f = arg;
            break;
          case 'fcharset': if (fontTmp && st.dest === 'fonttbl') fontTmp.cp = CHARSET_CP[arg] || null; break;
          case 'fs': st.fs = arg; break;
          case 'b': st.b = arg !== 0; break;
          case 'i': st.i = arg !== 0; break;
          case 'ul': case 'uld': case 'uldb': case 'ulw': case 'ulwave': case 'uldash': st.ul = arg !== 0; break;
          case 'ulnone': st.ul = false; break;
          case 'strike': case 'striked': st.strike = arg !== 0; break;
          case 'super': st.sup = true; st.sub = false; break;
          case 'sub': st.sub = true; st.sup = false; break;
          case 'nosupersub': st.sup = st.sub = false; break;
          case 'caps': st.caps = arg !== 0; break;
          case 'v': st.hidden = arg !== 0; break;
          case 'cf': st.cf = arg; break;
          case 'cb': case 'highlight': case 'chcbpat': st.cb = arg; break;
          case 'plain': Object.assign(st, { b: false, i: false, ul: false, strike: false, fs: 24, f: defF, cf: 0, cb: 0, sup: false, sub: false, caps: false, hidden: false }); break;
          case 'uc': st.uc = arg; break;
          case 'u': { let c = arg; if (c < 0) c += 65536; flushBytes(); text(String.fromCharCode(c)); skipChars = st.uc; break; }
          // абзацы
          case 'pard': pp = freshPara(); break;
          case 'par': if (st.dest) break; endPara(); break;
          case 'line': text('\n'); break;
          case 'tab': text('\t'); break;
          case 'page': endPara(); out.append(h('div', { class: 'page-break' })); break;
          case 'ql': pp.align = 'left'; break;
          case 'qc': pp.align = 'center'; break;
          case 'qr': pp.align = 'right'; break;
          case 'qj': pp.align = 'justify'; break;
          case 'li': pp.li = arg; break;
          case 'ri': pp.ri = arg; break;
          case 'fi': pp.fi = arg; break;
          case 'sb': pp.sb = arg; break;
          case 'sa': pp.sa = arg; break;
          case 'sl': pp.sl = arg; break;
          case 'slmult': pp.slmult = arg; break;
          case 'outlinelevel': if (arg >= 0 && arg < 6) pp.style = 'h' + (arg + 1); break;
          case 'ls': pp.ls = arg; break;
          case 'ilvl': pp.ilvl = arg; break;
          case 'pnlvlblt': if (!pp.ls) { pp.ls = 9999; listText = '•'; } break;
          case 'pnlvlbody': if (!pp.ls) { pp.ls = 9998; listText = '1.'; } break;
          case 'intbl': pp.intbl = true; break;
          case 'cell': endPara(); cellEl = null; break;
          case 'nestcell': endPara(); cellEl = null; break;
          case 'row': row = null; cellEl = null; break;
          case 'emdash': text('—'); break;
          case 'endash': text('–'); break;
          case 'bullet': text('•'); break;
          case 'lquote': text('‘'); break;
          case 'rquote': text('’'); break;
          case 'ldblquote': text('“'); break;
          case 'rdblquote': text('”'); break;
          case 'emspace': text('\u2003'); break;
          case 'enspace': text('\u2002'); break;
          case 'bin': i += arg || 0; break;
          default:
            if (IGNORE_DEST.has(w)) st.dest = w;
        }
        continue;
      }
      if (ch === '\r' || ch === '\n') { i++; continue; }
      // обычный текст
      let j = i;
      while (j < n && !'\\{}\r\n'.includes(src[j])) j++;
      let chunk = src.slice(i, j);
      i = j;
      if (skipChars > 0) { const k = Math.min(skipChars, chunk.length); chunk = chunk.slice(k); skipChars -= k; }
      if (!chunk) continue;
      if (st.dest === 'fonttbl') { if (fontTmp) { fontTmp.name += chunk; if (chunk.includes(';')) { fontTmp.name = fontTmp.name.replace(/;.*$/, '').trim(); } } continue; }
      if (st.dest === 'colortbl') {
        for (const c of chunk) if (c === ';') { colors.push(colorTmp && colorTmp.set ? '#' + [colorTmp.r, colorTmp.g, colorTmp.b].map(x => x.toString(16).padStart(2, '0')).join('') : null); colorTmp = { r: 0, g: 0, b: 0, set: false }; }
        continue;
      }
      if (st.dest === 'pict') { if (pict) pict.hex += chunk; continue; }
      if (st.dest === 'info' || (st.dest && IGNORE_DEST.has(st.dest)) || st.dest === 'skip') continue;
      // байты > 127 в «сыром» тексте трактуем в кодировке документа
      if (/[\x80-\xff]/.test(chunk) && !st.dest) { for (const c of chunk) pendingBytes.push(c.charCodeAt(0)); flushBytes(); continue; }
      text(chunk);
    }
    flushBytes();
    if (p) endPara();
    // имена шрифтов: убрать ; и альтернативы
    for (const k in fonts) fonts[k].name = fonts[k].name.replace(/;.*$/, '').trim();
    if (defF != null && fonts[defF]) meta.defaultFont = fonts[defF].name;
    // шрифты в стилях проставлены до очистки имён — исправим «хвосты»
    out.querySelectorAll('[style*="font-family"]').forEach(e => { e.style.fontFamily = e.style.fontFamily.replace(/;.*$/, ''); });

    function placePict(pc) {
      if (pc.type === 'unsupported' || !pc.hex) return;
      const hex = pc.hex.replace(/[^0-9a-fA-F]/g, '');
      const b = new Uint8Array(hex.length >> 1);
      for (let k = 0; k < b.length; k++) b[k] = parseInt(hex.substr(k * 2, 2), 16);
      const img = document.createElement('img');
      img.src = Fmt.bytesToDataUrl(b, pc.type === 'jpeg' ? 'image/jpeg' : 'image/png');
      const wtw = pc.gw ? pc.gw * pc.sx / 100 : 0;
      if (wtw) img.style.width = Math.round(wtw / 15) + 'px';
      ensureP().append(img);
    }
    return { html: out.innerHTML, meta };
  }

  // ===================== ЗАПИСЬ =====================
  function write(docEl, meta) {
    document.documentElement.classList.add('exporting');
    try { return writeInner(docEl, meta); } finally { document.documentElement.classList.remove('exporting'); }
  }
  function writeInner(docEl, meta) {
    const zoom = parseFloat(getComputedStyle(document.getElementById('page')).zoom) || 1;
    const fonts = [meta.defaultFont || 'Times New Roman'], colors = [];
    const fi = name => { let k = fonts.indexOf(name); if (k < 0) { fonts.push(name); k = fonts.length - 1; } return k; };
    const ci = hex => { let k = colors.indexOf(hex); if (k < 0) { colors.push(hex); k = colors.length - 1; } return k + 1; };
    const enc = s => {
      let o = '';
      for (const c of s.replace(/\u200B/g, '')) {
        const code = c.codePointAt(0);
        if (c === '\\' || c === '{' || c === '}') o += '\\' + c;
        else if (c === '\t') o += '\\tab ';
        else if (c === '\n') o += '\\line ';
        else if (code === 0xA0) o += '\\~';
        else if (code < 128) o += c;
        else if (code > 0xFFFF) { const s2 = c; for (let k = 0; k < s2.length; k++) { let u = s2.charCodeAt(k); if (u > 32767) u -= 65536; o += `\\u${u}?`; } }
        else { let u = code; if (u > 32767) u -= 65536; o += `\\u${u}?`; }
      }
      return o;
    };
    const run = el => {
      const r = Fmt.runStyle(el);
      let s = `\\f${fi(r.font)}\\fs${Math.round(r.size * 2)}`;
      if (r.b) s += '\\b'; if (r.i) s += '\\i';
      if (r.u) s += r.u === 'double' ? '\\uldb' : r.u === 'dotted' ? '\\uld' : r.u === 'wavy' ? '\\ulwave' : '\\ul';
      if (r.strike) s += '\\strike';
      if (r.vert === 'super') s += '\\super'; else if (r.vert === 'sub') s += '\\sub';
      if (r.caps) s += '\\caps';
      if (r.color && r.color !== '000000') s += `\\cf${ci(r.color)}`;
      if (r.bg) s += `\\chcbpat${ci(r.bg)}\\cb${ci(r.bg)}`;
      return s + ' ';
    };
    const para = (el, extra = '') => {
      const ps = Fmt.paraStyle(el);
      let s = '\\pard\\plain' + extra;
      s += { center: '\\qc', right: '\\qr', justify: '\\qj', left: '\\ql' }[ps.align];
      if (ps.ml) s += `\\li${Math.round(ps.ml * 20)}`;
      if (ps.mr) s += `\\ri${Math.round(ps.mr * 20)}`;
      if (ps.ti) s += `\\fi${Math.round(ps.ti * 20)}`;
      s += `\\sb${Math.round(ps.mt * 20)}\\sa${Math.round(ps.mb * 20)}`;
      if (ps.lhExact) s += `\\sl-${Math.round(ps.lhExact * 20)}\\slmult0`;
      else if (ps.lh) s += `\\sl${Math.round(ps.lh * 240)}\\slmult1`;
      if (/^H[1-6]$/.test(el.tagName)) s += `\\outlinelevel${+el.tagName[1] - 1}`;
      return s + ' ';
    };
    const inline = n => {
      if (n.nodeType === 3) { const t = n.data.replace(/\u200B/g, ''); return t ? `{${run(n.parentElement)}${enc(t)}}` : ''; }
      if (n.nodeType !== 1) return '';
      if (n.tagName === 'BR') return Fmt.trailingBr(n) ? '' : '\\line ';
      if (n.tagName === 'IMG') return pict(n);
      if (n.tagName === 'A' && /^https?:|^mailto:/.test(n.getAttribute('href') || '')) return `{\\field{\\*\\fldinst HYPERLINK "${enc(n.getAttribute('href'))}"}{\\fldrslt ${[...n.childNodes].map(inline).join('')}}}`;
      if (n.tagName === 'SUP' && n.classList.contains('fn')) {
        const li = docEl.querySelector('#' + CSS.escape(n.dataset.fn));
        return `{\\super\\chftn}{\\footnote\\pard\\plain{\\super\\chftn} ${enc(li ? li.textContent : '')}}`;
      }
      if (/^(UL|OL|TABLE)$/.test(n.tagName)) return enc(n.innerText);
      return [...n.childNodes].map(inline).join('');
    };
    const pict = img => {
      let d = img.src.startsWith('data:') ? Fmt.dataUrlToBytes(img.src) : null;
      if (!d || !/png|jpeg/.test(d.mime)) {
        try { const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight; c.getContext('2d').drawImage(img, 0, 0); d = Fmt.dataUrlToBytes(c.toDataURL('image/png')); } catch (e) { return ''; }
      }
      const [iw, ih] = Fmt.imageSize(img);
      const w = Math.round(iw * 15), hh = Math.round(ih * 15);
      let hex = '';
      for (let k = 0; k < d.bytes.length; k++) { hex += d.bytes[k].toString(16).padStart(2, '0'); if (k % 64 === 63) hex += '\n'; }
      return `{\\pict${d.mime === 'image/jpeg' ? '\\jpegblip' : '\\pngblip'}\\picw${img.naturalWidth}\\pich${img.naturalHeight}\\picwgoal${w}\\pichgoal${hh}\n${hex}}`;
    };
    const isBlock = t => /^(P|H[1-6]|DIV|UL|OL|LI|TABLE|BLOCKQUOTE|PRE|HR)$/.test(t);
    let pendingPage = false;
    const block = (n, extra = '') => {
      if (n.nodeType === 3) return n.data.trim() ? `\\pard\\plain ${enc(n.data)}\\par\n` : '';
      if (n.nodeType !== 1) return '';
      const t = n.tagName;
      if (n.classList.contains('page-break')) { pendingPage = true; return ''; }
      if (n.classList.contains('footnotes') || n.classList.contains('col-break')) return '';
      const pb = pendingPage ? '\\pagebb' : '';
      pendingPage = false;
      if (t === 'HR') return `\\pard\\plain${pb}\\brdrb\\brdrs\\brdrw10\\brsp20 \\par\n`;
      if (t === 'TABLE') return table(n);
      if (t === 'UL' || t === 'OL') return list(n, 0);
      if (n.classList.contains('toc')) return [...n.querySelectorAll('.toc-title, a')].map(a => `\\pard\\plain ${enc(a.classList.contains('toc-title') ? a.textContent : (a.querySelector('.t')?.textContent || '') + '\t' + (a.querySelector('.n')?.textContent || ''))}\\par\n`).join('');
      if ([...n.children].some(c => isBlock(c.tagName))) return [...n.childNodes].map(c => block(c, extra)).join('');
      return para(n, pb + extra) + [...n.childNodes].map(inline).join('') + '\\par\n';
    };
    const list = (l, lvl) => {
      let s = '', k = +l.getAttribute('start') || 1;
      const type = getComputedStyle(l).listStyleType;
      const label = idx => {
        if (l.tagName === 'UL') return l.classList.contains('checklist') ? '☐' : ['•', '◦', '▪'][lvl % 3];
        if (/alpha|latin/.test(type)) { const c = String.fromCharCode(96 + ((idx - 1) % 26) + 1); return (/upper/.test(type) ? c.toUpperCase() : c) + '.'; }
        if (/roman/.test(type)) { const r = toRoman(idx); return (/upper/.test(type) ? r : r.toLowerCase()) + '.'; }
        return idx + '.';
      };
      for (const li of l.children) {
        if (li.tagName !== 'LI') continue;
        const inl = [], nested = [];
        for (const c of li.childNodes) (c.nodeType === 1 && /^(UL|OL)$/.test(c.tagName) ? nested : inl).push(c);
        let lab = label(k++);
        if (l.classList.contains('checklist') && li.dataset.checked === '1') lab = '☑';
        const indent = 360 + lvl * 360;
        s += para(li).replace('\\pard\\plain', `\\pard\\plain\\li${indent + 360}\\fi-360`) + `{${enc(lab)}\\tab}` + inl.map(c => c.nodeType === 1 && isBlock(c.tagName) ? [...c.childNodes].map(inline).join('') : inline(c)).join('') + '\\par\n';
        for (const nl of nested) s += list(nl, lvl + 1);
      }
      return s;
    };
    const table = t => {
      const rows = [...t.rows];
      const G = [];
      rows.forEach((tr, r) => {
        G[r] = G[r] || []; let c = 0;
        for (const td of tr.cells) { while (G[r][c]) c++; for (let a = 0; a < (td.rowSpan || 1); a++) for (let b = 0; b < (td.colSpan || 1); b++) { G[r + a] = G[r + a] || []; G[r + a][c + b] = td; } c += td.colSpan || 1; }
      });
      const ncol = Math.max(...G.map(r => r.length));
      const tw = Math.round(Fmt.paperWidth(t) * 15) || 9000;
      const cw = Math.round(tw / ncol);
      const border = t.dataset.borders !== '0' ? '\\clbrdrt\\brdrs\\brdrw10\\clbrdrl\\brdrs\\brdrw10\\clbrdrb\\brdrs\\brdrw10\\clbrdrr\\brdrs\\brdrw10' : '';
      let s = '';
      for (let r = 0; r < G.length; r++) {
        s += '\\trowd\\trgaph108\\trleft0';
        let x = 0;
        for (let c = 0; c < ncol; c++) {
          const td = G[r][c];
          const sr = td ? G.findIndex(row => row.includes(td)) : r;
          const scol = td ? G[sr].indexOf(td) : c;
          let merge = '';
          if (td && (td.rowSpan || 1) > 1) merge += sr === r ? '\\clvmgf' : '\\clvmrg';
          if (td && (td.colSpan || 1) > 1) merge += scol === c ? '\\clmgf' : '\\clmrg';
          const bg = td ? Fmt.toHex(getComputedStyle(td).backgroundColor) : null;
          x += cw;
          s += `${merge}${border}${bg ? `\\clcbpat${ci(bg)}` : ''}\\cellx${x}`;
        }
        s += '\n';
        for (let c = 0; c < ncol; c++) {
          const td = G[r][c];
          const sr = td ? G.findIndex(row => row.includes(td)) : r;
          const scol = td ? G[sr].indexOf(td) : c;
          if (!td || sr !== r || scol !== c) { s += '\\pard\\intbl \\cell\n'; continue; }
          const kids = [...td.childNodes];
          const blocks = kids.filter(k => k.nodeType === 1 && isBlock(k.tagName) && !/^(TABLE|UL|OL)$/.test(k.tagName));
          if (blocks.length) s += blocks.map((b, bi) => para(b, '\\intbl') + [...b.childNodes].map(inline).join('') + (bi < blocks.length - 1 ? '\\par ' : '')).join('') + '\\cell\n';
          else s += para(td, '\\intbl') + kids.map(inline).join('') + '\\cell\n';
        }
        s += '\\row\n';
      }
      return s + '\\pard\n';
    };
    let body = '';
    for (const n of docEl.childNodes) body += block(n);
    const land = meta.orientation === 'landscape';
    let pw = Fmt.mmToTw(meta.pageW), ph = Fmt.mmToTw(meta.pageH);
    if (land && pw < ph) [pw, ph] = [ph, pw];
    const mg = meta.margins;
    const pn = meta.pageNumbers || 'none';
    const pnAl = pn.endsWith('right') ? '\\qr' : pn.endsWith('left') ? '\\ql' : '\\qc';
    const fld = '{\\field{\\*\\fldinst PAGE}{\\fldrslt 1}}';
    let hf = '';
    if (meta.header || pn.startsWith('top')) hf += `{\\header ${meta.header ? `\\pard\\qc ${enc(meta.header)}\\par ` : ''}${pn.startsWith('top') ? `\\pard${pnAl} ${fld}\\par` : ''}}`;
    if (meta.footer || pn.startsWith('bottom')) hf += `{\\footer ${meta.footer ? `\\pard\\qc ${enc(meta.footer)}\\par ` : ''}${pn.startsWith('bottom') ? `\\pard${pnAl} ${fld}\\par` : ''}}`;
    const fontTbl = '{\\fonttbl' + fonts.map((f, k) => `{\\f${k}\\fnil\\fcharset204 ${enc(f)};}`).join('') + '}';
    const colTbl = '{\\colortbl;' + colors.map(c => `\\red${parseInt(c.slice(0, 2), 16)}\\green${parseInt(c.slice(2, 4), 16)}\\blue${parseInt(c.slice(4, 6), 16)};`).join('') + '}';
    const rtf = `{\\rtf1\\ansi\\ansicpg1251\\deff0\\uc1${fontTbl}${colTbl}{\\info{\\title ${enc(meta.title || '')}}}` +
      `\\paperw${pw}\\paperh${ph}\\margl${Fmt.mmToTw(mg.l)}\\margr${Fmt.mmToTw(mg.r)}\\margt${Fmt.mmToTw(mg.t)}\\margb${Fmt.mmToTw(mg.b)}${land ? '\\landscape' : ''}` +
      `${meta.columns > 1 ? `\\cols${meta.columns}` : ''}\\deflang1049\\fs${Math.round(meta.defaultSize * 2)}\n${hf}\n${body}}`;
    return new TextEncoder().encode(rtf);
  }
  function toRoman(n) {
    const m = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
    let s = '';
    for (const [v, r] of m) while (n >= v) { s += r; n -= v; }
    return s;
  }
  return { read, write };
})();
