/* Просмотр PDF (pdf.js) и преобразование PDF в редактируемый текст */
'use strict';
const PdfView = (() => {
  let lib = null, pdf = null, scale = 1, observer = null, bytesCache = null;
  const base = p => new URL('lib/pdfjs/' + p, document.baseURI).href;
  async function load() {
    if (lib) return lib;
    lib = await import(base('pdf.min.js'));
    lib.GlobalWorkerOptions.workerSrc = base('pdf.worker.min.js');
    return lib;
  }
  async function open(bytes, name) {
    await load();
    bytesCache = bytes.slice();
    pdf = await lib.getDocument({
      data: bytes.slice(), cMapUrl: base('cmaps/'), cMapPacked: true, standardFontDataUrl: base('standard_fonts/'),
      wasmUrl: base('wasm/'), iccUrl: base('iccs/'), isEvalSupported: false
    }).promise;
    const view = $('#pdfView');
    view.innerHTML = '';
    const bar = h('div', { class: 'pdf-bar' },
      h('button', { class: 'btn', text: '−', onclick: () => rescale(scale / 1.2) }),
      h('button', { class: 'btn', text: 'По ширине', onclick: () => rescale(0) }),
      h('button', { class: 'btn', text: '+', onclick: () => rescale(scale * 1.2) }),
      h('button', { class: 'btn', text: 'Редактировать как текст', onclick: () => App.pdfToDoc() }),
      h('button', { class: 'btn', text: 'Закрыть', onclick: () => App.closePdf() }));
    view.append(bar);
    for (let i = 1; i <= pdf.numPages; i++) {
      const c = h('canvas', { 'data-page': i });
      c.style.width = '90%'; c.style.height = '200px';
      view.append(c);
    }
    view.hidden = false;
    await rescale(0);
    return pdf.numPages;
  }
  async function rescale(s) {
    if (!pdf) return;
    const view = $('#pdfView');
    const p1 = await pdf.getPage(1);
    const vp1 = p1.getViewport({ scale: 1 });
    if (!s) s = (view.clientWidth - 16) / vp1.width;
    scale = Math.max(0.3, Math.min(5, s));
    if (observer) observer.disconnect();
    observer = new IntersectionObserver(entries => {
      for (const e of entries) if (e.isIntersecting && !e.target.__rendered) renderPage(e.target);
    }, { root: view, rootMargin: '600px 0px' });
    for (const c of $$('canvas', view)) {
      c.__rendered = false;
      const page = await pdf.getPage(+c.dataset.page);
      const vp = page.getViewport({ scale });
      c.style.width = Math.floor(vp.width) + 'px';
      c.style.height = Math.floor(vp.height) + 'px';
      observer.observe(c);
    }
  }
  async function renderPage(c) {
    c.__rendered = true;
    const page = await pdf.getPage(+c.dataset.page);
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    const vp = page.getViewport({ scale: scale * dpr });
    c.width = vp.width; c.height = vp.height;
    await page.render({ canvasContext: c.getContext('2d'), viewport: vp, canvas: c }).promise;
  }
  /** Извлечение текста: строки по координате Y, абзацы по интервалам */
  async function toHtml() {
    if (!pdf) return '';
    const parts = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const tc = await page.getTextContent();
      const lines = [];
      let cur = null;
      for (const it of tc.items) {
        if (!('str' in it) || !it.str) continue;
        const y = it.transform[5], x = it.transform[4], size = Math.hypot(it.transform[2], it.transform[3]) || 10;
        if (!cur || Math.abs(cur.y - y) > size * 0.5) { cur = { y, size, items: [] }; lines.push(cur); }
        cur.items.push({ x, w: it.width || 0, s: it.str });
      }
      let maxRight = 0, minLeft = Infinity;
      for (const l of lines) {
        l.items.sort((a, b) => a.x - b.x);
        let t = '', end = null;
        for (const it of l.items) {
          if (end != null && it.x - end > l.size * 0.2 && !t.endsWith(' ') && !it.s.startsWith(' ')) t += ' ';
          t += it.s; end = it.x + it.w;
        }
        l.text = t.replace(/\s+/g, ' ').trim();
        l.left = l.items[0].x; l.right = end;
        maxRight = Math.max(maxRight, l.right); minLeft = Math.min(minLeft, l.left);
      }
      const width = maxRight - minLeft || 1;
      let para = null, prev = null;
      const out = [];
      for (const l of lines) {
        if (!l.text) { para = null; prev = null; continue; }
        const gap = prev ? prev.y - l.y : 0;
        const startsItem = /^([•▪◦\-–—*]|\d+[.)]|[a-zа-я][.)])\s/i.test(l.text);
        const prevShort = prev && (prev.right - minLeft) < width * 0.8;
        const newPara = !para || gap > l.size * 1.6 || startsItem || prevShort || Math.abs(l.size - para.size) > 1.5;
        if (newPara) { para = { text: l.text, size: l.size }; out.push(para); }
        else para.text += (para.text.endsWith('-') ? '' : ' ') + l.text;
        prev = l;
      }
      const sizes = out.map(p => p.size).sort((a, b) => a - b);
      const median = sizes[Math.floor(sizes.length / 2)] || 10;
      const body = out.map(p => {
        if (p.size > median * 1.6) return `<h1>${esc(p.text)}</h1>`;
        if (p.size > median * 1.25) return `<h2>${esc(p.text)}</h2>`;
        return `<p>${esc(p.text)}</p>`;
      }).join('');
      parts.push(body || '<p><br></p>');
    }
    return parts.join('<div class="page-break"></div>');
  }
  function close() { if (observer) observer.disconnect(); pdf = null; $('#pdfView').hidden = true; $('#pdfView').innerHTML = ''; }
  return { open, close, toHtml, isOpen: () => !!pdf, bytes: () => bytesCache };
})();
