/* Чтение и запись DOCX (Office Open XML) */
'use strict';
const Docx = (() => {
  const NS = {
    w: 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    r: 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    a: 'http://schemas.openxmlformats.org/drawingml/2006/main',
    wp: 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
    pic: 'http://schemas.openxmlformats.org/drawingml/2006/picture',
    v: 'urn:schemas-microsoft-com:vml',
    m: 'http://schemas.openxmlformats.org/officeDocument/2006/math'
  };
  const parse = s => new DOMParser().parseFromString(s, 'application/xml');
  const kids = (el, n) => el ? [...el.children].filter(c => c.localName === n) : [];
  const kid = (el, n) => el ? [...el.children].find(c => c.localName === n) || null : null;
  const deep = (el, n) => el ? [...el.getElementsByTagNameNS('*', n)] : [];
  const wa = (el, n) => el ? (el.getAttributeNS(NS.w, n) ?? el.getAttribute('w:' + n)) : null;
  const ra = (el, n) => el ? (el.getAttributeNS(NS.r, n) ?? el.getAttribute('r:' + n)) : null;
  const on = el => { if (!el) return undefined; const v = wa(el, 'val'); return !(v === '0' || v === 'false' || v === 'off' || v === 'none'); };
  const num = v => (v == null || v === '' ? null : parseFloat(v));

  // ===================== ЧТЕНИЕ =====================
  async function read(bytes) {
    const zip = await Zip.read(bytes);
    const relsXml = await zip.text('_rels/.rels');
    let mainPath = 'word/document.xml';
    if (relsXml) {
      const rel = [...parse(relsXml).getElementsByTagName('Relationship')].find(r => /officeDocument$/.test(r.getAttribute('Type')));
      if (rel) mainPath = rel.getAttribute('Target').replace(/^\//, '');
    }
    const base = mainPath.replace(/[^/]+$/, '');
    const docXml = await zip.text(mainPath);
    if (!docXml) throw new Error('В архиве нет основного документа (это не DOCX?)');
    const dx = parse(docXml);
    const rels = {};
    const rx = await zip.text(base + '_rels/' + mainPath.split('/').pop() + '.rels');
    if (rx) for (const r of parse(rx).getElementsByTagName('Relationship'))
      rels[r.getAttribute('Id')] = { target: r.getAttribute('Target'), mode: r.getAttribute('TargetMode'), type: r.getAttribute('Type') };
    const resolve = t => t.startsWith('/') ? t.slice(1) : (base + t).replace(/[^/]+\/\.\.\//g, '');

    const ctx = { zip, rels, resolve, styles: {}, defaults: { r: {}, p: {} }, numbering: { abs: {}, nums: {} }, comments: {}, footnotes: {},
      fnList: [], meta: Fmt.defaultMeta(), imgCount: 0, numCounters: {} };

    // стили
    const stx = await zip.text(base + 'styles.xml');
    if (stx) readStyles(parse(stx), ctx);
    const nmx = await zip.text(base + 'numbering.xml');
    if (nmx) readNumbering(parse(nmx), ctx);
    const cmx = await zip.text(base + 'comments.xml');
    if (cmx) for (const c of deep(parse(cmx), 'comment')) {
      ctx.comments[wa(c, 'id')] = { author: wa(c, 'author') || '', date: wa(c, 'date') || '', text: deep(c, 'p').map(p => deep(p, 't').map(t => t.textContent).join('')).join('\n') };
    }
    const fnx = await zip.text(base + 'footnotes.xml');
    if (fnx) for (const f of deep(parse(fnx), 'footnote')) {
      if (wa(f, 'type')) continue;
      ctx.footnotes[wa(f, 'id')] = deep(f, 'p').map(p => deep(p, 't').map(t => t.textContent).join('')).join(' ').trim();
    }
    const enx = await zip.text(base + 'endnotes.xml');
    if (enx) for (const f of deep(parse(enx), 'endnote')) {
      if (wa(f, 'type')) continue;
      ctx.footnotes['e' + wa(f, 'id')] = deep(f, 'p').map(p => deep(p, 't').map(t => t.textContent).join('')).join(' ').trim();
    }

    // параметры документа по умолчанию
    const dr = ctx.defaults.r, dp = ctx.defaults.p;
    const normal = Object.values(ctx.styles).find(s => s.type === 'paragraph' && s.isDefault) || ctx.styles.Normal;
    const nr = Object.assign({}, dr, normal ? normal.r : {});
    const np = Object.assign({}, dp, normal ? normal.p : {});
    if (nr.font) ctx.meta.defaultFont = nr.font;
    ctx.meta.defaultSize = nr.sz || 10;
    ctx.meta.defaultAfter = np.after != null ? np.after : 0;
    ctx.meta.defaultLine = np.line && np.lineRule !== 'exact' && np.lineRule !== 'atLeast' ? +(np.line).toFixed(2) : 1;
    ctx.meta.defaultIndent = 0;
    ctx.docDefaults = { r: nr, p: np };

    const body = dx.getElementsByTagNameNS(NS.w, 'body')[0] || deep(dx, 'body')[0];
    const out = document.createElement('div');
    convertBlocks(body, out, ctx);

    await Promise.all(ctx.imgPromises || []);
    // сноски
    if (ctx.fnList.length) {
      const box = h('div', { class: 'footnotes' }, h('ol', null, ctx.fnList.map(f => h('li', { id: f.id, text: f.text }))));
      out.append(box);
    }

    // раздел (последний sectPr)
    const sect = kid(body, 'sectPr') || deep(body, 'sectPr').pop();
    if (sect) await readSection(sect, ctx);

    const core = await zip.text('docProps/core.xml');
    if (core) { const t = deep(parse(core), 'title')[0]; if (t && t.textContent.trim()) ctx.meta.title = t.textContent.trim(); }
    return { html: out.innerHTML, meta: ctx.meta };
  }

  function readRPr(rPr) {
    const o = {};
    if (!rPr) return o;
    for (const c of rPr.children) {
      const n = c.localName;
      switch (n) {
        case 'b': o.b = on(c); break;
        case 'i': o.i = on(c); break;
        case 'u': { const v = wa(c, 'val'); o.u = v && v !== 'none' ? v : false; const col = wa(c, 'color'); if (col && col !== 'auto') o.uColor = col; break; }
        case 'strike': o.strike = on(c); break;
        case 'dstrike': o.dstrike = on(c); break;
        case 'vertAlign': o.vert = wa(c, 'val'); break;
        case 'sz': o.sz = num(wa(c, 'val')) / 2; break;
        case 'rFonts': { const f = wa(c, 'ascii') || wa(c, 'hAnsi') || wa(c, 'cs') || wa(c, 'eastAsia'); if (f) o.font = f; else if (wa(c, 'asciiTheme')) o.fontTheme = wa(c, 'asciiTheme'); break; }
        case 'color': { const v = wa(c, 'val'); if (v && v !== 'auto') o.color = v; break; }
        case 'highlight': { const v = wa(c, 'val'); if (v && v !== 'none') o.hl = Fmt.HL[v] || null; break; }
        case 'shd': { const f = wa(c, 'fill'); if (f && f !== 'auto' && f !== 'FFFFFF') o.shd = f; break; }
        case 'caps': o.caps = on(c); break;
        case 'smallCaps': o.smallCaps = on(c); break;
        case 'spacing': o.spacing = num(wa(c, 'val')); break;
        case 'vanish': o.vanish = on(c); break;
        case 'rStyle': o.rStyle = wa(c, 'val'); break;
        case 'rtl': o.rtl = on(c); break;
      }
    }
    return o;
  }
  function readPPr(pPr) {
    const o = {};
    if (!pPr) return o;
    for (const c of pPr.children) {
      switch (c.localName) {
        case 'pStyle': o.style = wa(c, 'val'); break;
        case 'jc': o.jc = wa(c, 'val'); break;
        case 'spacing': {
          const b = wa(c, 'before'), a = wa(c, 'after'), l = wa(c, 'line'), lr = wa(c, 'lineRule');
          if (b != null && wa(c, 'beforeAutospacing') !== '1') o.before = num(b) / 20;
          if (a != null && wa(c, 'afterAutospacing') !== '1') o.after = num(a) / 20;
          if (l != null) { o.lineRule = lr || 'auto'; o.line = o.lineRule === 'auto' ? num(l) / 240 : num(l) / 20; }
          break;
        }
        case 'ind': {
          const l = wa(c, 'left') ?? wa(c, 'start'), r = wa(c, 'right') ?? wa(c, 'end'), f = wa(c, 'firstLine'), hg = wa(c, 'hanging');
          if (l != null) o.left = num(l) / 20;
          if (r != null) o.right = num(r) / 20;
          if (f != null) o.first = num(f) / 20;
          if (hg != null) o.first = -num(hg) / 20;
          break;
        }
        case 'numPr': { const id = wa(kid(c, 'numId'), 'val'); const lv = wa(kid(c, 'ilvl'), 'val'); if (id != null) o.numId = id; if (lv != null) o.ilvl = +lv; break; }
        case 'outlineLvl': o.outline = +wa(c, 'val'); break;
        case 'pageBreakBefore': o.pbb = on(c); break;
        case 'shd': { const f = wa(c, 'fill'); if (f && f !== 'auto') o.shd = f; break; }
        case 'bidi': o.bidi = on(c); break;
        case 'keepNext': o.keepNext = on(c); break;
        case 'pBdr': o.border = !!kid(c, 'bottom') || !!kid(c, 'top'); break;
        case 'rPr': o.markRPr = readRPr(c); break;
      }
    }
    return o;
  }
  function readStyles(x, ctx) {
    const dd = deep(x, 'docDefaults')[0];
    if (dd) {
      ctx.defaults.r = readRPr(deep(dd, 'rPr')[0]);
      ctx.defaults.p = readPPr(deep(dd, 'pPr')[0]);
    }
    for (const s of deep(x, 'style')) {
      const id = wa(s, 'styleId');
      ctx.styles[id] = {
        id, type: wa(s, 'type'), name: (wa(kid(s, 'name'), 'val') || id || '').toLowerCase(),
        basedOn: wa(kid(s, 'basedOn'), 'val'), isDefault: wa(s, 'default') === '1',
        r: readRPr(kid(s, 'rPr')), p: readPPr(kid(s, 'pPr')), tblBorders: !!deep(s, 'tblBorders')[0] && deep(deep(s, 'tblBorders')[0], 'top').some(b => wa(b, 'val') !== 'nil' && wa(b, 'val') !== 'none')
      };
    }
  }
  function styleChain(ctx, id, key) {
    const out = {};
    const chain = [];
    let s = ctx.styles[id], guard = 0;
    while (s && guard++ < 20) { chain.unshift(s); s = ctx.styles[s.basedOn]; }
    for (const st of chain) Object.assign(out, st[key]);
    return out;
  }
  function readNumbering(x, ctx) {
    for (const an of deep(x, 'abstractNum')) {
      const lv = {};
      for (const l of kids(an, 'lvl')) {
        lv[+wa(l, 'ilvl')] = { fmt: wa(kid(l, 'numFmt'), 'val') || 'decimal', text: wa(kid(l, 'lvlText'), 'val') || '', start: +(wa(kid(l, 'start'), 'val') || 1) };
      }
      ctx.numbering.abs[wa(an, 'abstractNumId')] = lv;
    }
    for (const n of kids(x.documentElement, 'num')) {
      const o = { abs: wa(kid(n, 'abstractNumId'), 'val'), overrides: {} };
      for (const ov of kids(n, 'lvlOverride')) { const so = kid(ov, 'startOverride'); if (so) o.overrides[+wa(ov, 'ilvl')] = +wa(so, 'val'); }
      ctx.numbering.nums[wa(n, 'numId')] = o;
    }
  }
  function numLevel(ctx, numId, ilvl) {
    const n = ctx.numbering.nums[numId];
    if (!n) return null;
    const lv = (ctx.numbering.abs[n.abs] || {})[ilvl] || { fmt: 'decimal', start: 1 };
    return Object.assign({}, lv, n.overrides[ilvl] != null ? { start: n.overrides[ilvl] } : {});
  }
  const LIST_TYPE = { decimal: 'decimal', lowerLetter: 'lower-alpha', upperLetter: 'upper-alpha', lowerRoman: 'lower-roman', upperRoman: 'upper-roman',
    decimalZero: 'decimal-leading-zero', russianLower: 'cyr-lower', russianUpper: 'cyr-upper' };

  function themeFont(ctx, t) { return /major/i.test(t || '') ? 'Calibri Light' : 'Calibri'; }

  function runCss(o, ctx, para) {
    const st = [];
    const font = o.font || (o.fontTheme ? themeFont(ctx, o.fontTheme) : null);
    if (font && font !== para.font) st.push('font-family:' + Fonts.css(font).replace(/"/g, "'"));
    if (o.sz && o.sz !== para.sz) st.push(`font-size:${o.sz}pt`);
    if (o.b !== undefined && !!o.b !== !!para.b) st.push('font-weight:' + (o.b ? 'bold' : 'normal'));
    if (o.i !== undefined && !!o.i !== !!para.i) st.push('font-style:' + (o.i ? 'italic' : 'normal'));
    const dec = [];
    if (o.u) dec.push('underline');
    if (o.strike || o.dstrike) dec.push('line-through');
    if (dec.length) {
      st.push('text-decoration-line:' + dec.join(' '));
      if (o.u === 'double' || o.dstrike) st.push('text-decoration-style:double');
      else if (/wave/i.test(o.u || '')) st.push('text-decoration-style:wavy');
      else if (/dot/i.test(o.u || '')) st.push('text-decoration-style:dotted');
      else if (/dash/i.test(o.u || '')) st.push('text-decoration-style:dashed');
      if (o.uColor) st.push('text-decoration-color:#' + o.uColor);
    }
    if (o.color && o.color !== para.color) st.push('color:#' + o.color);
    if (o.hl || o.shd) st.push('background-color:#' + (o.hl || o.shd));
    if (o.caps) st.push('text-transform:uppercase');
    if (o.smallCaps) st.push('font-variant:small-caps');
    if (o.spacing) st.push(`letter-spacing:${(o.spacing / 20).toFixed(2)}pt`);
    return st.join(';');
  }

  function convertBlocks(container, out, ctx) {
    const listState = { stack: [] };
    for (const el of container.children) {
      const n = el.localName;
      if (n === 'p') paragraph(el, out, ctx, listState);
      else if (n === 'tbl') { listState.stack = []; out.append(table(el, ctx)); }
      else if (n === 'sdt') { const c = kid(el, 'sdtContent'); if (c) convertBlocks(c, out, ctx); }
      else if (n === 'customXml' || n === 'ins' || n === 'smartTag') convertBlocks(el, out, ctx);
      else if (n === 'AlternateContent') { const f = kid(el, 'Fallback') || kid(el, 'Choice'); if (f) convertBlocks(f, out, ctx); }
    }
  }

  function paragraph(p, out, ctx, ls) {
    const pp = readPPr(kid(p, 'pPr'));
    const sid = pp.style || Object.values(ctx.styles).find(s => s.type === 'paragraph' && s.isDefault)?.id || 'Normal';
    const sp = styleChain(ctx, sid, 'p');
    const sr = styleChain(ctx, sid, 'r');
    const P = Object.assign({}, ctx.defaults.p, sp, pp);
    delete P.markRPr;
    const PR = Object.assign({}, ctx.docDefaults.r, sr);
    const sname = (ctx.styles[sid]?.name || '').toLowerCase();

    // выбор тега
    let tag = 'p', cls = '';
    const outline = pp.outline ?? sp.outline;
    if (outline != null && outline < 6) tag = 'h' + (outline + 1);
    else if (/^(heading|заголовок)\s*([1-6])$/.test(sname)) tag = 'h' + sname.match(/([1-6])$/)[1];
    else if (sname === 'title' || sname === 'название') cls = 'title';
    else if (sname === 'subtitle' || sname === 'подзаголовок') cls = 'subtitle';
    else if (/quote|цитата/.test(sname)) tag = 'blockquote';
    else if (/^(no spacing|без интервала)$/.test(sname)) cls = 'no-spacing';

    const el = document.createElement(tag);
    if (cls) el.className = cls;
    const css = [];
    const D = ctx.docDefaults;
    if (P.jc && P.jc !== 'left' && P.jc !== 'start') css.push('text-align:' + ({ both: 'justify', distribute: 'justify', center: 'center', right: 'right', end: 'right' }[P.jc] || 'left'));
    if (P.before != null && (P.before || tag !== 'p') ) css.push(`margin-top:${P.before}pt`);
    if (P.after != null && (P.after !== D.p.after || tag !== 'p' || cls)) css.push(`margin-bottom:${P.after}pt`);
    if (P.line != null && !(P.lineRule === 'auto' && Math.abs(P.line - (D.p.line || 1)) < 0.01 && tag === 'p')) css.push('line-height:' + (P.lineRule === 'auto' ? +(P.line * Fmt.LH).toFixed(3) : (P.lineRule === 'exact' ? P.line + 'pt' : `max(${P.line}pt, 1.15em)`)));
    const isList = P.numId && P.numId !== '0' && ctx.numbering.nums[P.numId];
    if (!isList) {
      if (P.left) css.push(`margin-left:${P.left}pt`);
      if (P.first) css.push(`text-indent:${P.first}pt`);
    }
    if (P.right) css.push(`margin-right:${P.right}pt`);
    if (P.shd) css.push('background-color:#' + P.shd);
    if (P.bidi) el.setAttribute('dir', 'rtl');
    // свойства шрифта стиля абзаца
    const para = { font: D.r.font, sz: D.r.sz, b: false, i: false, color: null };
    if (tag !== 'p' || cls || sid !== 'Normal') {
      const f = PR.font || (PR.fontTheme ? themeFont(ctx, PR.fontTheme) : null);
      if (f && f !== D.r.font) { css.push('font-family:' + Fonts.css(f).replace(/"/g, "'")); para.font = f; }
      if (PR.sz && (PR.sz !== D.r.sz || tag !== 'p')) { css.push(`font-size:${PR.sz}pt`); para.sz = PR.sz; }
      if (PR.b !== undefined) { css.push('font-weight:' + (PR.b ? 'bold' : 'normal')); para.b = PR.b; }
      else if (/^h/.test(tag)) para.b = true;
      if (PR.i !== undefined) { css.push('font-style:' + (PR.i ? 'italic' : 'normal')); para.i = PR.i; }
      if (PR.color) { css.push('color:#' + PR.color); para.color = PR.color; }
      else if (/^h/.test(tag) || cls) css.push('color:inherit');
      if (PR.caps) css.push('text-transform:uppercase');
    } else {
      if (PR.color) { css.push('color:#' + PR.color); para.color = PR.color; }
    }
    if (tag === 'blockquote') css.push('font-style:' + (para.i ? 'italic' : 'normal'));
    if (css.length) el.setAttribute('style', css.join(';'));

    // содержимое
    const pieces = [el];
    const state = { cur: el, pieces, field: [], comments: ctx.activeComments || (ctx.activeComments = new Set()) };
    inlines(p, state, ctx, para);

    // разрыв страницы перед абзацем
    if (P.pbb) out.append(h('div', { class: 'page-break' }));

    for (const piece of pieces) {
      if (piece.classList && (piece.classList.contains('page-break') || piece.classList.contains('col-break'))) { ls.stack = []; out.append(piece); continue; }
      const empty = !piece.textContent.length && !piece.querySelector('img,br');
      if (empty && piece === el && pieces.length > 1) continue;
      if (empty) piece.innerHTML = '<br>';
      if (isList && piece === el) addListItem(piece, P, ctx, out, ls);
      else { if (piece === el) ls.stack = []; if (!(empty && piece !== el)) out.append(piece); }
    }
    if (P.border && !el.textContent.trim() && !el.querySelector('img')) el.replaceWith(h('hr'));
  }

  function addListItem(el, P, ctx, out, ls) {
    const lvl = P.ilvl || 0;
    const L = numLevel(ctx, P.numId, lvl) || { fmt: 'decimal', start: 1 };
    const bullet = L.fmt === 'bullet' || L.fmt === 'none';
    const tag = bullet ? 'UL' : 'OL';
    const li = document.createElement('li');
    // переносим стили абзаца (кроме отступов) на li
    const st = el.getAttribute('style');
    li.append(...el.childNodes);
    if (st) li.setAttribute('style', st.replace(/(^|;)\s*(margin-left|text-indent)[^;]*/g, ''));
    if (el.className) li.className = el.className;
    const s = ls.stack;
    while (s.length && s[s.length - 1].lvl > lvl) s.pop();
    let top = s[s.length - 1];
    if (top && top.lvl === lvl && (top.numId !== P.numId || top.list.tagName !== tag)) { s.pop(); top = s[s.length - 1]; }
    if (!top || top.lvl < lvl) {
      const list = document.createElement(tag);
      const key = P.numId + ':' + lvl;
      if (!bullet) {
        const typ = LIST_TYPE[L.fmt];
        if (typ && typ !== 'decimal') list.style.listStyleType = typ;
        const start = (ctx.numCounters[key] || 0) + (ctx.numCounters[key] ? 1 : L.start);
        if (start !== 1) list.setAttribute('start', start);
      } else {
        if (/[o◦]/.test(L.text)) list.style.listStyleType = 'circle';
        else if (/[§▪■]/.test(L.text)) list.style.listStyleType = 'square';
      }
      if (top) {
        const lastLi = top.list.lastElementChild || top.list.appendChild(document.createElement('li'));
        lastLi.append(list);
      } else out.append(list);
      s.push({ lvl, numId: P.numId, list });
      top = s[s.length - 1];
    }
    top.list.append(li);
    const key = P.numId + ':' + lvl;
    if (!bullet) {
      if (!ctx.numCounters[key]) ctx.numCounters[key] = (+top.list.getAttribute('start') || 1) + top.list.children.length - 1;
      else ctx.numCounters[key]++;
      // уровни ниже сбрасываются
      for (let k = lvl + 1; k < 9; k++) delete ctx.numCounters[P.numId + ':' + k];
    }
  }

  function inlines(container, state, ctx, para) {
    for (const c of container.children) {
      const n = c.localName;
      if (n === 'r') run(c, state, ctx, para);
      else if (n === 'hyperlink') {
        const id = ra(c, 'id'), anchor = wa(c, 'anchor');
        const href = id && ctx.rels[id] ? ctx.rels[id].target : (anchor ? '#' + anchor : null);
        if (href) {
          const a = document.createElement('a');
          a.href = href;
          const saved = state.cur;
          state.cur.append(a); state.cur = a;
          inlines(c, state, ctx, para);
          state.cur = saved;
          if (!a.textContent) a.remove();
        } else inlines(c, state, ctx, para);
      }
      else if (n === 'ins' || n === 'smartTag' || n === 'customXml' || n === 'fldSimple' || n === 'dir' || n === 'bdo') inlines(c, state, ctx, para);
      else if (n === 'sdt') { const sc = kid(c, 'sdtContent'); if (sc) inlines(sc, state, ctx, para); }
      else if (n === 'AlternateContent') { const f = kid(c, 'Choice') || kid(c, 'Fallback'); if (f) inlines(f, state, ctx, para); }
      else if (n === 'commentRangeStart') state.comments.add(wa(c, 'id'));
      else if (n === 'commentRangeEnd') state.comments.delete(wa(c, 'id'));
      else if (n === 'bookmarkStart') { const nm = wa(c, 'name'); if (nm && !nm.startsWith('_')) { const top = state.pieces[0]; if (!top.id) top.id = nm; } }
      else if (n === 'oMath' || n === 'oMathPara') {
        const t = deep(c, 't').map(x => x.textContent).join('');
        if (t) state.cur.append(h('span', { style: 'font-family:"Cambria Math",serif;font-style:italic', text: t }));
      }
    }
  }

  function append(state, node, cssText, ctx) {
    let target = state.cur;
    // примечание
    let cm = null;
    for (const id of state.comments) { cm = id; break; }
    const key = cssText + '|' + (cm || '');
    const last = target.lastChild;
    if (node.nodeType === 3 && last && last.nodeType === 1 && last.tagName === 'SPAN' && last.__key === key) { last.append(node); return; }
    if (node.nodeType === 3 && !cssText && !cm) {
      if (last && last.nodeType === 3) { last.data += node.data; return; }
      target.append(node); return;
    }
    if (!cssText && !cm) { target.append(node); return; }
    const span = document.createElement('span');
    if (cssText) span.setAttribute('style', cssText);
    if (cm) {
      const c = ctx.comments[cm] || {};
      span.className = 'dp-comment';
      span.dataset.id = 'c' + cm; span.dataset.text = c.text || ''; span.dataset.author = c.author || ''; span.dataset.date = c.date || '';
    }
    span.__key = key;
    span.append(node);
    target.append(span);
  }

  function run(r, state, ctx, para) {
    const rp = readRPr(kid(r, 'rPr'));
    const rs = rp.rStyle ? styleChain(ctx, rp.rStyle, 'r') : {};
    const o = Object.assign({}, rs, rp);
    if (o.vanish) return;
    let css = runCss(o, ctx, para);
    const wrapVert = node => {
      if (o.vert === 'superscript' || o.vert === 'subscript') { const e = document.createElement(o.vert === 'superscript' ? 'sup' : 'sub'); e.append(node); return e; }
      return node;
    };
    for (const c of r.children) {
      const n = c.localName;
      if (n === 'fldChar') {
        const t = wa(c, 'fldCharType');
        if (t === 'begin') state.field.push('instr');
        else if (t === 'separate') state.field[state.field.length - 1] = 'result';
        else if (t === 'end') state.field.pop();
        continue;
      }
      if (state.field.length && state.field[state.field.length - 1] === 'instr') continue;
      if (n === 't') { const txt = c.textContent; if (txt) append(state, wrapVert(document.createTextNode(txt)), css, ctx); }
      else if (n === 'tab' || n === 'ptab') append(state, document.createTextNode('\t'), css, ctx);
      else if (n === 'br' || n === 'cr') {
        const t = wa(c, 'type');
        if (t === 'page' || t === 'column') {
          // разрываем абзац
          const br = h('div', { class: t === 'page' ? 'page-break' : 'col-break' });
          const next = state.cur.closest ? state.pieces[0].cloneNode(false) : null;
          state.pieces.push(br);
          if (next) { next.removeAttribute('id'); state.pieces.push(next); state.cur = next; }
        } else state.cur.append(document.createElement('br'));
      }
      else if (n === 'noBreakHyphen') append(state, document.createTextNode('‑'), css, ctx);
      else if (n === 'softHyphen') append(state, document.createTextNode('­'), css, ctx);
      else if (n === 'sym') {
        const code = parseInt(wa(c, 'char'), 16);
        const font = wa(c, 'font') || '';
        let ch = String.fromCharCode(code >= 0xF000 ? code - 0xF000 : code);
        if (/symbol/i.test(font)) ch = SYMBOL_MAP[ch.charCodeAt(0)] || ch;
        else if (/wingdings/i.test(font)) ch = WINGDINGS[ch.charCodeAt(0)] || '•';
        append(state, document.createTextNode(ch), css, ctx);
      }
      else if (n === 'drawing' || n === 'pict' || n === 'object') { const img = image(c, ctx); if (img) state.cur.append(img); }
      else if (n === 'AlternateContent') {
        const ch = kid(c, 'Choice'), fb = kid(c, 'Fallback');
        const src = (ch && deep(ch, 'drawing')[0]) ? ch : fb;
        if (src) {
          const d = deep(src, 'drawing')[0] || deep(src, 'pict')[0];
          const img = d && image(d, ctx);
          if (img) state.cur.append(img);
          else { // текстовое поле — берём текст
            const txt = deep(src, 'txbxContent')[0];
            if (txt) state.cur.append(document.createTextNode(deep(txt, 'p').map(p => deep(p, 't').map(t => t.textContent).join('')).join('\n')));
          }
        }
      }
      else if (n === 'footnoteReference' || n === 'endnoteReference') {
        const id = (n === 'endnoteReference' ? 'e' : '') + wa(c, 'id');
        const fid = 'fn' + id.replace(/\W/g, '');
        ctx.fnList.push({ id: fid, text: ctx.footnotes[id] || '' });
        state.cur.append(h('sup', { class: 'fn', 'data-fn': fid, contenteditable: 'false', text: String(ctx.fnList.length) }));
      }
      else if (n === 'lastRenderedPageBreak') { /* игнорируем */ }
    }
  }

  function image(el, ctx) {
    const blip = deep(el, 'blip')[0];
    let rid = blip ? (ra(blip, 'embed') || ra(blip, 'link')) : null;
    if (!rid) { const im = deep(el, 'imagedata')[0]; if (im) rid = ra(im, 'id'); }
    if (!rid || !ctx.rels[rid]) return null;
    const path = ctx.resolve(ctx.rels[rid].target);
    const ext = (path.match(/\.(\w+)$/) || [])[1]?.toLowerCase();
    const mime = Fmt.MIME_BY_EXT[ext];
    const img = document.createElement('img');
    const extent = deep(el, 'extent')[0];
    if (extent) {
      const w = +extent.getAttribute('cx') / 9525;
      if (w) img.style.width = Math.round(w) + 'px';
    } else {
      const shape = deep(el, 'shape')[0];
      const m = shape && /width:([\d.]+)pt/.exec(shape.getAttribute('style') || '');
      if (m) img.style.width = Math.round(+m[1] / 0.75) + 'px';
    }
    const anchor = deep(el, 'anchor')[0];
    if (anchor && !deep(anchor, 'wrapNone')[0] && !deep(anchor, 'wrapTopAndBottom')[0]) {
      const al = deep(deep(anchor, 'positionH')[0], 'align')[0];
      const a = al ? al.textContent : 'left';
      img.className = a === 'right' ? 'float-right' : a === 'center' ? 'center' : 'float-left';
    } else if (anchor && deep(anchor, 'wrapTopAndBottom')[0]) img.className = 'center';
    img.alt = deep(el, 'docPr')[0]?.getAttribute('descr') || '';
    img.dataset.src = path;
    img.dataset.mime = mime || '';
    ctx.imgPromises = ctx.imgPromises || [];
    // данные подставляются асинхронно, read() дожидается их
    ctx.imgPromises.push(ctx.zip.bytes(path).then(b => {
      if (!b) return;
      if (mime && !/emf|wmf|tiff/.test(mime)) img.src = Fmt.bytesToDataUrl(b, mime);
      else { img.replaceWith(document.createTextNode(`[рисунок ${ext?.toUpperCase() || ''}]`)); }
    }).catch(() => {}));
    return img;
  }

  function table(tbl, ctx) {
    const t = document.createElement('table');
    const tp = kid(tbl, 'tblPr');
    const tstyle = wa(kid(tp, 'tblStyle'), 'val');
    let borders = false;
    const tb = kid(tp, 'tblBorders');
    if (tb) borders = [...tb.children].some(b => { const v = wa(b, 'val'); return v && v !== 'nil' && v !== 'none'; });
    else if (tstyle && ctx.styles[tstyle] && ctx.styles[tstyle].tblBorders) borders = true;
    else if (tstyle && /grid|сетка/i.test(tstyle)) borders = true;
    // проверка границ у ячеек
    if (!borders) borders = deep(tbl, 'tcBorders').some(b => [...b.children].some(x => { const v = wa(x, 'val'); return v && v !== 'nil' && v !== 'none'; }));
    t.dataset.borders = borders ? '1' : '0';
    const tw = kid(tp, 'tblW');
    if (tw) {
      const type = wa(tw, 'type'), w = +wa(tw, 'w');
      if (type === 'pct') t.style.width = (w > 100 ? w / 50 : w) + '%';
      else if (type === 'dxa' && w) t.style.width = Math.round(w / 15) + 'px';
    }
    const jc = wa(kid(tp, 'jc'), 'val');
    if (jc === 'center') { t.style.marginLeft = 'auto'; t.style.marginRight = 'auto'; }
    else if (jc === 'right' || jc === 'end') t.style.marginLeft = 'auto';
    const grid = kids(kid(tbl, 'tblGrid'), 'gridCol').map(g => +wa(g, 'w') || 0);
    const tbody = document.createElement('tbody');
    t.append(tbody);
    const vm = {}; // col -> cell (vMerge restart)
    for (const tr of kids(tbl, 'tr')) {
      const row = document.createElement('tr');
      const trh = kid(kid(tr, 'trPr'), 'trHeight');
      if (trh) row.style.height = Math.round(+wa(trh, 'val') / 15) + 'px';
      let col = 0;
      const gb = kid(kid(tr, 'trPr'), 'gridBefore');
      if (gb) col += +wa(gb, 'val');
      for (const tc of kids(tr, 'tc')) {
        const pr = kid(tc, 'tcPr');
        const span = +(wa(kid(pr, 'gridSpan'), 'val') || 1);
        const vmEl = kid(pr, 'vMerge');
        const vmVal = vmEl ? (wa(vmEl, 'val') || 'continue') : null;
        if (vmVal === 'continue' && vm[col]) { vm[col].rowSpan++; col += span; continue; }
        const td = document.createElement('td');
        if (span > 1) td.colSpan = span;
        if (vmVal === 'restart') vm[col] = td; else delete vm[col];
        const shd = wa(kid(pr, 'shd'), 'fill');
        if (shd && shd !== 'auto' && shd !== 'FFFFFF') td.style.backgroundColor = '#' + shd;
        const va = wa(kid(pr, 'vAlign'), 'val');
        if (va === 'center') td.style.verticalAlign = 'middle'; else if (va === 'bottom') td.style.verticalAlign = 'bottom';
        const w = kid(pr, 'tcW');
        if (w && wa(w, 'type') === 'dxa' && +wa(w, 'w')) td.style.width = Math.round(+wa(w, 'w') / 15) + 'px';
        else if (grid.length && grid[col]) { let s = 0; for (let k = 0; k < span; k++) s += grid[col + k] || 0; if (s) td.style.width = Math.round(s / 15) + 'px'; }
        convertBlocks(tc, td, ctx);
        // ячейка с одним пустым абзацем
        if (!td.childNodes.length) td.innerHTML = '<br>';
        row.append(td);
        col += span;
      }
      tbody.append(row);
    }
    return t;
  }

  async function readSection(sect, ctx) {
    const m = ctx.meta;
    const pg = kid(sect, 'pgSz');
    if (pg) {
      const w = +wa(pg, 'w'), hh = +wa(pg, 'h');
      if (w && hh) { m.pageW = +Fmt.twToMm(w).toFixed(1); m.pageH = +Fmt.twToMm(hh).toFixed(1); }
      m.orientation = wa(pg, 'orient') === 'landscape' || w > hh ? 'landscape' : 'portrait';
      if (m.orientation === 'landscape' && m.pageW < m.pageH) [m.pageW, m.pageH] = [m.pageH, m.pageW];
    }
    const mg = kid(sect, 'pgMar');
    if (mg) m.margins = { t: +Fmt.twToMm(Math.abs(+wa(mg, 'top') || 0)).toFixed(1), r: +Fmt.twToMm(+wa(mg, 'right') || 0).toFixed(1), b: +Fmt.twToMm(Math.abs(+wa(mg, 'bottom') || 0)).toFixed(1), l: +Fmt.twToMm(+wa(mg, 'left') || 0).toFixed(1) };
    const cols = kid(sect, 'cols');
    if (cols && +wa(cols, 'num') > 1) m.columns = +wa(cols, 'num');
    for (const [tagName, key] of [['headerReference', 'header'], ['footerReference', 'footer']]) {
      const ref = kids(sect, tagName).find(x => wa(x, 'type') === 'default') || kids(sect, tagName)[0];
      if (!ref) continue;
      const rel = ctx.rels[ra(ref, 'id')];
      if (!rel) continue;
      const x = await ctx.zip.text(ctx.resolve(rel.target));
      if (!x) continue;
      const xd = parse(x);
      const instr = deep(xd, 'instrText').map(i => i.textContent).join(' ') + ' ' + deep(xd, 'fldSimple').map(f => wa(f, 'instr')).join(' ');
      const lines = [];
      for (const p of deep(xd, 'p')) {
        let txt = '', inInstr = false, hasPage = false;
        for (const node of deep(p, '*')) {
          if (node.localName === 'fldChar') { const tt = wa(node, 'fldCharType'); if (tt === 'begin') inInstr = true; if (tt === 'separate' || tt === 'end') inInstr = false; }
          if (node.localName === 'instrText' && /PAGE/.test(node.textContent)) hasPage = true;
          if (node.localName === 't' && !inInstr) txt += node.textContent;
        }
        if (hasPage || deep(p, 'fldSimple').some(f => /PAGE/.test(wa(f, 'instr')))) {
          const jc = wa(deep(p, 'jc')[0], 'val') || 'center';
          m.pageNumbers = (key === 'header' ? 'top-' : 'bottom-') + (jc === 'right' || jc === 'end' ? 'right' : jc === 'left' || jc === 'start' ? 'left' : 'center');
          if (/NUMPAGES/.test(instr)) m.pageNumFormat = 'n of N';
          txt = txt.replace(/\d+/g, '').replace(/(Страница|Стр\.|Page|из|of)\s*/gi, '').trim();
        }
        if (txt.trim()) lines.push(txt);
      }
      m[key] = lines.join('\n');
    }
  }

  const SYMBOL_MAP = { 0x61: 'α', 0x62: 'β', 0x63: 'χ', 0x64: 'δ', 0x65: 'ε', 0x66: 'φ', 0x67: 'γ', 0x68: 'η', 0x69: 'ι', 0x6B: 'κ', 0x6C: 'λ', 0x6D: 'μ', 0x6E: 'ν', 0x6F: 'ο', 0x70: 'π', 0x71: 'θ', 0x72: 'ρ', 0x73: 'σ', 0x74: 'τ', 0x75: 'υ', 0x77: 'ω', 0x78: 'ξ', 0x79: 'ψ', 0x7A: 'ζ',
    0x44: 'Δ', 0x46: 'Φ', 0x47: 'Γ', 0x4C: 'Λ', 0x50: 'Π', 0x51: 'Θ', 0x53: 'Σ', 0x57: 'Ω', 0x58: 'Ξ', 0x59: 'Ψ', 0xA3: '≤', 0xB3: '≥', 0xB9: '≠', 0xBB: '≈', 0xB1: '±', 0xB4: '×', 0xB8: '÷', 0xA5: '∞', 0xD6: '√', 0xE5: '∑', 0xF2: '∫', 0xB7: '•', 0xAE: '→', 0xAC: '←', 0xAD: '↑', 0xAF: '↓', 0xDE: '⇒', 0xDB: '⇔', 0xB0: '°', 0xA2: '′', 0xB2: '″', 0xCE: '∈', 0xC7: '∩', 0xC8: '∪', 0xC6: '∅', 0xD1: '∇', 0xB6: '∂', 0x22: '∀', 0x24: '∃' };
  const WINGDINGS = { 0xFC: '✓', 0xFB: '✗', 0xFE: '☑', 0xFD: '☒', 0xA8: '☐', 0x6F: '☐', 0x6C: '●', 0x6E: '■', 0xA7: '▪', 0x76: '❖', 0xD8: '➢', 0xE0: '→', 0xE8: '➔', 0x4A: '☺', 0x4C: '☹', 0xF0: '⇨', 0x9F: '•', 0x71: '❑', 0x75: '◆' };

  // ===================== ЗАПИСЬ =====================
  const X = Fmt.xmlEsc;

  async function write(docEl, meta) {
    document.documentElement.classList.add('exporting');
    try { return await writeInner(docEl, meta); }
    finally { document.documentElement.classList.remove('exporting'); }
  }

  async function writeInner(docEl, meta) {
    const zoom = parseFloat(getComputedStyle(document.getElementById('page')).zoom) || 1;
    const W = {
      rels: [], media: [], nums: [], imgId: 1, bm: 1, comments: [], commentIds: new Map(), openComment: null, doneComments: new Set(),
      footnotes: [], zoom, defFont: meta.defaultFont, defSize: meta.defaultSize
    };
    const addRel = (type, target, ext) => {
      const id = 'rId' + (W.rels.length + 10);
      W.rels.push({ id, type, target, ext });
      return id;
    };
    W.addRel = addRel;
    const bodyParts = [];
    for (const n of docEl.childNodes) {
      if (n.nodeType === 1 && n.classList.contains('footnotes')) continue;
      bodyParts.push(...block(n, W, {}));
    }
    flushComment(W, bodyParts);
    // сноски
    const fnBox = docEl.querySelector('.footnotes');
    if (fnBox) fnBox.querySelectorAll('li').forEach(li => { const f = W.footnotes.find(x => x.key === li.id); if (f) f.text = li.textContent; });

    // колонтитулы
    let hdrRef = '', ftrRef = '';
    const files = [];
    const pn = meta.pageNumbers || 'none';
    const hfXml = (text, withNum, jcNum) => {
      let ps = (text || '').split('\n').filter((l, i, a) => l || a.length === 1).map(l => l ? `<w:p><w:pPr><w:pStyle w:val="Header"/><w:jc w:val="center"/></w:pPr><w:r><w:t xml:space="preserve">${X(l)}</w:t></w:r></w:p>` : '').join('');
      if (withNum) {
        const fld = f => `<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> ${f} </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>`;
        const body = meta.pageNumFormat === 'n of N' ? `<w:r><w:t xml:space="preserve">Страница </w:t></w:r>${fld('PAGE')}<w:r><w:t xml:space="preserve"> из </w:t></w:r>${fld('NUMPAGES')}` : fld('PAGE');
        ps += `<w:p><w:pPr><w:jc w:val="${jcNum}"/></w:pPr>${body}</w:p>`;
      }
      if (!ps) ps = '<w:p/>';
      return ps;
    };
    const jcNum = pn.endsWith('right') ? 'right' : pn.endsWith('left') ? 'left' : 'center';
    if (meta.header || pn.startsWith('top')) {
      files.push({ name: 'word/header1.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:hdr ${NSDECL}>${hfXml(meta.header, pn.startsWith('top'), jcNum)}</w:hdr>` });
      hdrRef = `<w:headerReference w:type="default" r:id="${addRel('header', 'header1.xml')}"/>`;
    }
    if (meta.footer || pn.startsWith('bottom')) {
      files.push({ name: 'word/footer1.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:ftr ${NSDECL}>${hfXml(meta.footer, pn.startsWith('bottom'), jcNum)}</w:ftr>` });
      ftrRef = `<w:footerReference w:type="default" r:id="${addRel('footer', 'footer1.xml')}"/>`;
    }

    const land = meta.orientation === 'landscape';
    let pw = Fmt.mmToTw(meta.pageW), ph = Fmt.mmToTw(meta.pageH);
    if (land && pw < ph) [pw, ph] = [ph, pw];
    const mg = meta.margins;
    const sect = `<w:sectPr>${hdrRef}${ftrRef}<w:pgSz w:w="${pw}" w:h="${ph}"${land ? ' w:orient="landscape"' : ''}/>` +
      `<w:pgMar w:top="${Fmt.mmToTw(mg.t)}" w:right="${Fmt.mmToTw(mg.r)}" w:bottom="${Fmt.mmToTw(mg.b)}" w:left="${Fmt.mmToTw(mg.l)}" w:header="567" w:footer="567" w:gutter="0"/>` +
      `<w:cols w:num="${meta.columns || 1}" w:space="708"/></w:sectPr>`;
    const docXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:document ${NSDECL}><w:body>${bodyParts.join('')}${sect}</w:body></w:document>`;

    // нумерация
    let numXml = '';
    if (W.nums.length) {
      numXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:numbering ${NSDECL}>` +
        W.nums.map((n, i) => `<w:abstractNum w:abstractNumId="${i}"><w:multiLevelType w:val="hybridMultilevel"/>${n.levels.map((L, lv) => levelXml(L, lv)).join('')}</w:abstractNum>`).join('') +
        W.nums.map((n, i) => `<w:num w:numId="${i + 1}"><w:abstractNumId w:val="${i}"/>${n.start && n.start !== 1 ? `<w:lvlOverride w:ilvl="0"><w:startOverride w:val="${n.start}"/></w:lvlOverride>` : ''}</w:num>`).join('') +
        '</w:numbering>';
      addRel('numbering', 'numbering.xml');
    }
    if (W.comments.length) {
      files.push({ name: 'word/comments.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:comments ${NSDECL}>` + W.comments.map(c =>
        `<w:comment w:id="${c.id}" w:author="${X(c.author || 'Автор')}" w:date="${X((c.date || new Date().toISOString()).replace(/\.\d+Z$/, 'Z'))}" w:initials="${X((c.author || 'A').slice(0, 2))}"><w:p><w:pPr><w:pStyle w:val="CommentText"/></w:pPr><w:r><w:t xml:space="preserve">${X(c.text || '')}</w:t></w:r></w:p></w:comment>`).join('') + '</w:comments>' });
      addRel('comments', 'comments.xml');
    }
    if (W.footnotes.length) {
      files.push({ name: 'word/footnotes.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:footnotes ${NSDECL}>` +
        '<w:footnote w:type="separator" w:id="-1"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:separator/></w:r></w:p></w:footnote>' +
        '<w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>' +
        W.footnotes.map(f => `<w:footnote w:id="${f.id}"><w:p><w:pPr><w:pStyle w:val="FootnoteText"/></w:pPr><w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr><w:footnoteRef/></w:r><w:r><w:t xml:space="preserve"> ${X(f.text || '')}</w:t></w:r></w:p></w:footnote>`).join('') +
        '</w:footnotes>' });
      addRel('footnotes', 'footnotes.xml');
    }
    addRel('styles', 'styles.xml');
    addRel('settings', 'settings.xml');

    const T = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/';
    const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
      W.rels.map(r => `<Relationship Id="${r.id}" Type="${T}${r.type}" Target="${X(r.target)}"${r.ext ? ' TargetMode="External"' : ''}/>`).join('') + '</Relationships>';

    const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
    const author = X(Store.S().author || 'DocPad');
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
      '<Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/><Default Extension="bmp" ContentType="image/bmp"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
      '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
      '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>' +
      (numXml ? '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>' : '') +
      (files.some(f => f.name === 'word/header1.xml') ? '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' : '') +
      (files.some(f => f.name === 'word/footer1.xml') ? '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' : '') +
      (W.comments.length ? '<Override PartName="/word/comments.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"/>' : '') +
      (W.footnotes.length ? '<Override PartName="/word/footnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"/>' : '') +
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' +
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';

    const zipFiles = [
      { name: '[Content_Types].xml', data: ct },
      { name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>' },
      { name: 'docProps/core.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${X(meta.title || '')}</dc:title><dc:creator>${author}</dc:creator><cp:lastModifiedBy>${author}</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${meta.created || now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>` },
      { name: 'docProps/app.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>DocPad</Application></Properties>' },
      { name: 'word/document.xml', data: docXml },
      { name: 'word/_rels/document.xml.rels', data: relsXml },
      { name: 'word/styles.xml', data: stylesXml(meta) },
      { name: 'word/settings.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:settings ${NSDECL}><w:defaultTabStop w:val="709"/><w:characterSpacingControl w:val="doNotCompress"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>` }
    ];
    if (numXml) zipFiles.push({ name: 'word/numbering.xml', data: numXml });
    zipFiles.push(...files);
    W.media.forEach(m => zipFiles.push({ name: 'word/media/' + m.name, data: m.bytes, store: true }));
    return Zip.write(zipFiles);
  }

  const NSDECL = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"';

  const BULLETS = ['•', '◦', '▪', '•', '◦', '▪', '•', '◦', '▪'];
  const FMT = { decimal: 'decimal', 'lower-alpha': 'lowerLetter', 'lower-latin': 'lowerLetter', 'upper-alpha': 'upperLetter', 'upper-latin': 'upperLetter',
    'lower-roman': 'lowerRoman', 'upper-roman': 'upperRoman', 'decimal-leading-zero': 'decimalZero', 'cyr-lower': 'russianLower', 'cyr-upper': 'russianUpper' };
  function levelXml(L, lv) {
    const left = 720 * (lv + 1);
    if (L.bullet) {
      const str = /^["'](.+?)\s*["']$/.exec(L.type || '');
      const ch = str ? X(str[1].trim() || '•') : L.type === 'circle' ? '◦' : L.type === 'square' ? '▪' : BULLETS[lv];
      return `<w:lvl w:ilvl="${lv}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="${ch}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${left}" w:hanging="360"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:hint="default"/></w:rPr></w:lvl>`;
    }
    return `<w:lvl w:ilvl="${lv}"><w:start w:val="${L.start || 1}"/><w:numFmt w:val="${FMT[L.type] || 'decimal'}"/><w:lvlText w:val="%${lv + 1}."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${left}" w:hanging="360"/></w:pPr></w:lvl>`;
  }

  // ---- блоки ----
  const isBlockTag = t => /^(P|H[1-6]|DIV|UL|OL|LI|TABLE|BLOCKQUOTE|PRE|HR|SECTION|ARTICLE|HEADER|FOOTER|ASIDE|NAV|FIGURE|DL|DT|DD|ADDRESS|MAIN)$/.test(t);

  function block(n, W, ctx) {
    if (n.nodeType === 3) return n.data.trim() ? [para(null, [n], W, ctx)] : [];
    if (n.nodeType !== 1) return [];
    const t = n.tagName;
    if (n.classList.contains('page-break')) return ['<w:p><w:r><w:br w:type="page"/></w:r></w:p>'];
    if (n.classList.contains('col-break')) return ['<w:p><w:r><w:br w:type="column"/></w:r></w:p>'];
    if (n.classList.contains('toc')) return tocXml(n, W);
    if (t === 'HR') return ['<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="auto"/></w:pBdr></w:pPr></w:p>'];
    if (t === 'TABLE') return [tableXml(n, W, ctx)];
    if (t === 'UL' || t === 'OL') return listXml(n, W, ctx, 0, null);
    if (t === 'BLOCKQUOTE') return containerXml(n, W, Object.assign({}, ctx, { style: 'Quote' }));
    if (/^(DIV|SECTION|ARTICLE|HEADER|FOOTER|ASIDE|NAV|FIGURE|MAIN|ADDRESS)$/.test(t) && [...n.childNodes].some(c => c.nodeType === 1 && isBlockTag(c.tagName))) return containerXml(n, W, ctx);
    if (t === 'IMG') return [para(n, [n], W, ctx)];
    return [para(n, [...n.childNodes], W, ctx)];
  }
  function containerXml(n, W, ctx) {
    const out = [];
    let inl = [];
    const flush = () => { if (inl.some(x => x.nodeType === 1 || x.data.trim())) out.push(para(n, inl, W, ctx)); inl = []; };
    for (const c of n.childNodes) {
      if (c.nodeType === 1 && (isBlockTag(c.tagName) || c.classList.contains('page-break'))) { flush(); out.push(...block(c, W, ctx)); }
      else inl.push(c);
    }
    flush();
    return out;
  }

  function listXml(list, W, ctx, level, numIdx) {
    const out = [];
    if (numIdx == null) {
      // новая нумерация для каждого корневого списка
      const levels = [];
      const collect = (l, lv) => {
        if (lv > 8) return;
        if (!levels[lv]) {
          const type = getComputedStyle(l).listStyleType;
          levels[lv] = { bullet: l.tagName === 'UL', type, start: +l.getAttribute('start') || 1 };
        }
        l.querySelectorAll(':scope > li > ul, :scope > li > ol').forEach(s => collect(s, lv + 1));
      };
      collect(list, 0);
      for (let i = 0; i < 9; i++) if (!levels[i]) levels[i] = { bullet: list.tagName === 'UL', type: list.tagName === 'UL' ? 'disc' : 'decimal', start: 1 };
      W.nums.push({ levels });
      numIdx = W.nums.length;
    }
    const check = list.classList.contains('checklist');
    for (const li of list.children) {
      if (li.tagName !== 'LI') { out.push(...block(li, W, ctx)); continue; }
      const inl = [], nested = [];
      for (const c of li.childNodes) {
        if (c.nodeType === 1 && (c.tagName === 'UL' || c.tagName === 'OL')) nested.push(c);
        else inl.push(c);
      }
      // если внутри li абзацы
      const blocksInside = inl.filter(c => c.nodeType === 1 && isBlockTag(c.tagName));
      const lctx = Object.assign({}, ctx, check ? { prefix: li.dataset.checked === '1' ? '☑ ' : '☐ ' } : { num: { id: numIdx, lvl: level } }, { style: 'ListParagraph' });
      if (blocksInside.length) {
        let first = true;
        for (const c of inl) {
          if (c.nodeType === 1 && isBlockTag(c.tagName)) { out.push(...block(c, W, first ? lctx : Object.assign({}, ctx, { indentLvl: level }))); first = false; }
        }
      } else out.push(para(li, inl, W, lctx));
      for (const nl of nested) out.push(...listXml(nl, W, ctx, level + 1, check ? null : numIdx));
    }
    return out;
  }

  function tocXml(n, W) {
    const out = [];
    const title = n.querySelector('.toc-title');
    if (title) out.push(`<w:p><w:pPr><w:pStyle w:val="TOCHeading"/></w:pPr><w:r><w:t>${X(title.textContent)}</w:t></w:r></w:p>`);
    n.querySelectorAll('a').forEach(a => {
      const lvl = +((a.parentElement.className.match(/l(\d)/) || [])[1] || 1);
      const anchor = bmName((a.getAttribute('href') || '').slice(1));
      const t = a.querySelector('.t')?.textContent || a.textContent;
      const pg = a.querySelector('.n')?.textContent || '';
      out.push(`<w:p><w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9350"/></w:tabs><w:spacing w:after="60"/><w:ind w:left="${(lvl - 1) * 240}"/></w:pPr><w:hyperlink w:anchor="${anchor}"><w:r><w:t xml:space="preserve">${X(t)}</w:t></w:r><w:r><w:tab/></w:r><w:r><w:t>${X(pg)}</w:t></w:r></w:hyperlink></w:p>`);
    });
    return out;
  }
  const bmName = id => ('b_' + id).replace(/[^\w]/g, '_').slice(0, 40);

  function paraProps(el, W, ctx) {
    const pr = [];
    let style = ctx.style || null;
    if (el && el.nodeType === 1) {
      const t = el.tagName;
      if (/^H[1-6]$/.test(t)) style = 'Heading' + t[1];
      else if (t === 'PRE') style = 'Code';
      else if (el.classList.contains('title')) style = 'Title';
      else if (el.classList.contains('subtitle')) style = 'Subtitle';
      else if (el.classList.contains('no-spacing')) style = 'NoSpacing';
    }
    if (style) pr.push(`<w:pStyle w:val="${style}"/>`);
    if (ctx.num) pr.push(`<w:numPr><w:ilvl w:val="${ctx.num.lvl}"/><w:numId w:val="${ctx.num.id}"/></w:numPr>`);
    if (el && el.nodeType === 1 && el.tagName !== 'IMG') {
      const cs = getComputedStyle(el);
      const fs = parseFloat(cs.fontSize) || 16;
      const isCell = /^(TD|TH)$/.test(el.tagName);
      const mt = isCell ? 0 : parseFloat(cs.marginTop) || 0, mb = isCell ? 0 : parseFloat(cs.marginBottom) || 0;
      let line = '';
      if (cs.lineHeight !== 'normal') {
        const lh = parseFloat(cs.lineHeight);
        const inline = el.style.lineHeight;
        if (/pt$/.test(inline)) line = ` w:line="${Math.round(parseFloat(inline) * 20)}" w:lineRule="exact"`;
        else line = ` w:line="${Math.round(lh / fs / Fmt.LH * 240)}" w:lineRule="auto"`;
      }
      pr.push(`<w:spacing w:before="${Fmt.pxToTw(mt)}" w:after="${Fmt.pxToTw(mb)}"${line}/>`);
      if (!ctx.num) {
        const ml = isCell ? 0 : parseFloat(cs.marginLeft) || 0, mr = isCell ? 0 : parseFloat(cs.marginRight) || 0, ti = parseFloat(cs.textIndent) || 0;
        const indLvl = ctx.indentLvl != null ? 720 * (ctx.indentLvl + 1) : 0;
        if (ml || mr || ti || indLvl) pr.push(`<w:ind w:left="${Fmt.pxToTw(ml) + indLvl}" w:right="${Fmt.pxToTw(mr)}"${ti > 0 ? ` w:firstLine="${Fmt.pxToTw(ti)}"` : ti < 0 ? ` w:hanging="${Fmt.pxToTw(-ti)}"` : ''}/>`);
      }
      const al = cs.textAlign;
      let jc = al === 'center' ? 'center' : (al === 'right' || al === 'end') ? 'right' : al === 'justify' ? 'both' : null;
      if (!jc && el.querySelector(':scope > img.center') && !el.textContent.trim()) jc = 'center';
      if (jc) pr.push(`<w:jc w:val="${jc}"/>`);
      if (el.getAttribute('dir') === 'rtl') pr.push('<w:bidi/>');
      const bg = isCell ? null : Fmt.toHex(cs.backgroundColor);
      if (bg && el.tagName !== 'LI') pr.push(`<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>`);
    }
    return pr.length ? `<w:pPr>${order(pr)}</w:pPr>` : '';
  }
  // порядок элементов pPr по схеме
  function order(pr) {
    const rank = s => ['pStyle', 'numPr', 'shd', 'tabs', 'spacing', 'ind', 'jc', 'bidi'].findIndex(k => s.startsWith('<w:' + k));
    const r = pr.slice().sort((a, b) => rank(a) - rank(b));
    // bidi должен идти до spacing по схеме
    const bi = r.findIndex(x => x.startsWith('<w:bidi'));
    if (bi >= 0) { const [b] = r.splice(bi, 1); const sp = r.findIndex(x => x.startsWith('<w:spacing')); r.splice(sp >= 0 ? sp : r.length, 0, b); }
    return r.join('');
  }

  function para(el, nodes, W, ctx) {
    const runs = [];
    let bm = '';
    if (el && el.id && /^H[1-6]$/.test(el.tagName)) {
      const id = W.bm++;
      bm = `<w:bookmarkStart w:id="${id}" w:name="${bmName(el.id)}"/>`;
      runs.push(bm);
      runs.end = `<w:bookmarkEnd w:id="${id}"/>`;
    }
    if (ctx.prefix) runs.push(`<w:r><w:t xml:space="preserve">${X(ctx.prefix)}</w:t></w:r>`);
    for (const n of nodes) inline(n, W, runs, null);
    if (runs.end) runs.push(runs.end);
    return `<w:p>${paraProps(el, W, ctx)}${runs.join('')}</w:p>`;
  }

  function commentOf(node) {
    const e = node.nodeType === 1 ? node : node.parentElement;
    const c = e && e.closest('.dp-comment');
    return c ? c : null;
  }
  function flushComment(W, out) {
    if (!W.openComment) return;
    const id = W.openComment;
    out.push(`<w:commentRangeEnd w:id="${id}"/><w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="${id}"/></w:r>`);
    W.openComment = null;
  }
  function handleComment(node, W, out) {
    const c = commentOf(node);
    const key = c ? c.dataset.id : null;
    const curKey = W.openComment != null ? W.openCommentKey : null;
    if (key === curKey) return;
    if (W.openComment != null) flushComment(W, out);
    if (key && !W.doneComments.has(key)) {
      const id = W.comments.length;
      W.comments.push({ id, text: c.dataset.text, author: c.dataset.author, date: c.dataset.date });
      W.doneComments.add(key);
      W.openComment = id; W.openCommentKey = key;
      out.push(`<w:commentRangeStart w:id="${id}"/>`);
    }
  }

  function inline(n, W, out, link) {
    if (n.nodeType === 3) {
      const text = n.data.replace(/​/g, '');
      if (!text) return;
      handleComment(n, W, out);
      const rPr = runProps(n.parentElement, W, link);
      const parts = text.split(/(\t|\n)/);
      let body = '';
      for (const p of parts) {
        if (p === '\t') body += '<w:tab/>';
        else if (p === '\n') body += '<w:br/>';
        else if (p) body += `<w:t xml:space="preserve">${X(p)}</w:t>`;
      }
      out.push(`<w:r>${rPr}${body}</w:r>`);
      return;
    }
    if (n.nodeType !== 1) return;
    const t = n.tagName;
    if (t === 'BR') { if (!Fmt.trailingBr(n)) out.push('<w:r><w:br/></w:r>'); return; }
    if (t === 'IMG') { const x = imageXml(n, W); if (x) out.push(x); return; }
    if (t === 'SUP' && n.classList.contains('fn')) {
      const id = W.footnotes.length + 1;
      W.footnotes.push({ id, key: n.dataset.fn, text: '' });
      out.push(`<w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr><w:footnoteReference w:id="${id}"/></w:r>`);
      return;
    }
    if (t === 'A' && n.getAttribute('href')) {
      const href = n.getAttribute('href');
      const inner = [];
      for (const c of n.childNodes) inline(c, W, inner, true);
      if (href.startsWith('#')) out.push(`<w:hyperlink w:anchor="${bmName(href.slice(1))}">${inner.join('')}</w:hyperlink>`);
      else out.push(`<w:hyperlink r:id="${W.addRel('hyperlink', href, true)}">${inner.join('')}</w:hyperlink>`);
      return;
    }
    if (t === 'TABLE' || t === 'UL' || t === 'OL') {
      // таблица/список внутри абзаца — выводим как текст
      out.push(`<w:r><w:t xml:space="preserve">${X(n.innerText)}</w:t></w:r>`);
      return;
    }
    for (const c of n.childNodes) inline(c, W, out, link);
  }

  const GENERIC = { 'sans-serif': 'Arial', serif: 'Times New Roman', monospace: 'Courier New', cursive: 'Comic Sans MS', 'system-ui': 'Arial',
    'sans-serif-light': 'Arial', 'sans-serif-medium': 'Arial', 'sans-serif-condensed': 'Arial Narrow', 'sans-serif-black': 'Arial Black', 'sans-serif-thin': 'Arial',
    'sans-serif-smallcaps': 'Arial', casual: 'Comic Sans MS', 'serif-monospace': 'Courier New' };
  function runProps(el, W, link) {
    const cs = getComputedStyle(el);
    const p = [];
    if (link) p.push('<w:rStyle w:val="Hyperlink"/>');
    let font = Fonts.first(cs.fontFamily);
    font = GENERIC[font] || font;
    if (font && font !== W.defFont) p.push(`<w:rFonts w:ascii="${X(font)}" w:hAnsi="${X(font)}" w:cs="${X(font)}" w:eastAsia="${X(font)}"/>`);
    const wgt = parseInt(cs.fontWeight) || 400;
    if (wgt >= 600) p.push('<w:b/><w:bCs/>');
    if (cs.fontStyle === 'italic' || cs.fontStyle === 'oblique') p.push('<w:i/><w:iCs/>');
    if (cs.textTransform === 'uppercase') p.push('<w:caps/>');
    if (cs.fontVariantCaps === 'small-caps' || cs.fontVariant === 'small-caps') p.push('<w:smallCaps/>');
    // оформление текста наследуется визуально — ищем у предков
    let u = null, strike = false, dstrike = false, vert = null, bg = null;
    let e = el;
    while (e && e.id !== 'doc') {
      const ecs = e === el ? cs : getComputedStyle(e);
      const line = ecs.textDecorationLine || '';
      if (/underline/.test(line) && !u) {
        const st = ecs.textDecorationStyle;
        u = { style: st === 'double' ? 'double' : st === 'wavy' ? 'wave' : st === 'dotted' ? 'dotted' : st === 'dashed' ? 'dash' : 'single', color: Fmt.toHex(ecs.textDecorationColor) };
      }
      if (/line-through/.test(line)) { if (ecs.textDecorationStyle === 'double') dstrike = true; else strike = true; }
      if (!vert && (e.tagName === 'SUP' || ecs.verticalAlign === 'super')) vert = 'superscript';
      if (!vert && (e.tagName === 'SUB' || ecs.verticalAlign === 'sub')) vert = 'subscript';
      if (!bg && !/^(P|H[1-6]|LI|TD|TH|BLOCKQUOTE|PRE|DIV|TABLE|TR|TBODY|UL|OL)$/.test(e.tagName)) bg = Fmt.toHex(ecs.backgroundColor);
      if (/^(P|H[1-6]|LI|TD|TH|BLOCKQUOTE|PRE)$/.test(e.tagName)) break;
      e = e.parentElement;
    }
    if (dstrike) p.push('<w:dstrike/>'); else if (strike) p.push('<w:strike/>');
    const col = Fmt.toHex(cs.color);
    if (col && col !== '000000' && !link) p.push(`<w:color w:val="${col}"/>`);
    else if (link) p.push('<w:color w:val="0563C1"/>');
    const spc = parseFloat(cs.letterSpacing);
    if (spc) p.push(`<w:spacing w:val="${Math.round(spc * 15)}"/>`);
    const sz = Math.round(parseFloat(cs.fontSize) * 0.75 * 2);
    const realSz = vert ? Math.round(parseFloat(getComputedStyle(el.closest('p,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,pre') || el).fontSize) * 0.75 * 2) : sz;
    if (realSz && realSz !== W.defSize * 2) p.push(`<w:sz w:val="${realSz}"/><w:szCs w:val="${realSz}"/>`);
    if (bg) p.push(`<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>`);
    if (u || link) p.push(`<w:u w:val="${u ? u.style : 'single'}"${u && u.color && u.color !== col ? ` w:color="${u.color}"` : ''}/>`);
    if (vert) p.push(`<w:vertAlign w:val="${vert}"/>`);
    return p.length ? `<w:rPr>${rOrder(p)}</w:rPr>` : '';
  }
  function rOrder(p) {
    const ORDER = ['rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps', 'strike', 'dstrike', 'color', 'spacing', 'sz', 'szCs', 'highlight', 'u', 'shd', 'vertAlign'];
    const key = s => { const m = s.match(/^<w:(\w+)/); return m ? m[1] : ''; };
    const parts = [];
    p.forEach(s => s.split(/(?=<w:)/).forEach(x => x && parts.push(x)));
    return parts.sort((a, b) => ORDER.indexOf(key(a)) - ORDER.indexOf(key(b))).join('');
  }

  function imageXml(img, W) {
    let data = img.src && img.src.startsWith('data:') ? Fmt.dataUrlToBytes(img.src) : null;
    let ext = data ? Fmt.EXT_BY_MIME[data.mime] : null;
    if (!data || !ext) {
      try {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth || 1; c.height = img.naturalHeight || 1;
        c.getContext('2d').drawImage(img, 0, 0);
        data = Fmt.dataUrlToBytes(c.toDataURL('image/png'));
        ext = 'png';
      } catch (e) { return null; }
    }
    const name = `image${W.imgId}.${ext}`;
    const docPrId = W.imgId++;
    W.media.push({ name, bytes: data.bytes });
    const rid = W.addRel('image', 'media/' + name);
    const [wpx, hpx] = Fmt.imageSize(img);
    const cx = Fmt.pxToEmu(wpx), cy = Fmt.pxToEmu(hpx);
    const graphic = `<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${docPrId}" name="${name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>`;
    const docPr = `<wp:docPr id="${docPrId}" name="Рисунок ${docPrId}"${img.alt ? ` descr="${X(img.alt)}"` : ''}/>`;
    const fl = img.classList.contains('float-left') ? 'left' : img.classList.contains('float-right') ? 'right' : null;
    if (fl) {
      return `<w:r><w:drawing><wp:anchor distT="0" distB="0" distL="114300" distR="114300" simplePos="0" relativeHeight="${251658240 + docPrId}" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="column"><wp:align>${fl}</wp:align></wp:positionH><wp:positionV relativeFrom="paragraph"><wp:posOffset>0</wp:posOffset></wp:positionV><wp:extent cx="${cx}" cy="${cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapSquare wrapText="bothSides"/>${docPr}<wp:cNvGraphicFramePr/>${graphic}</wp:anchor></w:drawing></w:r>`;
    }
    return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/>${docPr}<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>${graphic}</wp:inline></w:drawing></w:r>`;
  }

  function tableXml(t, W, ctx) {
    const rows = [...t.rows];
    if (!rows.length) return '';
    // сетка
    const G = [];
    rows.forEach((tr, r) => {
      G[r] = G[r] || [];
      let c = 0;
      for (const td of tr.cells) {
        while (G[r][c]) c++;
        for (let i = 0; i < (td.rowSpan || 1); i++) for (let j = 0; j < (td.colSpan || 1); j++) { G[r + i] = G[r + i] || []; G[r + i][c + j] = td; }
        c += td.colSpan || 1;
      }
    });
    const ncol = Math.max(...G.map(r => r.length));
    // ширины колонок: пропорции с экрана, масштаб — по ширине таблицы на бумаге
    const raw = new Array(ncol).fill(0);
    for (let r = 0; r < G.length; r++) for (let c = 0; c < ncol; c++) {
      const td = G[r][c];
      if (td && (td.colSpan || 1) === 1 && !raw[c]) raw[c] = td.getBoundingClientRect().width;
    }
    const screenW = t.getBoundingClientRect().width || 1;
    const known = raw.reduce((a, b) => a + b, 0);
    const unknown = raw.filter(x => !x).length;
    for (let c = 0; c < ncol; c++) if (!raw[c]) raw[c] = Math.max(20, (screenW - known) / Math.max(1, unknown));
    const tw = Fmt.pxToTw(Fmt.paperWidth(t)) || 9000;
    const sum = raw.reduce((a, b) => a + b, 0) || 1;
    const widths = raw.map(x => Math.max(200, Math.round(x / sum * tw)));
    const borders = t.dataset.borders !== '0';
    const cs = getComputedStyle(t);
    const jc = cs.marginLeft !== '0px' && cs.marginRight !== '0px' && t.style.marginLeft === 'auto' ? (t.style.marginRight === 'auto' ? 'center' : 'right') : null;
    const b = v => `<w:top w:val="${v}" w:sz="4" w:space="0" w:color="auto"/><w:left w:val="${v}" w:sz="4" w:space="0" w:color="auto"/><w:bottom w:val="${v}" w:sz="4" w:space="0" w:color="auto"/><w:right w:val="${v}" w:sz="4" w:space="0" w:color="auto"/><w:insideH w:val="${v}" w:sz="4" w:space="0" w:color="auto"/><w:insideV w:val="${v}" w:sz="4" w:space="0" w:color="auto"/>`;
    let x = `<w:tbl><w:tblPr><w:tblStyle w:val="${borders ? 'TableGrid' : 'TableNormal'}"/><w:tblW w:w="${widths.reduce((a, b) => a + b, 0)}" w:type="dxa"/>${jc ? `<w:jc w:val="${jc}"/>` : ''}<w:tblBorders>${b(borders ? 'single' : 'nil')}</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="85" w:type="dxa"/><w:right w:w="85" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>`;
    x += '<w:tblGrid>' + widths.map(w => `<w:gridCol w:w="${w}"/>`).join('') + '</w:tblGrid>';
    for (let r = 0; r < G.length; r++) {
      const tr = rows[r];
      const isHead = tr && [...tr.cells].every(c => c.tagName === 'TH');
      x += `<w:tr>${isHead && r === 0 ? '<w:trPr><w:tblHeader/></w:trPr>' : ''}`;
      for (let c = 0; c < ncol;) {
        const td = G[r][c];
        if (!td) { x += `<w:tc><w:tcPr><w:tcW w:w="${widths[c]}" w:type="dxa"/></w:tcPr><w:p/></w:tc>`; c++; continue; }
        const span = td.colSpan || 1;
        const startRow = G.findIndex(row => row.includes(td));
        const w = widths.slice(c, c + span).reduce((a, b) => a + b, 0);
        const tcs = getComputedStyle(td);
        const fill = Fmt.toHex(tcs.backgroundColor);
        const va = tcs.verticalAlign === 'middle' ? 'center' : tcs.verticalAlign === 'bottom' ? 'bottom' : null;
        let pr = `<w:tcW w:w="${w}" w:type="dxa"/>${span > 1 ? `<w:gridSpan w:val="${span}"/>` : ''}`;
        if ((td.rowSpan || 1) > 1 || startRow !== r) pr += startRow === r ? '<w:vMerge w:val="restart"/>' : '<w:vMerge/>';
        if (fill) pr += `<w:shd w:val="clear" w:color="auto" w:fill="${fill}"/>`;
        if (va) pr += `<w:vAlign w:val="${va}"/>`;
        let content = '';
        if (startRow === r) {
          const parts = containerXml(td, W, Object.assign({}, ctx, { style: null, num: null }));
          content = parts.join('');
          if (!content.endsWith('</w:p>') && !content.endsWith('<w:p/>')) content += '<w:p/>';
        } else content = '<w:p/>';
        x += `<w:tc><w:tcPr>${pr}</w:tcPr>${content || '<w:p/>'}</w:tc>`;
        c += span;
      }
      x += '</w:tr>';
    }
    return x + '</w:tbl>';
  }

  function stylesXml(meta) {
    const f = X(meta.defaultFont || 'Times New Roman');
    const sz = Math.round((meta.defaultSize || 12) * 2);
    const after = Math.round((meta.defaultAfter ?? 8) * 20);
    const line = Math.round((meta.defaultLine || 1.15) * 240);
    const ind = meta.defaultIndent ? `<w:ind w:firstLine="${Fmt.mmToTw(meta.defaultIndent * 10)}"/>` : '';
    const lang = meta.lang === 'uk' ? 'uk-UA' : meta.lang === 'en' ? 'en-US' : 'ru-RU';
    const H = (n, size, extra = '') => `<w:style w:type="paragraph" w:styleId="Heading${n}"><w:name w:val="heading ${n}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="240" w:after="120"/><w:ind w:firstLine="0"/><w:outlineLvl w:val="${n - 1}"/></w:pPr><w:rPr><w:b/><w:bCs/>${extra}<w:color w:val="1F3864"/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr></w:style>`;
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:styles ${NSDECL}>` +
      `<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="${f}" w:hAnsi="${f}" w:cs="${f}" w:eastAsia="${f}"/><w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/><w:lang w:val="${lang}" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>` +
      `<w:pPrDefault><w:pPr><w:spacing w:after="${after}" w:line="${line}" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
      `<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/>${ind ? `<w:pPr>${ind}</w:pPr>` : ''}</w:style>` +
      H(1, 40) + H(2, 32) + H(3, 28) + H(4, 24, '<w:i/><w:iCs/>') + H(5, 22) + H(6, 22, '<w:i/><w:iCs/>') +
      `<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="120" w:line="240" w:lineRule="auto"/><w:ind w:firstLine="0"/></w:pPr><w:rPr><w:sz w:val="56"/><w:szCs w:val="56"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:firstLine="0"/></w:pPr><w:rPr><w:color w:val="5A5A5A"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="480" w:right="480" w:firstLine="0"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="404040"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F5F5F5"/><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:firstLine="0"/></w:pPr><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New" w:cs="Courier New"/><w:sz w:val="20"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="NoSpacing"><w:name w:val="No Spacing"/><w:qFormat/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="720" w:firstLine="0"/><w:contextualSpacing/></w:pPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Header"><w:name w:val="header"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:firstLine="0"/></w:pPr><w:rPr><w:sz w:val="20"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="TOCHeading"><w:name w:val="TOC Heading"/><w:basedOn w:val="Heading1"/><w:next w:val="Normal"/><w:qFormat/></w:style>` +
      `<w:style w:type="paragraph" w:styleId="FootnoteText"><w:name w:val="footnote text"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:firstLine="0"/></w:pPr><w:rPr><w:sz w:val="20"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="CommentText"><w:name w:val="annotation text"/><w:basedOn w:val="Normal"/><w:rPr><w:sz w:val="20"/></w:rPr></w:style>` +
      `<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/></w:style>` +
      `<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>` +
      `<w:style w:type="character" w:styleId="FootnoteReference"><w:name w:val="footnote reference"/><w:rPr><w:vertAlign w:val="superscript"/></w:rPr></w:style>` +
      `<w:style w:type="character" w:styleId="CommentReference"><w:name w:val="annotation reference"/><w:rPr><w:sz w:val="16"/></w:rPr></w:style>` +
      `<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>` +
      `<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tblBorders></w:tblPr></w:style>` +
      '</w:styles>';
  }

  /** Дождаться загрузки всех рисунков после read() */
  async function settle() { await new Promise(r => setTimeout(r, 0)); }

  return { read, write, settle };
})();
