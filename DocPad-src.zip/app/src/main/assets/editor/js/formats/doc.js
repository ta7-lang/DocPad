/* Чтение старых документов Word 97–2003 (.doc): извлечение текста, абзацев и таблиц.
   Форматирование символов в бинарном формате не восстанавливается. */
'use strict';
const Doc97 = (() => {
  function cfb(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const secShift = dv.getUint16(0x1E, true), miniShift = dv.getUint16(0x20, true);
    const SS = 1 << secShift, MS = 1 << miniShift;
    const nFat = dv.getUint32(0x2C, true), dirStart = dv.getUint32(0x30, true), cutoff = dv.getUint32(0x38, true);
    const miniFatStart = dv.getUint32(0x3C, true), difatStart = dv.getUint32(0x44, true);
    const off = s => (s + 1) * SS;
    const difat = [];
    for (let i = 0; i < 109; i++) { const s = dv.getUint32(0x4C + i * 4, true); if (s < 0xFFFFFFFA) difat.push(s); }
    let ds = difatStart, guard = 0;
    while (ds < 0xFFFFFFFA && guard++ < 10000) {
      const per = SS / 4 - 1;
      for (let i = 0; i < per; i++) { const s = dv.getUint32(off(ds) + i * 4, true); if (s < 0xFFFFFFFA) difat.push(s); }
      ds = dv.getUint32(off(ds) + per * 4, true);
    }
    const fat = [];
    for (const s of difat.slice(0, nFat || difat.length)) for (let i = 0; i < SS / 4; i++) fat.push(dv.getUint32(off(s) + i * 4, true));
    const chain = (start, table) => { const out = []; let s = start, g = 0; while (s < 0xFFFFFFFA && g++ < 1e6) { out.push(s); s = table[s]; } return out; };
    const readBig = (start, size) => {
      const secs = chain(start, fat);
      const out = new Uint8Array(secs.length * SS);
      secs.forEach((s, i) => out.set(u8.subarray(off(s), off(s) + SS), i * SS));
      return out.subarray(0, size);
    };
    const dir = readBig(dirStart, chain(dirStart, fat).length * SS);
    const entries = [];
    for (let p = 0; p + 128 <= dir.length; p += 128) {
      const nl = dir[p + 0x40] | (dir[p + 0x41] << 8);
      const name = new TextDecoder('utf-16le').decode(dir.subarray(p, p + Math.max(0, nl - 2)));
      const ddv = new DataView(dir.buffer, dir.byteOffset + p, 128);
      entries.push({ name, type: dir[p + 0x42], start: ddv.getUint32(0x74, true), size: ddv.getUint32(0x78, true) });
    }
    const root = entries[0];
    const miniStream = root ? readBig(root.start, root.size) : new Uint8Array(0);
    const miniFat = [];
    if (miniFatStart < 0xFFFFFFFA) { const mf = readBig(miniFatStart, chain(miniFatStart, fat).length * SS); const mdv = new DataView(mf.buffer, mf.byteOffset, mf.byteLength); for (let i = 0; i < mf.length / 4; i++) miniFat.push(mdv.getUint32(i * 4, true)); }
    const stream = name => {
      const e = entries.find(x => x.name === name && x.type === 2);
      if (!e) return null;
      if (e.size < cutoff) {
        const secs = chain(e.start, miniFat);
        const out = new Uint8Array(secs.length * MS);
        secs.forEach((s, i) => out.set(miniStream.subarray(s * MS, s * MS + MS), i * MS));
        return out.subarray(0, e.size);
      }
      return readBig(e.start, e.size);
    };
    return { stream, entries };
  }

  function read(bytes) {
    const c = cfb(bytes);
    const wd = c.stream('WordDocument');
    if (!wd) throw new Error('Это не документ Word (нет потока WordDocument)');
    const dv = new DataView(wd.buffer, wd.byteOffset, wd.byteLength);
    if (dv.getUint16(0, true) !== 0xA5EC) throw new Error('Неизвестный формат .doc');
    const flags = dv.getUint16(0x0A, true);
    if (flags & 0x0100) throw new Error('Документ зашифрован паролем — открыть его нельзя');
    const table = c.stream(flags & 0x0200 ? '1Table' : '0Table');
    if (!table) throw new Error('В документе нет таблицы фрагментов');
    const csw = dv.getUint16(32, true);
    const lwStart = 32 + 2 + csw * 2 + 2;
    const cslw = dv.getUint16(lwStart - 2, true);
    const ccpText = dv.getInt32(lwStart + 3 * 4, true);
    const rgStart = lwStart + cslw * 4 + 2;
    const fcClx = dv.getUint32(rgStart + 33 * 8, true), lcbClx = dv.getUint32(rgStart + 33 * 8 + 4, true);
    const tv = new DataView(table.buffer, table.byteOffset, table.byteLength);
    let p = fcClx;
    const end = fcClx + lcbClx;
    let text = '';
    while (p < end) {
      const t = table[p];
      if (t === 1) { p += 3 + tv.getInt16(p + 1, true); continue; }
      if (t !== 2) break;
      const lcb = tv.getUint32(p + 1, true);
      const base = p + 5;
      const n = (lcb - 4) / 12;
      const cps = [];
      for (let i = 0; i <= n; i++) cps.push(tv.getUint32(base + i * 4, true));
      for (let i = 0; i < n; i++) {
        const pcd = base + (n + 1) * 4 + i * 8;
        let fc = tv.getUint32(pcd + 2, true);
        const compressed = (fc & 0x40000000) !== 0;
        fc &= 0x3FFFFFFF;
        const cnt = cps[i + 1] - cps[i];
        if (compressed) text += new TextDecoder('windows-1252').decode(wd.subarray(fc / 2, fc / 2 + cnt));
        else text += new TextDecoder('utf-16le').decode(wd.subarray(fc, fc + cnt * 2));
      }
      break;
    }
    if (ccpText > 0 && ccpText < text.length) text = text.slice(0, ccpText);
    // поля: оставляем только результат (между 0x14 и 0x15)
    let clean = '', depth = 0, inInstr = [];
    for (const ch of text) {
      if (ch === '\x13') { depth++; inInstr.push(true); continue; }
      if (ch === '\x14') { if (depth) inInstr[depth - 1] = false; continue; }
      if (ch === '\x15') { if (depth) { depth--; inInstr.pop(); } continue; }
      if (depth && inInstr[depth - 1]) continue;
      clean += ch;
    }
    clean = clean.replace(/[\x01\x02\x05\x08]/g, '').replace(/\x1E/g, '‑').replace(/\x1F/g, '­').replace(/\x0B/g, '\n');
    // разбор на абзацы и таблицы
    const out = document.createElement('div');
    let tbl = null, row = null;
    const parts = clean.split(/(\r|\x07|\x0C)/);
    let buf = '';
    let lastCell = false;
    for (const part of parts) {
      if (part === '\r') {
        if (tbl && row && !lastCell) { buf += '\n'; continue; }
        tbl = null; row = null;
        out.append(par(buf)); buf = ''; lastCell = false;
      } else if (part === '\x07') {
        if (lastCell && !buf) { row = null; lastCell = false; continue; } // конец строки
        if (!tbl) { tbl = h('table', { 'data-borders': '1' }, h('tbody')); out.append(tbl); }
        if (!row) { row = h('tr'); tbl.tBodies[0].append(row); }
        const td = h('td');
        buf.split('\n').forEach((l, i) => { if (i) td.append(h('br')); td.append(l); });
        if (!buf) td.innerHTML = '<br>';
        row.append(td);
        buf = ''; lastCell = true;
      } else if (part === '\x0C') {
        if (buf) { out.append(par(buf)); buf = ''; }
        out.append(h('div', { class: 'page-break' }));
        tbl = null; row = null; lastCell = false;
      } else if (part) { buf += part; lastCell = false; }
    }
    if (buf) out.append(par(buf));
    const meta = Fmt.defaultMeta();
    meta.defaultIndent = 0;
    return { html: out.innerHTML, meta, warning: 'Документ .doc (Word 97–2003) открыт в упрощённом режиме: сохранены текст, абзацы и таблицы, оформление символов и рисунки недоступны. Сохраните его в .docx.' };
  }
  function par(t) {
    const p = document.createElement('p');
    if (!t) p.innerHTML = '<br>'; else p.textContent = t;
    return p;
  }
  return { read };
})();
