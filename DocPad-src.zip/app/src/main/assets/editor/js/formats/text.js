/* Простые форматы: TXT, HTML, Markdown */
'use strict';
const TextFmt = (() => {
  // ---------- TXT ----------
  function readTxt(bytes) {
    const t = Fmt.decodeText(bytes).replace(/\r\n?/g, '\n');
    const html = t.split('\n').map(l => `<p>${esc(l) || '<br>'}</p>`).join('');
    const meta = Fmt.defaultMeta();
    meta.defaultIndent = 0; meta.defaultAfter = 0;
    return { html, meta };
  }
  /** Текст с маркерами списков и табуляцией между ячейками */
  function toText(docEl) {
    const out = [];
    const walk = (n, prefix = '') => {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) { out.push(c.data); continue; }
        if (c.nodeType !== 1) continue;
        const t = c.tagName;
        if (t === 'BR') { out.push('\n'); continue; }
        if (c.classList.contains('page-break')) { out.push('\n\f\n'); continue; }
        if (t === 'UL' || t === 'OL') {
          let k = +c.getAttribute('start') || 1;
          for (const li of c.children) {
            out.push(prefix + (t === 'UL' ? (c.classList.contains('checklist') ? (li.dataset.checked === '1' ? '[x] ' : '[ ] ') : '• ') : (k++) + '. '));
            walk(li, prefix + '    ');
            if (!out[out.length - 1]?.endsWith('\n')) out.push('\n');
          }
          continue;
        }
        if (t === 'TABLE') {
          for (const tr of c.rows) out.push([...tr.cells].map(td => td.innerText.replace(/\n/g, ' ')).join('\t') + '\n');
          continue;
        }
        if (t === 'IMG') { out.push('[рисунок]'); continue; }
        if (c.classList.contains('toc')) { c.querySelectorAll('a').forEach(a => out.push((a.querySelector('.t')?.textContent || '') + ' ... ' + (a.querySelector('.n')?.textContent || '') + '\n')); continue; }
        walk(c, prefix);
        if (/^(P|H[1-6]|DIV|BLOCKQUOTE|PRE|LI)$/.test(t) && !out[out.length - 1]?.endsWith('\n')) out.push('\n');
      }
    };
    walk(docEl);
    return out.join('').replace(/​/g, '').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n';
  }
  function writeTxt(docEl, crlf) {
    let t = toText(docEl);
    if (crlf) t = t.replace(/\n/g, '\r\n');
    return new TextEncoder().encode('﻿' + t);
  }

  // ---------- HTML ----------
  function readHtml(bytes) {
    const src = Fmt.decodeText(bytes);
    const d = new DOMParser().parseFromString(src, 'text/html');
    const meta = Fmt.defaultMeta();
    meta.defaultIndent = 0;
    const m = d.querySelector('meta[name="docpad-meta"]');
    if (m) { try { Object.assign(meta, JSON.parse(m.getAttribute('content'))); } catch (e) {} }
    meta.title = d.title || meta.title;
    // свёртываем пробелы, как это делает браузер (в редакторе white-space: pre-wrap)
    const tw = d.createTreeWalker(d.body, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (tw.nextNode()) nodes.push(tw.currentNode);
    for (const n of nodes) {
      if (n.parentElement && n.parentElement.closest('pre')) continue;
      n.data = n.data.replace(/[\r\n\t ]+/g, ' ');
      const prev = n.previousSibling, next = n.nextSibling;
      if (!n.data.trim() && (!prev || !next || /^(P|DIV|H\d|UL|OL|LI|TABLE|TR|TD|TH|TBODY|BLOCKQUOTE|BR)$/.test(prev?.nodeName) || /^(P|DIV|H\d|UL|OL|LI|TABLE|TR|TD|TH|TBODY|BLOCKQUOTE)$/.test(next?.nodeName))) n.remove();
    }
    const root = d.querySelector('#doc') || d.body;
    return { html: Ed.sanitize(root.innerHTML), meta };
  }
  function writeHtml(html, meta) {
    const mg = meta.margins;
    const land = meta.orientation === 'landscape';
    const pw = land ? Math.max(meta.pageW, meta.pageH) : meta.pageW, ph = land ? Math.min(meta.pageW, meta.pageH) : meta.pageH;
    const css = `
@page { size: ${pw}mm ${ph}mm; margin: ${mg.t}mm ${mg.r}mm ${mg.b}mm ${mg.l}mm; }
body { margin: 0; background: #e9ebee; }
#doc { background: ${meta.pageColor || '#fff'}; max-width: ${pw}mm; margin: 16px auto; padding: ${mg.t}mm ${mg.r}mm ${mg.b}mm ${mg.l}mm; box-sizing: border-box; box-shadow: 0 1px 6px rgba(0,0,0,.2);
  font-family: ${Fonts.css(meta.defaultFont)}; font-size: ${meta.defaultSize}pt; line-height: ${(meta.defaultLine * Fmt.LH).toFixed(3)}; white-space: pre-wrap; overflow-wrap: break-word; color: #000; ${meta.columns > 1 ? `column-count:${meta.columns};` : ''} }
#doc p { margin: 0 0 ${meta.defaultAfter}pt; text-indent: ${meta.defaultIndent || 0}cm; }
#doc h1,#doc h2,#doc h3,#doc h4,#doc h5,#doc h6 { color: #1F3864; margin: 12pt 0 6pt; }
#doc h1{font-size:20pt}#doc h2{font-size:16pt}#doc h3{font-size:14pt}
#doc .title { font-size: 28pt; } #doc .subtitle { font-size: 15pt; color: #5a5a5a; }
#doc blockquote { margin: 8pt 24pt; padding: 4pt 12pt; border-left: 3pt solid #9BB0D0; font-style: italic; }
#doc pre { font-family: "Courier New", monospace; background: #f5f5f5; padding: 6pt; }
#doc table { border-collapse: collapse; } #doc td, #doc th { padding: 3pt 5pt; vertical-align: top; }
#doc table[data-borders="1"] td, #doc table[data-borders="1"] th { border: 1px solid #000; }
#doc img { max-width: 100%; height: auto; } #doc img.float-left { float: left; margin: 0 10pt 6pt 0; } #doc img.float-right { float: right; margin: 0 0 6pt 10pt; } #doc img.center { display: block; margin: 0 auto; }
#doc .page-break { break-after: page; height: 0; }
#doc ul.checklist { list-style: none; } #doc ul.checklist li::before { content: "☐ "; } #doc ul.checklist li[data-checked="1"]::before { content: "☑ "; }
#doc .dp-comment { background: #FFF2A8; }
#doc .footnotes { border-top: 1px solid #999; margin-top: 18pt; font-size: .85em; }
#doc .toc a { color: inherit; text-decoration: none; }
@media print { body { background: #fff; } #doc { margin: 0; padding: 0; box-shadow: none; max-width: none; } }`;
    const metaJson = esc(JSON.stringify(meta));
    const out = `<!DOCTYPE html>\n<html lang="${meta.lang || 'ru'}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<meta name="generator" content="DocPad">\n<meta name="docpad-meta" content="${metaJson}">\n<title>${esc(meta.title || '')}</title>\n<style>${css}\n</style>\n</head>\n<body>\n<div id="doc">${html}</div>\n</body>\n</html>\n`;
    return new TextEncoder().encode(out);
  }

  // ---------- Markdown ----------
  function readMd(bytes) {
    const src = Fmt.decodeText(bytes);
    let html;
    if (window.marked) html = marked.parse(src, { gfm: true, breaks: false });
    else html = src.split(/\n{2,}/).map(p => `<p>${esc(p)}</p>`).join('');
    // marked оставляет переводы строк между тегами — в pre-wrap они видны
    const d = document.createElement('div');
    d.innerHTML = Ed.sanitize(html);
    const tw = document.createTreeWalker(d, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (tw.nextNode()) nodes.push(tw.currentNode);
    for (const n of nodes) {
      if (n.parentElement.closest('pre')) continue;
      if (!n.data.trim() && n.data.includes('\n')) n.remove();
      else n.data = n.data.replace(/\n/g, ' ');
    }
    d.querySelectorAll('pre').forEach(p => { p.textContent = p.textContent.replace(/\n$/, ''); });
    d.querySelectorAll('table').forEach(t => t.dataset.borders = '1');
    d.querySelectorAll('li > p:only-child').forEach(p => p.replaceWith(...p.childNodes));
    d.querySelectorAll('li').forEach(li => {
      const cb = li.querySelector('input[type=checkbox]');
      if (cb) { li.parentElement.classList.add('checklist'); li.dataset.checked = cb.checked ? '1' : '0'; cb.remove(); }
    });
    const meta = Fmt.defaultMeta();
    meta.defaultIndent = 0;
    return { html: d.innerHTML, meta };
  }
  function writeMd(docEl) {
    const inline = n => {
      if (n.nodeType === 3) return n.data.replace(/​/g, '').replace(/([*_`\[\]\\])/g, '\\$1');
      if (n.nodeType !== 1) return '';
      const t = n.tagName;
      const inner = () => [...n.childNodes].map(inline).join('');
      if (t === 'BR') return '  \n';
      if (t === 'IMG') return `![${n.alt || ''}](${n.src.startsWith('data:') && n.src.length > 200000 ? 'image' : n.src})`;
      if (t === 'A') return `[${inner()}](${n.getAttribute('href') || ''})`;
      if (t === 'CODE') return '`' + n.textContent + '`';
      const cs = getComputedStyle(n);
      let s = inner();
      if (!s.trim()) return s;
      const b = t === 'B' || t === 'STRONG' || (parseInt(cs.fontWeight) >= 600 && !(parseInt(getComputedStyle(n.parentElement).fontWeight) >= 600));
      const i = t === 'I' || t === 'EM' || (cs.fontStyle === 'italic' && getComputedStyle(n.parentElement).fontStyle !== 'italic');
      const st = t === 'S' || t === 'STRIKE' || t === 'DEL' || /line-through/.test(n.style.textDecorationLine || n.style.textDecoration || '');
      if (st) s = `~~${s}~~`;
      if (i) s = `*${s}*`;
      if (b) s = `**${s}**`;
      if (t === 'SUP') s = `<sup>${s}</sup>`;
      if (t === 'SUB') s = `<sub>${s}</sub>`;
      return s;
    };
    const out = [];
    const block = (n, indent = '') => {
      if (n.nodeType === 3) { if (n.data.trim()) out.push(indent + inline(n)); return; }
      if (n.nodeType !== 1) return;
      const t = n.tagName;
      if (/^H[1-6]$/.test(t)) return out.push('#'.repeat(+t[1]) + ' ' + [...n.childNodes].map(inline).join('').trim(), '');
      if (t === 'HR' || n.classList.contains('page-break')) return out.push('---', '');
      if (t === 'BLOCKQUOTE') { const sub = []; const save = out.length; [...n.childNodes].forEach(c => block(c)); const lines = out.splice(save); out.push(...(lines.length ? lines : [inline(n)]).map(l => '> ' + l), ''); return; }
      if (t === 'PRE') return out.push('```', n.textContent, '```', '');
      if (t === 'UL' || t === 'OL') {
        let k = +n.getAttribute('start') || 1;
        for (const li of n.children) {
          const nested = [...li.children].filter(c => c.tagName === 'UL' || c.tagName === 'OL');
          const txt = [...li.childNodes].filter(c => !nested.includes(c)).map(inline).join('').trim();
          const mark = t === 'OL' ? `${k++}.` : n.classList.contains('checklist') ? `- [${li.dataset.checked === '1' ? 'x' : ' '}]` : '-';
          out.push(indent + mark + ' ' + txt);
          nested.forEach(nl => block(nl, indent + '   '));
        }
        if (!indent) out.push('');
        return;
      }
      if (t === 'TABLE') {
        const rows = [...n.rows].map(r => [...r.cells].map(c => inline(c).replace(/\|/g, '\\|').replace(/\n/g, ' ').trim()));
        if (!rows.length) return;
        const w = Math.max(...rows.map(r => r.length));
        rows.forEach(r => { while (r.length < w) r.push(''); });
        out.push('| ' + rows[0].join(' | ') + ' |', '|' + ' --- |'.repeat(w));
        rows.slice(1).forEach(r => out.push('| ' + r.join(' | ') + ' |'));
        out.push('');
        return;
      }
      if (n.classList.contains('toc')) { n.querySelectorAll('a').forEach(a => out.push(`- [${a.querySelector('.t')?.textContent || ''}](${a.getAttribute('href')})`)); out.push(''); return; }
      if ([...n.children].some(c => /^(P|DIV|UL|OL|TABLE|H\d|BLOCKQUOTE|PRE)$/.test(c.tagName))) { [...n.childNodes].forEach(c => block(c, indent)); return; }
      const s = inline(n).trim();
      out.push(s, '');
    };
    [...docEl.childNodes].forEach(c => block(c));
    return new TextEncoder().encode(out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n');
  }

  return { readTxt, writeTxt, toText, readHtml, writeHtml, readMd, writeMd };
})();
