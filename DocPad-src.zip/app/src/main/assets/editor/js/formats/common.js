/* Общие функции для форматов файлов */
'use strict';
const Fmt = (() => {
  function b64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function bytesToB64(u8) {
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  }
  function dataUrlToBytes(url) {
    const m = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(url);
    if (!m) return null;
    const mime = m[1] || 'application/octet-stream';
    const bytes = m[2] ? b64ToBytes(m[3]) : new TextEncoder().encode(decodeURIComponent(m[3]));
    return { mime, bytes };
  }
  function bytesToDataUrl(bytes, mime) { return `data:${mime};base64,${bytesToB64(bytes)}`; }
  const MIME_BY_EXT = {
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', webp: 'image/webp',
    svg: 'image/svg+xml', tif: 'image/tiff', tiff: 'image/tiff', emf: 'image/x-emf', wmf: 'image/x-wmf'
  };
  const EXT_BY_MIME = { 'image/png': 'png', 'image/jpeg': 'jpeg', 'image/gif': 'gif', 'image/bmp': 'bmp' };

  const FORMATS = {
    docx: { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', label: 'Документ Word (.docx)', write: true },
    odt: { mime: 'application/vnd.oasis.opendocument.text', label: 'Документ OpenDocument (.odt)', write: true },
    rtf: { mime: 'application/rtf', label: 'Текст в формате RTF (.rtf)', write: true },
    pdf: { mime: 'application/pdf', label: 'PDF (.pdf)', write: true },
    html: { mime: 'text/html', label: 'Веб-страница (.html)', write: true },
    txt: { mime: 'text/plain', label: 'Обычный текст (.txt)', write: true },
    md: { mime: 'text/markdown', label: 'Markdown (.md)', write: true },
    doc: { mime: 'application/msword', label: 'Документ Word 97–2003 (.doc)', write: false }
  };

  function detect(bytes, name = '') {
    const ext = (name.match(/\.([a-z0-9]+)$/i) || [])[1]?.toLowerCase() || '';
    const b = bytes;
    if (b[0] === 0x50 && b[1] === 0x4B) {
      const head = new TextDecoder('latin1').decode(b.subarray(0, Math.min(b.length, 4000)));
      if (head.includes('mimetypeapplication/vnd.oasis.opendocument')) return 'odt';
      if (ext === 'odt' || ext === 'ott') return 'odt';
      return 'docx';
    }
    if (b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0) return 'doc';
    if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return 'pdf';
    const start = new TextDecoder('latin1').decode(b.subarray(0, 64)).replace(/^﻿|^ï»¿/, '').trimStart();
    if (start.startsWith('{\\rtf')) return 'rtf';
    if (ext === 'md' || ext === 'markdown') return 'md';
    if (ext === 'html' || ext === 'htm' || ext === 'xhtml' || /^<(!doctype html|html|\?xml)/i.test(start)) return 'html';
    if (ext === 'fodt') return 'odt-flat';
    return 'txt';
  }

  /** Декодирование текста: BOM, UTF-8, иначе windows-1251 */
  function decodeText(bytes) {
    if (bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) return new TextDecoder('utf-8').decode(bytes.subarray(3));
    if (bytes[0] === 0xFF && bytes[1] === 0xFE) return new TextDecoder('utf-16le').decode(bytes.subarray(2));
    if (bytes[0] === 0xFE && bytes[1] === 0xFF) return new TextDecoder('utf-16be').decode(bytes.subarray(2));
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch (e) {
      try { return new TextDecoder('windows-1251').decode(bytes); } catch (e2) { return new TextDecoder('latin1').decode(bytes); }
    }
  }

  // ---- цвета ----
  function toHex(c) {
    if (!c) return null;
    c = c.trim();
    if (c === 'transparent' || c === 'inherit' || c === 'initial') return null;
    if (c[0] === '#') {
      if (c.length === 4) c = '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3];
      return c.slice(1, 7).toUpperCase();
    }
    const m = c.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?/);
    if (m) {
      if (m[4] !== undefined && parseFloat(m[4]) === 0) return null;
      return [m[1], m[2], m[3]].map(x => Math.round(+x).toString(16).padStart(2, '0')).join('').toUpperCase();
    }
    const d = document.createElement('div'); d.style.color = c; document.body.append(d);
    const r = getComputedStyle(d).color; d.remove();
    return r && r !== c ? toHex(r) : null;
  }
  const HL = { yellow: 'FFFF00', green: '00FF00', cyan: '00FFFF', magenta: 'FF00FF', blue: '0000FF', red: 'FF0000', darkBlue: '000080', darkCyan: '008080',
    darkGreen: '008000', darkMagenta: '800080', darkRed: '800000', darkYellow: '808000', darkGray: '808080', lightGray: 'C0C0C0', black: '000000', white: 'FFFFFF' };

  const xmlEsc = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ---- размеры ----
  const PAGE_SIZES = {
    A3: [297, 420], A4: [210, 297], A5: [148, 210], A6: [105, 148], B5: [176, 250], Letter: [215.9, 279.4], Legal: [215.9, 355.6],
    Executive: [184.2, 266.7], Tabloid: [279.4, 431.8]
  };
  const MARGINS = {
    normal: { t: 20, r: 15, b: 20, l: 30 }, gost: { t: 20, r: 10, b: 20, l: 30 }, narrow: { t: 12.7, r: 12.7, b: 12.7, l: 12.7 },
    moderate: { t: 25.4, r: 19.1, b: 25.4, l: 19.1 }, wide: { t: 25.4, r: 50.8, b: 25.4, l: 50.8 }, office: { t: 25.4, r: 25.4, b: 25.4, l: 25.4 }
  };
  const mmToTw = mm => Math.round(mm / 25.4 * 1440);
  const twToMm = tw => tw / 1440 * 25.4;
  const pxToTw = px => Math.round(px * 15);
  const pxToEmu = px => Math.round(px * 9525);

  function defaultMeta() {
    const S = Store.S();
    const sz = PAGE_SIZES[S.pageSize] || PAGE_SIZES.A4;
    return {
      title: '', pageW: sz[0], pageH: sz[1], orientation: 'portrait',
      margins: Object.assign({}, MARGINS[S.marginsPreset] || MARGINS.normal),
      columns: 1, header: '', footer: '', pageNumbers: 'none', pageNumFormat: 'n',
      defaultFont: S.defaultFont, defaultSize: S.defaultSize, defaultLine: S.defaultLine, defaultAfter: S.defaultAfter, defaultIndent: S.defaultIndent,
      pageColor: '', lang: S.lang
    };
  }

  function download(bytes, name, mime) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([bytes], { type: mime }));
    a.download = name;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // межстрочный интервал Word «1,0» ≈ 1.15 в CSS (учёт межстрочного зазора шрифта)
  const LH = 1.15;


  // ---- извлечение оформления из DOM (для ODT/RTF/других экспортёров) ----
  const GENERIC_FONT = { 'sans-serif': 'Arial', serif: 'Times New Roman', monospace: 'Courier New', cursive: 'Comic Sans MS', 'system-ui': 'Arial',
    'sans-serif-condensed': 'Arial Narrow', casual: 'Comic Sans MS', 'serif-monospace': 'Courier New' };
  const BLOCK_RX = /^(P|H[1-6]|LI|TD|TH|BLOCKQUOTE|PRE|DIV|TABLE|TR|TBODY|UL|OL)$/;
  function runStyle(el) {
    const cs = getComputedStyle(el);
    let font = Fonts.first(cs.fontFamily);
    font = GENERIC_FONT[font] || (/^sans-serif-/.test(font) ? 'Arial' : font);
    const o = {
      font, size: Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2,
      b: (parseInt(cs.fontWeight) || 400) >= 600, i: cs.fontStyle !== 'normal',
      color: toHex(cs.color), caps: cs.textTransform === 'uppercase', smallCaps: cs.fontVariantCaps === 'small-caps',
      u: null, strike: false, vert: null, bg: null, spacing: parseFloat(cs.letterSpacing) || 0
    };
    let e = el;
    while (e && e.id !== 'doc') {
      const ecs = e === el ? cs : getComputedStyle(e);
      const line = ecs.textDecorationLine || '';
      if (/underline/.test(line) && !o.u) o.u = ecs.textDecorationStyle || 'solid';
      if (/line-through/.test(line)) o.strike = true;
      if (!o.vert && (e.tagName === 'SUP' || ecs.verticalAlign === 'super')) o.vert = 'super';
      if (!o.vert && (e.tagName === 'SUB' || ecs.verticalAlign === 'sub')) o.vert = 'sub';
      if (!o.bg && !BLOCK_RX.test(e.tagName)) o.bg = toHex(ecs.backgroundColor);
      if (/^(P|H[1-6]|LI|TD|TH|BLOCKQUOTE|PRE)$/.test(e.tagName)) break;
      e = e.parentElement;
    }
    if (o.vert) {
      const blk = el.closest('p,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,pre');
      if (blk) o.size = Math.round(parseFloat(getComputedStyle(blk).fontSize) * 0.75 * 2) / 2;
    }
    return o;
  }
  function paraStyle(el) {
    const cs = getComputedStyle(el);
    const fs = parseFloat(cs.fontSize) || 16;
    const isCell = /^(TD|TH)$/.test(el.tagName);
    const al = cs.textAlign;
    const o = {
      align: al === 'center' ? 'center' : (al === 'right' || al === 'end') ? 'right' : al === 'justify' ? 'justify' : 'left',
      mt: isCell ? 0 : (parseFloat(cs.marginTop) || 0) * 0.75, mb: isCell ? 0 : (parseFloat(cs.marginBottom) || 0) * 0.75,
      ml: isCell ? 0 : (parseFloat(cs.marginLeft) || 0) * 0.75, mr: isCell ? 0 : (parseFloat(cs.marginRight) || 0) * 0.75,
      ti: (parseFloat(cs.textIndent) || 0) * 0.75, lh: null, lhExact: null,
      bg: isCell ? null : toHex(cs.backgroundColor), rtl: el.getAttribute('dir') === 'rtl'
    };
    if (cs.lineHeight !== 'normal') {
      if (/pt$/.test(el.style.lineHeight)) o.lhExact = parseFloat(el.style.lineHeight);
      else o.lh = parseFloat(cs.lineHeight) / fs / LH;
    }
    if (o.align === 'left' && el.querySelector && el.querySelector(':scope > img.center') && !el.textContent.trim()) o.align = 'center';
    return o;
  }
  /** Единицы ODF/CSS → пункты */
  function toPt(v) {
    if (v == null) return null;
    const m = /^(-?[\d.]+)\s*(pt|cm|mm|in|px|pc|%)?$/.exec(String(v).trim());
    if (!m) return null;
    const n = parseFloat(m[1]);
    switch (m[2]) { case 'cm': return n / 2.54 * 72; case 'mm': return n / 25.4 * 72; case 'in': return n * 72; case 'px': return n * 0.75; case 'pc': return n * 12; default: return n; }
  }

  /** Ширина текстовой области страницы в CSS-пикселях (96 dpi) */
  function contentPx() {
    const m = App.state.meta;
    const land = m.orientation === 'landscape';
    const pw = land ? Math.max(m.pageW, m.pageH) : Math.min(m.pageW, m.pageH);
    return (pw - m.margins.l - m.margins.r) / 25.4 * 96 / (m.columns > 1 ? m.columns : 1);
  }
  /** Ширина элемента «на бумаге» (а не на экране телефона) */
  function paperWidth(el) {
    const cp = contentPx();
    const sw = el.style.width;
    if (/%$/.test(sw)) return cp * parseFloat(sw) / 100;
    if (/px$/.test(sw)) return Math.min(parseFloat(sw), cp);
    const zoom = parseFloat(getComputedStyle(document.getElementById('page')).zoom) || 1;
    const docW = Ed.doc.clientWidth || cp;
    const w = el.getBoundingClientRect().width / zoom;
    return Math.min(cp, w * Math.max(1, cp / docW));
  }
  /** Размер рисунка на бумаге [w, h] */
  function imageSize(img) {
    const w = paperWidth(img);
    const ratio = img.naturalWidth && img.naturalHeight ? img.naturalHeight / img.naturalWidth : (img.getBoundingClientRect().height / (img.getBoundingClientRect().width || 1)) || 1;
    return [w || img.naturalWidth || 100, (w || img.naturalWidth || 100) * ratio];
  }

  /** Последний <br> в абзаце — служебный (держит высоту пустой строки), в файл не пишется */
  function trailingBr(n) {
    let x = n;
    while (x && !x.nextSibling && x.parentElement && !/^(P|H[1-6]|LI|TD|TH|BLOCKQUOTE|PRE|DIV)$/.test(x.parentElement.tagName)) x = x.parentElement;
    return !!x && !x.nextSibling;
  }
  return { trailingBr, contentPx, paperWidth, imageSize, runStyle, paraStyle, toPt, LH, b64ToBytes, bytesToB64, dataUrlToBytes, bytesToDataUrl, MIME_BY_EXT, EXT_BY_MIME, FORMATS, detect, decodeText, toHex, HL, xmlEsc,
    PAGE_SIZES, MARGINS, mmToTw, twToMm, pxToTw, pxToEmu, defaultMeta, download };
})();
