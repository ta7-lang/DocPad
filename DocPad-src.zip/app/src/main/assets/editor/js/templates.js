/* Шаблоны новых документов */
'use strict';
const Templates = (() => {
  const today = () => new Date().toLocaleDateString('ru-RU', { day: '2-digit', month: 'long', year: 'numeric' });
  const list = [
    { id: 'blank', name: 'Новый документ', html: () => '<p><br></p>' },
    {
      id: 'statement', name: 'Заявление', meta: { defaultFont: 'Times New Roman', defaultSize: 14, defaultLine: 1, defaultAfter: 0, defaultIndent: 1.25, marginsPreset: 'gost' },
      html: () => `<p style="margin-left:50%;text-indent:0">Директору ООО «Название»<br>Иванову И. И.<br>от Петрова Петра Петровича,<br>должность</p><p><br></p>
<p style="text-align:center;text-indent:0"><b>ЗАЯВЛЕНИЕ</b></p><p><br></p>
<p style="text-align:justify">Прошу предоставить мне ежегодный оплачиваемый отпуск с «__» ________ 20__ г. продолжительностью __ календарных дней.</p><p><br></p>
<p style="text-indent:0">${today()}\t\t\t\t\t________ / П. П. Петров</p>`
    },
    {
      id: 'letter', name: 'Деловое письмо', meta: { defaultFont: 'Arial', defaultSize: 11, defaultLine: 1.15, defaultAfter: 6 },
      html: () => `<p style="text-align:right"><b>ООО «Компания»</b><br>г. Город, ул. Улица, 1<br>тел. +0 000 000-00-00</p><hr>
<p>${today()}</p><p>Уважаемый(ая) Имя Отчество!</p>
<p style="text-align:justify">Текст письма. Кратко изложите цель обращения, затем подробности и ожидаемый результат.</p>
<p style="text-align:justify">Будем признательны за ответ до __ ________ 20__ г.</p><p><br></p><p>С уважением,<br>Имя Фамилия<br>Должность</p>`
    },
    {
      id: 'resume', name: 'Резюме', meta: { defaultFont: 'Calibri', defaultSize: 11, defaultLine: 1.1, defaultAfter: 4 },
      html: () => `<p class="title" style="text-align:center">Имя Фамилия</p><p class="subtitle" style="text-align:center">Желаемая должность · Город · +0 000 000-00-00 · email@example.com</p><hr>
<h2>О себе</h2><p>Два-три предложения о профессиональном опыте и сильных сторонах.</p>
<h2>Опыт работы</h2><p><b>Должность</b> — Компания, 2021–настоящее время</p><ul><li>Достижение с цифрами</li><li>Ключевая обязанность</li></ul>
<p><b>Должность</b> — Компания, 2018–2021</p><ul><li>Достижение</li></ul>
<h2>Образование</h2><p><b>Университет</b>, специальность, 2014–2018</p>
<h2>Навыки</h2><table data-borders="0" style="width:100%"><tbody><tr><td>• Навык 1<br>• Навык 2</td><td>• Навык 3<br>• Навык 4</td></tr></tbody></table>
<h2>Языки</h2><p>Русский — родной; Английский — B2</p>`
    },
    {
      id: 'report', name: 'Отчёт', meta: { defaultFont: 'Times New Roman', defaultSize: 14, defaultLine: 1.5, defaultAfter: 0, defaultIndent: 1.25, marginsPreset: 'gost', pageNumbers: 'bottom-center' },
      html: () => `<p style="text-align:center;text-indent:0">МИНИСТЕРСТВО ОБРАЗОВАНИЯ<br>Название организации</p><p><br></p><p><br></p><p><br></p>
<p style="text-align:center;text-indent:0;font-size:18pt"><b>ОТЧЁТ</b></p><p style="text-align:center;text-indent:0">по теме «Название работы»</p><p><br></p><p><br></p>
<p style="margin-left:50%;text-indent:0">Выполнил: Фамилия И. О.<br>Проверил: Фамилия И. О.</p><p><br></p><p><br></p>
<p style="text-align:center;text-indent:0">Город, ${new Date().getFullYear()}</p><div class="page-break" contenteditable="false"></div>
<div class="toc" contenteditable="false"><div class="toc-title">Оглавление</div></div><div class="page-break" contenteditable="false"></div>
<h1>Введение</h1><p style="text-align:justify">Актуальность темы, цель и задачи работы.</p>
<h1>1. Основная часть</h1><h2>1.1. Подраздел</h2><p style="text-align:justify">Текст раздела.</p>
<h1>Заключение</h1><p style="text-align:justify">Выводы.</p>
<h1>Список литературы</h1><ol><li>Автор. Название. — Город: Издательство, год. — 100 с.</li></ol>`
    },
    {
      id: 'memo', name: 'Служебная записка', meta: { defaultFont: 'Times New Roman', defaultSize: 14, defaultLine: 1, defaultAfter: 0, defaultIndent: 1.25, marginsPreset: 'gost' },
      html: () => `<p style="margin-left:50%;text-indent:0">Руководителю отдела<br>Фамилия И. О.</p><p><br></p>
<p style="text-align:center;text-indent:0"><b>СЛУЖЕБНАЯ ЗАПИСКА</b></p><p style="text-align:center;text-indent:0">${today()} № ___</p><p><br></p>
<p style="text-align:justify">Довожу до Вашего сведения, что …</p><p><br></p>
<table data-borders="0" style="width:100%"><tbody><tr><td>Должность</td><td style="text-align:right">________ Фамилия И. О.</td></tr></tbody></table>`
    },
    {
      id: 'minutes', name: 'Протокол собрания', meta: { defaultFont: 'Arial', defaultSize: 11, defaultLine: 1.15, defaultAfter: 6 },
      html: () => `<h1 style="text-align:center">ПРОТОКОЛ № __</h1><p style="text-align:center">собрания «Название»</p>
<table data-borders="1" style="width:100%"><tbody><tr><td style="width:35%"><b>Дата</b></td><td>${today()}</td></tr><tr><td><b>Место</b></td><td> </td></tr><tr><td><b>Председатель</b></td><td> </td></tr><tr><td><b>Секретарь</b></td><td> </td></tr><tr><td><b>Присутствовали</b></td><td> </td></tr></tbody></table>
<h2>Повестка дня</h2><ol><li>Вопрос 1</li><li>Вопрос 2</li></ol>
<h2>Решения</h2><table data-borders="1" style="width:100%"><tbody><tr><th>№</th><th>Решение</th><th>Ответственный</th><th>Срок</th></tr><tr><td>1</td><td> </td><td> </td><td> </td></tr><tr><td>2</td><td> </td><td> </td><td> </td></tr></tbody></table>
<h2>Задачи</h2><ul class="checklist"><li data-checked="0">Задача</li><li data-checked="0">Задача</li></ul>`
    },
    {
      id: 'notes', name: 'Заметки', meta: { defaultFont: 'Roboto', defaultSize: 12, defaultLine: 1.2, defaultAfter: 6 },
      html: () => `<p class="title">Заметки</p><p class="subtitle">${today()}</p><h2>Главное</h2><ul><li>Пункт</li></ul><h2>Список дел</h2><ul class="checklist"><li data-checked="0">Дело 1</li><li data-checked="1">Сделанное дело</li></ul><blockquote>Важная мысль или цитата.</blockquote>`
    }
  ];
  return { list };
})();
