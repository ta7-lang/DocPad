/* Хранилище: IndexedDB (автосохранение, шрифты, библиотека документов) и localStorage (настройки) */
'use strict';
const Store = (() => {
  let dbp = null;
  function db() {
    if (dbp) return dbp;
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open('docpad', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        for (const s of ['kv', 'fonts', 'library']) if (!d.objectStoreNames.contains(s)) d.createObjectStore(s);
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  async function tx(store, fn) {
    const d = await db();
    return new Promise((res, rej) => {
      const t = d.transaction(store, 'readwrite');
      fn(t.objectStore(store));
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  }
  const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  async function get(store, key) { const d = await db(); return req(d.transaction(store).objectStore(store).get(key)); }
  async function put(store, key, val) { return tx(store, s => s.put(val, key)); }
  async function del(store, key) { return tx(store, s => s.delete(key)); }
  async function all(store) {
    const d = await db();
    const s = d.transaction(store).objectStore(store);
    const [keys, vals] = await Promise.all([req(s.getAllKeys()), req(s.getAll())]);
    return keys.map((k, i) => ({ key: k, value: vals[i] }));
  }

  // ---- настройки ----
  const DEFAULTS = {
    theme: 'system',            // system | light | dark
    paper: 'white',             // white | sepia | dark | gray
    ribbonPos: 'top',           // top | bottom
    ribbonMode: 'pinned',       // pinned | auto | hidden
    ribbonRows: 1,              // 1 — компактная лента в одну строку, 2 — как в Word
    quickbar: true,
    quickPos: 'bottom',         // bottom | top
    quickItems: ['bold', 'italic', 'underline', 'fontColor', 'highlight', 'alignMenu', 'bullets', 'numbering', 'indent', 'outdent', 'insertImage', 'insertTable', 'symbol', 'find'],
    btnSize: 'm',               // s | m | l | xl
    uiScale: 1,
    showLabels: true,
    groupLabels: true,
    statusbar: true,
    view: 'mobile',             // page | mobile
    zoom: 1,
    fitWidth: true,
    mobileScale: 1,
    guides: true,
    marks: false,
    spellcheck: true,
    hyphens: false,
    keepScreenOn: false,
    fullscreen: false,
    autosave: true,
    autosaveSec: 15,
    pastePlain: false,
    defaultFont: 'Times New Roman',
    defaultSize: 12,
    defaultLine: 1.15,
    defaultAfter: 8,
    defaultIndent: 0,
    lang: 'ru',
    pageSize: 'A4',
    marginsPreset: 'normal',
    autoCapitalize: true,
    smartQuotes: true,
    recentFonts: [],
    recentSymbols: [],
    recentColors: [],
    imageMaxPx: 2000,
    confirmClose: true,
    readFont: 1,
    author: ''
  };
  let settings;
  function loadSettings() {
    try { settings = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem('dp.settings') || '{}')); }
    catch (e) { settings = Object.assign({}, DEFAULTS); }
    return settings;
  }
  function saveSettings() { try { localStorage.setItem('dp.settings', JSON.stringify(settings)); } catch (e) {} }
  function S() { return settings || loadSettings(); }
  function set(k, v) { S()[k] = v; saveSettings(); }
  function reset() { settings = Object.assign({}, DEFAULTS); saveSettings(); }

  function recent() { try { return JSON.parse(localStorage.getItem('dp.recent') || '[]'); } catch (e) { return []; } }
  function addRecent(item) {
    let r = recent().filter(x => x.uri !== item.uri);
    r.unshift(Object.assign({ time: Date.now() }, item));
    r = r.slice(0, 30);
    try { localStorage.setItem('dp.recent', JSON.stringify(r)); } catch (e) {}
  }
  function removeRecent(uri) {
    try { localStorage.setItem('dp.recent', JSON.stringify(recent().filter(x => x.uri !== uri))); } catch (e) {}
  }

  return { get, put, del, all, S, set, reset, loadSettings, saveSettings, DEFAULTS, recent, addRecent, removeRecent };
})();
