# Методы моста JavaScript ↔ Android не должны переименовываться
-keepclassmembers class com.docpad.editor.Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
